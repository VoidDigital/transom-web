//
//  ShareListViewController.swift
//  TransomShareExtension
//
//  Created by Roma Sosnovsky on 21.02.2020.
//  Copyright © 2020 Void Digital. All rights reserved.
//

import Firebase
import UIKit

enum ShareListType {
    case tag, project

    var screenTitle: String {
        switch self {
        case .tag:
            return "Select Tags"
        case .project:
            return "Select Project"
        }
    }
}

protocol ShareListDelegate: AnyObject {
    func didSelect(tags: [FBTag], type: ShareListType)
}

class ShareListViewController: UIViewController {
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var activityIndicatorView: UIActivityIndicatorView!
    
    private var listType: ShareListType!
    private var initialTags: [FBTag] = []
    private var tags: [FBTag] = []

    private weak var delegate: ShareListDelegate?

    static func instantiate(listType: ShareListType, initialTags: [FBTag], delegate: ShareListDelegate) -> ShareListViewController {
        let vc = UIStoryboard(name: "MainInterface", bundle: nil).instantiateViewController(withIdentifier: "ShareListViewController") as! ShareListViewController
        vc.initialTags = initialTags
        vc.listType = listType
        vc.delegate = delegate
        return vc
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        setupNavigationBar()
        setupTableView()
        getTags()
    }

    private func setupNavigationBar() {
        navigationItem.title = listType.screenTitle
        let backButton = UIBarButtonItem(image: UIImage(named: "back"), style: .plain, target: self, action: #selector(goBack))
        navigationItem.leftBarButtonItem = backButton
    }

    @objc private func goBack() {
        navigationController?.popViewController(animated: true)
    }
    
    private func setupTableView() {
        tableView.dataSource = self
        tableView.delegate = self
        tableView.allowsMultipleSelection = listType == .some(.tag)
        tableView.tableFooterView = UIView()
    }

    private func selectInitialTags() {
        let selectedIndexPaths = initialTags.compactMap { self.tags.firstIndex(of: $0) }.map { IndexPath(row: $0, section: 0) }
        selectedIndexPaths.forEach {
            self.tableView.selectRow(at: $0, animated: false, scrollPosition: .none)
        }
    }

    private func getTags() {
        FBTag.tagRef?.observeSingleEvent(of: .value) { [weak self] snapshot in
            guard let self = self, let dictionary = snapshot.value as? [String: Any] else { return }

            var tags: [FBTag] = []
            for (key, _ ) in dictionary {
                guard let tagDict = dictionary[key] as? [String: Any] else { continue }

                let name = (tagDict["name"] as? String ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
                let isPiece = tagDict["isPiece"] as? Bool ?? false
                let createdAt = tagDict["createdAt"] as? TimeInterval ?? 0

                guard !name.isEmpty else { continue }

                let tag = FBTag(name: name, createdAt: createdAt, isPiece: isPiece)
                if !tags.contains(tag) {
                    switch self.listType {
                    case .project:
                        if isPiece {
                            tags.append(tag)
                        }
                    case .tag:
                        if !isPiece {
                            tags.append(tag)
                        }
                    case .none:
                        break
                    }
                }
            }

            self.tags = tags.sorted(by: { $0.name.lowercased() < $1.name.lowercased() })

            DispatchQueue.main.async {
                self.activityIndicatorView.stopAnimating()
                self.tableView.reloadData()
                self.selectInitialTags()
            }
        }
    }
}

extension ShareListViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tags.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "itemCell", for: indexPath) as? ShareListItemTableViewCell
        else { return  UITableViewCell() }

        cell.setup(tag: tags[indexPath.row])

        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let selectedRows = tableView.indexPathsForSelectedRows?.map { $0.row } ?? []
        let selectedTags = tags.enumerated()
                            .filter { (index, tag) in selectedRows.contains(index) }
                            .map { (index, tag) in tag }
        delegate?.didSelect(tags: selectedTags, type: listType)
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 56
    }
}
