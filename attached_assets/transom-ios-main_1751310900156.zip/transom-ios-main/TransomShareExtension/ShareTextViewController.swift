//
//  ShareTextViewController.swift
//  TransomShareExtension
//
//  Created by Roma Sosnovsky on 21.02.2020.
//  Copyright © 2020 Void Digital. All rights reserved.
//

import MobileCoreServices
import UIKit

class ShareTextViewController: UIViewController {
    @IBOutlet weak var thoughtTextView: UITextView!
    @IBOutlet weak var projectButton: UIButton!
    @IBOutlet weak var tagsButton: UIButton!

    private var selectedProject: FBTag? {
        didSet {
            let buttonTitle = selectedProject?.name ?? "Project"
            projectButton.setTitle(buttonTitle, for: .normal)
        }
    }
    private var selectedTags: [FBTag] = [] {
        didSet {
            let tagsString = selectedTags.map { $0.name }.joined(separator: ", ").trimmingCharacters(in: .whitespacesAndNewlines)
            let buttonTitle = tagsString.isEmpty ? "Tags" : tagsString
            tagsButton.setTitle(buttonTitle, for: .normal)
        }
    }
    private var thoughtText = ""
    
    static func instantiate() -> UINavigationController {
        let vc = UIStoryboard(name: "MainInterface", bundle: nil).instantiateViewController(withIdentifier: "ShareTextViewController")
        let navVC = UINavigationController(rootViewController: vc)
        navVC.navigationBar.backgroundColor = UIColor(red: 2/255, green: 66/255, blue: 254/255, alpha: 1)
        navVC.navigationBar.isOpaque = false
        navVC.navigationBar.barTintColor = UIColor(red: 2/255, green: 66/255, blue: 254/255, alpha: 1)
        navVC.navigationBar.tintColor = .white
        return navVC

    }

    override func viewDidLoad() {
        super.viewDidLoad()

        setupNavigationBar()
        setupTextView()
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)

        thoughtTextView.becomeFirstResponder()
    }

    private func setupNavigationBar() {
        let cancelButton = UIBarButtonItem(image: UIImage(named: "cross"), style: .plain, target: self, action: #selector(cancel))
        navigationItem.leftBarButtonItem = cancelButton

        let saveButton = UIBarButtonItem(image: UIImage(named: "save"), style: .plain, target: self, action: #selector(saveThought))
        navigationItem.rightBarButtonItem = saveButton

        let imageView = UIImageView(frame: CGRect(x: 0, y: 16, width: 17, height: 18))
        imageView.contentMode = .scaleAspectFit
        imageView.image = UIImage(named: "logo")
        navigationItem.titleView = imageView

        navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
    }

    private func setupTextView() {
        guard let inputItem = extensionContext?.inputItems.first as? NSExtensionItem,
              let itemProvider = inputItem.attachments?.first,
              itemProvider.hasItemConformingToTypeIdentifier(kUTTypeText as String)
        else { return }

        let paragraphStyle = NSMutableParagraphStyle()
        paragraphStyle.lineSpacing = 3
        let attrs: [NSAttributedString.Key: Any] = [.paragraphStyle: paragraphStyle, .font: UIFont.systemFont(ofSize: 18), .foregroundColor: UIColor(red: 70/255, green: 70/255, blue: 70/255, alpha: 1)]
        thoughtTextView.contentInset = UIEdgeInsets(top: 12, left: 16, bottom: 12, right: 16)
        thoughtTextView.typingAttributes = attrs

        itemProvider.loadItem(forTypeIdentifier: kUTTypeText as String, options: nil) { result, error in
            guard let result = result as? String else { return }

            self.thoughtText = result

            DispatchQueue.main.async {
                self.thoughtTextView.attributedText = NSAttributedString(string: result, attributes: attrs)
            }
        }
    }

    @objc private func cancel() {
        guard let context = extensionContext else { return }

        context.completeRequest(returningItems: nil)
    }

    @objc private func saveThought() {
        guard let context = extensionContext else { return }

        let tags = selectedTags.map { $0.name }
        FBThought.createThought(text: thoughtTextView.text, tags: tags, projectName: selectedProject?.name) { [weak self] thought in
            guard let self = self else { return }
            DispatchQueue.main.async {
                let vc = self.storyboard!.instantiateViewController(withIdentifier: "ShareSuccessViewController") as! ShareSuccessViewController
                vc.parentExtensionContext = context
                vc.thoughtId = thought.itemKey ?? ""
                vc.modalPresentationStyle = .overCurrentContext
                self.navigationController?.present(vc, animated: true, completion: nil)
            }
        }
    }

    private func showList(listType: ShareListType) {
        let initialTags: [FBTag]
        if listType == .project {
            if let selectedProject = selectedProject {
                initialTags = [selectedProject]
            } else {
                initialTags = []
            }
        } else {
            initialTags = selectedTags
        }
        let vc = ShareListViewController.instantiate(listType: listType, initialTags: initialTags, delegate: self)
        navigationController?.pushViewController(vc, animated: true)
    }

    // MARK: - IBActions
    @IBAction func showProjectsList(_ sender: Any) {
        showList(listType: .project)
    }

    @IBAction func showTagsList(_ sender: Any) {
        showList(listType: .tag)
    }
}

extension ShareTextViewController: ShareListDelegate {
    func didSelect(tags: [FBTag], type: ShareListType) {
        switch type {
        case .project:
            selectedProject = tags.first
        case .tag:
            selectedTags = tags
        }
    }
}
