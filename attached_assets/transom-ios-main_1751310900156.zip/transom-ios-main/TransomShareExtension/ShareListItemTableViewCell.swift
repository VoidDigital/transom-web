//
//  ShareListItemTableViewCell.swift
//  TransomShareExtension
//
//  Created by Roma Sosnovsky on 21.02.2020.
//  Copyright © 2020 Void Digital. All rights reserved.
//

import UIKit

class ShareListItemTableViewCell: UITableViewCell {
    @IBOutlet private weak var tagLabel: UILabel!
    @IBOutlet private weak var tickImageView: UIImageView!

    override func awakeFromNib() {
        super.awakeFromNib()

        tickImageView.isHidden = true
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        selectedBackgroundView?.isHidden = true
        tickImageView.isHidden = !selected
        contentView.backgroundColor = selected ? UIColor.white : UIColor(red: 247/255, green: 248/255, blue: 250/255, alpha: 1)
    }

    func setup(tag: FBTag) {
        tagLabel.text = tag.name
    }

}
