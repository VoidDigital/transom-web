//
//  ShareSuccessViewController.swift
//  TransomShareExtension
//
//  Created by Roma Sosnovsky on 26.02.2020.
//  Copyright © 2020 Void Digital. All rights reserved.
//

import UIKit

class ShareSuccessViewController: UIViewController {
    @IBOutlet weak var tickWrapView: UIView!
    @IBOutlet weak var transomButton: UIButton!

    var thoughtId = ""
    var parentExtensionContext: NSExtensionContext?

    override func viewDidLoad() {
        super.viewDidLoad()

        setupUI()
    }

    private func setupUI() {
        tickWrapView.layer.cornerRadius = 52
        tickWrapView.layer.borderWidth = 3
        tickWrapView.layer.borderColor = UIColor(red: 195/255, green: 198/255, blue: 200/255, alpha: 1).cgColor

        transomButton.layer.cornerRadius = 6
    }

    private func openURL(url: URL) {
        presentingViewController?.parent?.extensionContext?.completeRequest(returningItems: nil) { _ in
            do {
                let application = try self.sharedApplication()
                application.performSelector(inBackground: "openURL:", with: url)
            } catch {
                print(error)
            }
        }
    }

    func sharedApplication() throws -> UIApplication {
        var responder: UIResponder? = self
        while responder != nil {
            if let application = responder as? UIApplication {
                return application
            }

            responder = responder?.next
        }

        throw NSError(domain: "UIInputViewController+sharedApplication.swift", code: 1, userInfo: nil)
    }
    
    // MARK: IBActions
    @IBAction private func openInTransom(_ sender: Any) {
        let url = URL(string: "transom:thought?id=\(thoughtId)")!
        openURL(url: url)
    }

    @IBAction private func close(_ sender: Any) {
        parentExtensionContext?.completeRequest(returningItems: nil, completionHandler: nil)
    }
}
