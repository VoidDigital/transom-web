//
//  ShareViewController.swift
//  TransomShareExtension
//
//  Created by Roma Sosnovsky on 17.02.2020.
//  Copyright © 2020 Void Digital. All rights reserved.
//

import FirebaseCore
import FirebaseAuth
import UIKit

class ShareViewController: UIViewController {
    @IBOutlet weak var containerView: UIView!

    private var didLayoutSubviews = false

    override func viewDidLoad() {
        super.viewDidLoad()

        FirebaseApp.configure()

        DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
            do {
              try Auth.auth().useUserAccessGroup("5B8JD5RLV7.com.voidllc.transom")
            } catch let error as NSError {
              print("Error changing user access group: %@", error)
            }
        }

        containerView.layer.cornerRadius = 8
        containerView.clipsToBounds = true

        UINavigationBar.appearance().titleTextAttributes = [.foregroundColor: UIColor.white, .font: UIFont.systemFont(ofSize: 16)]
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()

        guard !didLayoutSubviews else { return }

        didLayoutSubviews = true
        setupContainerView()
    }

    private func setupContainerView() {
        let vc = ShareTextViewController.instantiate()
        addChild(vc)
        vc.view.autoresizingMask = [.flexibleHeight, .flexibleWidth]
        vc.view.frame = containerView.bounds
        containerView.addSubview(vc.view)
        vc.didMove(toParent: self)
    }
}
