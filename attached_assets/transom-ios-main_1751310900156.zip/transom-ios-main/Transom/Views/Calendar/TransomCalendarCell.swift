//
//  TransomCalendarCell.swift
//  transom
//
//  Created by Roma Sosnovsky on 28.08.2020.
//  Copyright © 2020 Void Digital. All rights reserved.
//

import Foundation
import FSCalendar

class TransomCalendarCell: FSCalendarCell {
    var dayLayer: CAShapeLayer!

    private var titleColor: UIColor?

    required init!(coder aDecoder: NSCoder!) {
        fatalError("init(coder:) has not been implemented")
    }

    override init!(frame: CGRect) {
        super.init(frame: frame)

        let x: CGFloat = (frame.width - contentView.bounds.height + 6) / 2
        let dayLayer = CAShapeLayer()
        dayLayer.borderWidth = 2
        dayLayer.cornerRadius = 6
        dayLayer.frame = CGRect(x: x, y: 0, width: contentView.bounds.height - 6, height: contentView.bounds.height - 6)
        dayLayer.actions = ["hidden": NSNull()]
        contentView.layer.insertSublayer(dayLayer, below: titleLabel.layer)
        self.dayLayer = dayLayer
    }

    func setup(backgroundColor: UIColor, borderColor: UIColor, titleColor: UIColor?) {
        dayLayer.backgroundColor = backgroundColor.cgColor
        dayLayer.borderColor = borderColor.cgColor

        self.titleColor = titleColor
    }

    override func configureAppearance() {
        super.configureAppearance()

        if let titleColor = titleColor {
            titleLabel.textColor = titleColor
        }
    }

}
