//
//  ThoughtTagsView.swift
//  transom
//
//  Created by Roma Sosnovsky on 9/25/19.
//  Copyright © 2019 Void Digital. All rights reserved.
//

import UIKit

protocol ThoughtTagsViewDelegate: AnyObject {
    func update(tags: [String], type: TagType)
}

class ThoughtTagsView: UIView {
    @IBOutlet private var view: UIView!
    @IBOutlet private weak var titleLabel: UILabel!
    @IBOutlet private weak var tagsCollectionView: UICollectionView!
    @IBOutlet private weak var searchTableView: UITableView!

    private var allowsMultipleSelection = false
    private var allowsCreation = true
    private var tags: [String] = []
    private var allTags: [FBTag] = []
    private var filteredTags: [FBTag] = []
    private var type: TagType = .tag
    private var searchText = ""
    
    private var allTagsStrings: [String] {
        allTags.map { $0.name }
    }

    weak var delegate: ThoughtTagsViewDelegate?
    
    override init(frame: CGRect) {
        super.init(frame: frame)

        setupView()
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)

        setupView()
    }

    private func setupView() {
        Bundle.main.loadNibNamed("ThoughtTagsView", owner: self, options: nil)

        guard let view = view else { return }

        view.layer.cornerRadius = 6
        view.clipsToBounds = true
        view.frame = bounds
        view.autoresizingMask = [.flexibleHeight, .flexibleWidth]
        addSubview(view)

        searchTableView.dataSource = self
        searchTableView.delegate = self
        searchTableView.register(UINib(nibName: "TagTableViewCell", bundle: nil), forCellReuseIdentifier: "tagCell")

        setupTagsCollectionView()
    }

    private func setupTagsCollectionView() {
        tagsCollectionView.dataSource = self
        tagsCollectionView.delegate = self
        tagsCollectionView.isPrefetchingEnabled = false
        tagsCollectionView.delaysContentTouches = false
        tagsCollectionView.allowsSelection = false
        tagsCollectionView.allowsMultipleSelection = false
        tagsCollectionView.showsVerticalScrollIndicator = false
        tagsCollectionView.showsHorizontalScrollIndicator = false
        tagsCollectionView.contentInset = UIEdgeInsets(top: 0, left: 12, bottom: 0, right: 12)
        tagsCollectionView.register(UINib(nibName: "TagCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "tagCell")
        tagsCollectionView.register(UINib(nibName: "TagInputCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "tagInputCell")

        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .horizontal
        tagsCollectionView.collectionViewLayout = layout
    }

    func focusInput() {
        let indexPath: IndexPath

        switch type {
        case .project:
            indexPath = IndexPath(row: allowsMultipleSelection ? tags.count : 0, section: 0)
        case .tag:
            indexPath = IndexPath(row: tags.count, section: 0)
        }

        guard let inputCell = tagsCollectionView.cellForItem(at: indexPath) as? TagInputCollectionViewCell else { return }
        inputCell.startEditing()
    }

    func setup(type: TagType, tags: [String], allTags: [FBTag], allowsMultipleSelection: Bool = false, allowsCreation: Bool = true) {
        self.type = type
        self.tags = tags
        self.allTags = allTags
        self.allowsMultipleSelection = allowsMultipleSelection
        self.allowsCreation = allowsCreation

        updateUI()
    }

    private func updateUI() {
        titleLabel.text = allowsMultipleSelection ? type.exportModalTitle : type.modalTitle
        filterTags(text: searchText)
        searchTableView.reloadData()
        tagsCollectionView.reloadData()
        tagsCollectionView.layoutIfNeeded()
        if type == .tag || allowsMultipleSelection {
            let indexPath = IndexPath(row: tags.count, section: 0)
            tagsCollectionView.scrollToItem(at: indexPath, at: .right, animated: false)
        }
    }

    // MARK: - IBActions
    @IBAction func saveTags(_ sender: Any) {
        view.endEditing(true)
        
        let indexPath: IndexPath

        switch type {
        case .project:
            indexPath = IndexPath(row: allowsMultipleSelection ? tags.count : 0, section: 0)
        case .tag:
            indexPath = IndexPath(row: tags.count, section: 0)
        }

        if let inputCell = tagsCollectionView.cellForItem(at: indexPath) as? TagInputCollectionViewCell, let tagInput = inputCell.inputTextField.text, !tagInput.isEmpty, !tags.contains(tagInput), allowsCreation {
            tags.append(tagInput)
        }

        delegate?.update(tags: tags, type: type)
    }
}

extension ThoughtTagsView: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return filteredTags.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "tagCell", for: indexPath) as? TagTableViewCell
        else { return UITableViewCell() }

        cell.setup(tag: filteredTags[indexPath.row])

        return cell
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 54
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard type != .project || tags.isEmpty || allowsMultipleSelection else { return }
        add(tag: filteredTags[indexPath.row].name)
    }
}

extension ThoughtTagsView: UICollectionViewDataSource, UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        switch type {
        case .project:
            return allowsMultipleSelection ? tags.count + 1 : 1
        case .tag:
            return tags.count + 1
        }
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard indexPath.row < tags.count else {
            if let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "tagInputCell", for: indexPath) as? TagInputCollectionViewCell {
                cell.update(text: searchText, placeholder: "Enter \(type.rawValue)")
                cell.delegate = self
                return cell
            } else {
                return UICollectionViewCell()
            }
        }

        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "tagCell", for: indexPath) as? TagCollectionViewCell
            else { return UICollectionViewCell() }

        cell.setup(tag: tags[indexPath.row])
        cell.delegate = self

        return cell
    }
}

extension ThoughtTagsView: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        guard indexPath.row < tags.count else {
            if tags.isEmpty {
                return CGSize(width: view.frame.width - 28, height: 30)
            } else {
                return CGSize(width: 200, height: 30)
            }
        }

        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 12, weight: .medium)
        label.text = tags[indexPath.row]
        let size = label.sizeThatFits(tagsCollectionView.frame.size)
        return CGSize(width: size.width + 44, height: 30)
    }
}

extension ThoughtTagsView: TagInputCellDelegate {
    func add(tag: String) {
        guard !tag.isEmpty else {
            saveTags(self)
            return
        }

        guard !tags.contains(tag) else { return }

        if allowsCreation || allTagsStrings.contains(tag) {
            tags.append(tag)
        }

        searchText = ""

        filterTags(text: searchText)
        searchTableView.reloadData()
        tagsCollectionView.reloadData()
        tagsCollectionView.layoutIfNeeded()
        focusInput()
    }

    func filterTags(text: String) {
        searchText = text.lowercased()

        let currentTags = tags.map { $0.lowercased() }.joined(separator: "~")
        filteredTags = allTags.filter { !"~\(currentTags)~".contains("~\($0.name.lowercased())~") }

        if !searchText.isEmpty {
            filteredTags = filteredTags.filter { $0.name.lowercased().contains(searchText) }
        }

        searchTableView.reloadData()
    }
}

extension ThoughtTagsView: TagCellDelegate {
    func delete(tag: String) {
        tags = tags.filter { $0 != tag }
        filterTags(text: searchText)
        searchTableView.reloadData()
        tagsCollectionView.reloadData()
        tagsCollectionView.layoutIfNeeded()
        focusInput()
    }
}
