//
//  ExportCompletionModalView.swift
//  transom
//
//  Created by Roma Sosnovsky on 09/03/21.
//  Copyright © 2021 Void Digital. All rights reserved.
//

import UIKit

protocol ExportCompletionDelegate: AnyObject {
    func goToHome()
    func goToNewExport()
}

class ExportCompletionModalView: UIView {
    @IBOutlet var view: UIView!

    weak var delegate: ExportCompletionDelegate?
    
    override init(frame: CGRect) {
        super.init(frame: frame)

        setupView()
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)

        setupView()
    }

    private func setupView() {
        Bundle.main.loadNibNamed("ExportCompletionModalView", owner: self, options: nil)

        guard let view = view else { return }

        view.layer.cornerRadius = 6
        view.clipsToBounds = true
        view.frame = bounds
        view.autoresizingMask = [.flexibleHeight, .flexibleWidth]
        addSubview(view)
    }
    
    // MARK: - IBActions
    @IBAction func backToExport() {
        delegate?.goToNewExport()
    }
    
    @IBAction func showHome() {
        delegate?.goToHome()
    }
    
}
