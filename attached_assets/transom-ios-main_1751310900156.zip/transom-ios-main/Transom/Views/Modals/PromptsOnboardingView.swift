//
//  PromptsOnboardingView.swift
//  transom
//
//  Created by Roma Sosnovsky on 16/06/21.
//  Copyright © 2021 Void Digital. All rights reserved.
//

import UIKit

protocol PromptsOnboardingDelegate: AnyObject {
    func closePromptsOnboarding()
}

class PromptsOnboardingView: UIView {
    @IBOutlet var view: UIView!

    weak var delegate: PromptsOnboardingDelegate?
    
    init(frame: CGRect, delegate: PromptsOnboardingDelegate) {
        super.init(frame: frame)

        self.delegate = delegate
        
        setupView()
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)

        setupView()
    }

    private func setupView() {
        Bundle.main.loadNibNamed("PromptsOnboardingView", owner: self, options: nil)

        guard let view = view else { return }

        view.layer.cornerRadius = 6
        view.clipsToBounds = true
        view.frame = bounds
        view.autoresizingMask = [.flexibleHeight, .flexibleWidth]
        addSubview(view)
    }

    // MARK: - IBActions
    @IBAction private func close() {
        delegate?.closePromptsOnboarding()
    }
}

