//
//  ProjectModalView.swift
//  transom
//
//  Created by Roma Sosnovsky on 9/4/19.
//  Copyright © 2019 Void Digital. All rights reserved.
//

import UIKit

protocol ProjectModalDelegate: AnyObject {
    func didChange(tag: FBTag)
    func didDelete(tag: FBTag)
    func closeProjectModal(message: String?)
}

class ProjectModalView: UIView {
    @IBOutlet var view: UIView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var messageLabel: UILabel!
    @IBOutlet weak var textField: UITextField!
    @IBOutlet weak var cancelButton: UIButton!
    @IBOutlet weak var saveButton: UIButton!

    private var fbTag: FBTag?
    private var thought: FBThought?
    private var modalType: ModalType = .newProject

    weak var delegate: ProjectModalDelegate?

    override init(frame: CGRect) {
        super.init(frame: frame)

        setupView()
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)

        setupView()
    }

    override func prepareForInterfaceBuilder() {
        super.prepareForInterfaceBuilder()

        setupView()
    }

    private func setupView() {
        Bundle.main.loadNibNamed("ProjectModalView", owner: self, options: nil)

        guard let view = view else { return }

        view.layer.cornerRadius = 6
        view.frame = bounds
        view.autoresizingMask = [.flexibleHeight, .flexibleWidth]
        addSubview(view)

        textField.delegate = self
    }

    func setup(type: ModalType) {
        modalType = type
        titleLabel.text = type.title
        messageLabel.text = type.message

        if type.message != nil {
            textField.isHidden = true
        } else {
            messageLabel.isHidden = true
        }

        switch type {
        case .deleteThought, .deleteProject, .deleteTag, .unarchiveThought:
            saveButton.setTitle("Yes, do it.", for: .normal)
            cancelButton.setTitle("No, don't.", for: .normal)
        default:
            break
        }
    }

    func setup(tag: FBTag) {
        self.fbTag = tag
        textField.text = tag.name
    }

    func setup(thought: FBThought) {
        self.thought = thought
    }

    func startEditing() {
        guard modalType.message == nil else { return }
        textField.becomeFirstResponder()
    }

    // MARK: - IBActions
    @IBAction func save(_ sender: Any) {
        var message: String? = nil
        switch modalType {
        case .newProject, .newTag:
            guard let name = textField.text?.trimmingCharacters(in: .whitespacesAndNewlines), !name.isEmpty else { return }

            if modalType == .newTag {
                FBTag.createTag(name: name, isProject: false, completion: nil)
                message = "Tag Created"
            } else if modalType == .newProject {
                FBTag.createProject(name: name)
                message = "Project Created"
            }
        case .editProject, .editTag:
            guard var fbTag = fbTag, let name = textField.text?.trimmingCharacters(in: .whitespacesAndNewlines), !name.isEmpty else { return }
            fbTag.changeName(to: name)
            delegate?.didChange(tag: fbTag)
            message = modalType == .editProject ? "Project Name Updated" : "Tag Name Updated"
        case .deleteProject, .deleteTag:
            guard let fbTag = fbTag else { return }
            fbTag.delete()
            delegate?.didDelete(tag: fbTag)
            message = modalType == .deleteProject ? "Project Deleted" : "Tag Deleted"
        case .deleteThought:
            if let prompt = thought?.prompt {
                PromptsService.shared.add(prompt: prompt, packId: thought?.promptPackId)
            }
            thought?.delete()
            message = "Thought Deleted"
        case .unarchiveThought:
            thought?.isArchived = false
            message = "Thought Unarchived"
        }

        view.endEditing(true)
        delegate?.closeProjectModal(message: message)
    }

    @IBAction func cancel(_ sender: Any) {
        view.endEditing(true)
        delegate?.closeProjectModal(message: nil)
    }
}

// MARK: - UITextFieldDelegate
extension ProjectModalView: UITextFieldDelegate {
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        guard let textFieldText = textField.text,
              let rangeOfTextToReplace = Range(range, in: textFieldText) else {
                return false
        }

        let substringToReplace = textFieldText[rangeOfTextToReplace]
        let count = textFieldText.count - substringToReplace.count + string.count

        let textLimit: Int

        switch modalType {
        case .newTag, .editTag:
            textLimit = 20
        default:
            textLimit = 28
        }

        return count <= textLimit
    }
}
