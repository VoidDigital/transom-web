//
//  DailyNotificationsModalView.swift
//  transom
//
//  Created by Roma Sosnovsky on 30.08.2020.
//  Copyright © 2020 Void Digital. All rights reserved.
//

import UIKit

protocol DailyNotificationsModalDelegate: AnyObject {
    func enableDailyNotifications()
    func closeDailyNotificationsModal(handler: (() -> Void)?)
}

class DailyNotificationsModalView: UIView {
    @IBOutlet var view: UIView!

    weak var delegate: DailyNotificationsModalDelegate?
    
    override init(frame: CGRect) {
        super.init(frame: frame)

        setupView()
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)

        setupView()
    }

    private func setupView() {
        Bundle.main.loadNibNamed("DailyNotificationsModalView", owner: self, options: nil)

        guard let view = view else { return }

        view.layer.cornerRadius = 6
        view.clipsToBounds = true
        view.frame = bounds
        view.autoresizingMask = [.flexibleHeight, .flexibleWidth]
        addSubview(view)
    }

    // MARK: - IBActions
    @IBAction private func approveNotifications(_ sender: Any) {
        delegate?.enableDailyNotifications()
    }

    @IBAction private func cancel(_ sender: Any) {
        UserDefaults.updateDailyWordReminders(isEnabled: false)
        delegate?.closeDailyNotificationsModal(handler: nil)
    }
}

