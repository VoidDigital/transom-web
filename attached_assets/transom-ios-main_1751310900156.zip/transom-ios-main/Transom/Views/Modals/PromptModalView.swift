//
//  PromptModalView.swift
//  transom
//
//  Created by Roma Sosnovsky on 17/06/21.
//  Copyright © 2021 Void Digital. All rights reserved.
//

import UIKit

protocol PromptsModalDelegate: AnyObject {
    func didSelect(prompt: String, promptPackId: String?)
    func shouldHidePromptsModal()
}

class PromptsModalView: UIView {
    @IBOutlet private var view: UIView!
    @IBOutlet private weak var promptLabel: UILabel!
    @IBOutlet private weak var skipButton: UIButton!
    @IBOutlet private weak var useButton: UIButton!
    
    private weak var delegate: PromptsModalDelegate?
    
    private var pack: PromptPack?
    private let promptsService = PromptsService.shared
    
    init(frame: CGRect, delegate: PromptsModalDelegate, pack: PromptPack) {
        super.init(frame: frame)

        self.delegate = delegate
        self.pack = pack
        
        setupView()
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)

        setupView()
    }

    private func setupView() {
        Bundle.main.loadNibNamed("PromptsModalView", owner: self, options: nil)

        guard let view = view else { return }

        view.layer.cornerRadius = 30
        view.clipsToBounds = true
        view.frame = bounds
        view.autoresizingMask = [.flexibleHeight, .flexibleWidth]
        addSubview(view)
        
        setupButtons()
        showNextPrompt()
    }
    
    private func setupButtons() {
        [skipButton, useButton].forEach {
            $0?.layer.borderColor = UIColor.white.cgColor
            $0?.layer.borderWidth = 2
            $0?.layer.cornerRadius = 8
            $0?.setBackgroundImage(UIImage.imageWithColor(color: UIColor(red: 2/255, green: 116/255, blue: 205/255, alpha: 1)), for: .highlighted)
        }
    }
    
    private func showNextPrompt() {
        guard let pack = pack else { return }
        promptLabel.text = promptsService.getPrompt(from: pack)
    }

    // MARK: - IBActions
    @IBAction private func closeModal() {
        delegate?.shouldHidePromptsModal()
    }
    
    @IBAction private func skipPrompt() {
        showNextPrompt()
    }
    
    @IBAction private func usePrompt() {
        delegate?.didSelect(prompt: promptLabel.text ?? "", promptPackId: pack?.id)
    }
}

