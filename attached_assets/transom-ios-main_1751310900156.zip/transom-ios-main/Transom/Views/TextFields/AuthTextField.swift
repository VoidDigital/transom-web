//
//  AuthTextField.swift
//  transom
//
//  Created by Roma Sosnovsky on 9/23/19.
//  Copyright © 2019 Void Digital. All rights reserved.
//

import UIKit

protocol AuthTextFieldDelegate: AnyObject {
    func didEndEditing(textField: AuthTextField)
}

class AuthTextField: UIView {
    @IBOutlet var view: UIView!
    @IBOutlet weak var placeholderLabel: UILabel!
    @IBOutlet weak var placeholderLabelCenterY: NSLayoutConstraint!
    @IBOutlet weak var textField: UITextField!

    private weak var delegate: AuthTextFieldDelegate?

    override init(frame: CGRect) {
        super.init(frame: frame)

        setupView()
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)

        setupView()
    }

    private func setupView() {
        Bundle.main.loadNibNamed("AuthTextField", owner: self, options: nil)

        guard let view = view else { return }

        view.clipsToBounds = true
        view.isUserInteractionEnabled = true
        view.frame = bounds
        view.autoresizingMask = [.flexibleHeight, .flexibleWidth]
        addSubview(view)

        textField.delegate = self

        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(startEditing))
        view.addGestureRecognizer(tapGesture)
    }

    var text: String? {
        return textField.text
    }

    func setup(placeholder: String?, keyboardType: UIKeyboardType, isSecureTextEntry: Bool, returnKeyType: UIReturnKeyType, delegate: AuthTextFieldDelegate) {
        self.delegate = delegate

        placeholderLabel.text = placeholder

        textField.keyboardType = keyboardType
        textField.isSecureTextEntry = isSecureTextEntry
        textField.returnKeyType = returnKeyType
    }

    @objc func startEditing() {
        textField.becomeFirstResponder()
    }
}

extension AuthTextField: UITextFieldDelegate {
    func textFieldDidBeginEditing(_ textField: UITextField) {
        UIView.animate(withDuration: 0.6, delay: 0, usingSpringWithDamping: 1, initialSpringVelocity: 1, options: .curveEaseOut, animations: {
            self.placeholderLabelCenterY.constant = -12
            self.placeholderLabel.textColor = UIColor(red: 171/255, green: 171/255, blue: 171/255, alpha: 1)
            self.placeholderLabel.font = UIFont.systemFont(ofSize: 11)
            self.layoutIfNeeded()
        }, completion: nil)
    }

    func textFieldDidEndEditing(_ textField: UITextField) {
        guard let text = textField.text, text.isEmpty else { return }

        UIView.animate(withDuration: 0.6, delay: 0, usingSpringWithDamping: 1, initialSpringVelocity: 1, options: .curveEaseOut, animations: {
            self.placeholderLabelCenterY.constant = 0
            self.placeholderLabel.textColor = UIColor(named: "Settings Button Text")
            self.placeholderLabel.font = UIFont.systemFont(ofSize: 16)
            self.layoutIfNeeded()
        }, completion: nil)
    }

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        delegate?.didEndEditing(textField: self)
        return true
    }
//
//extension AuthTextField: UITextFieldDelegate {
//
//  func textFieldShouldReturn(_ textField: UITextField) -> Bool {
//    return textField.resignFirstResponder()
//  }
//
//  func textFieldDidBeginEditing(_ textField: UITextField) {
//    usernameLabelYAnchorConstraint.constant = -25
//    usernameLabelLeadingAnchor.constant = 0
//    performAnimation(transform: CGAffineTransform(scaleX: 0.8, y: 0.8))
//  }
//
//  func textFieldDidEndEditing(_ textField: UITextField) {
//    if let text = textField.text, text.isEmpty {
//      usernameLabelYAnchorConstraint.constant = 0
//      usernameLabelLeadingAnchor.constant = 5
//      performAnimation(transform: CGAffineTransform(scaleX: 1, y: 1))
//    }
//  }
//
//  fileprivate func performAnimation(transform: CGAffineTransform) {
//    UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 1, initialSpringVelocity: 1, options: .curveEaseOut, animations: {
//      self.usernameLBL.transform = transform
//      self.layoutIfNeeded()
//    }, completion: nil)
//  }

}
