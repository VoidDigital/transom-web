//
//  ListItemTableViewCell.swift
//  transom
//
//  Created by Roma Sosnovsky on 8/23/19.
//  Copyright © 2019 Void Digital. All rights reserved.
//

import UIKit

class ListItemTableViewCell: UITableViewCell {
    @IBOutlet private weak var topBorderView: UIView!
    @IBOutlet private weak var contentLabel: UILabel!
    @IBOutlet private weak var countLabel: UILabel!
    @IBOutlet private weak var countLabelWidth: NSLayoutConstraint!

    override func awakeFromNib() {
        super.awakeFromNib()

        selectionStyle = .none
    }

    func setTopBorderView(isHidden: Bool) {
        topBorderView.isHidden = isHidden
    }

    func setup(thought: FBThought) {
        contentLabel.text = thought.plainText
        countLabelWidth.constant = 0
    }

    func setup(tag: FBTag) {
        let count = FirebaseService.shared.thoughts(for: tag).count
        contentLabel.text = tag.name
        countLabelWidth.constant = count > 9 ? 30 : 22
        countLabel.text = "\(count)"
    }
}
