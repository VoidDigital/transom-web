//
//  SettingsTableViewCell.swift
//  transom
//
//  Created by Roma Sosnovsky on 03.08.2020.
//  Copyright © 2020 Void Digital. All rights reserved.
//

import UIKit

class SettingsTableViewCell: UITableViewCell {
    @IBOutlet weak var menuItemLabel: UILabel!
    @IBOutlet weak var menuItemDescriptionLabel: UILabel!
    @IBOutlet weak var menuItemImageView: UIImageView!
    @IBOutlet weak var menuItemImageWidth: NSLayoutConstraint!
    @IBOutlet weak var menuItemImageHeight: NSLayoutConstraint!
    @IBOutlet weak var menuItemImageMarginRight: NSLayoutConstraint!
    
    override func awakeFromNib() {
        super.awakeFromNib()

        selectionStyle = .none
    }

    func setup(label: String, description: String? = nil, imageName: String, imageSize: CGSize, imageMargin: CGFloat) {
        menuItemLabel.text = label
        menuItemDescriptionLabel.text = description
        menuItemImageView.image = UIImage(named: imageName)
        menuItemImageWidth.constant = imageSize.width
        menuItemImageHeight.constant = imageSize.height
        menuItemImageMarginRight.constant = imageMargin
    }
    
}
