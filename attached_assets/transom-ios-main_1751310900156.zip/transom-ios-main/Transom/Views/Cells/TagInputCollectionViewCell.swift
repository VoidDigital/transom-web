//
//  TagInputCollectionViewCell.swift
//  transom
//
//  Created by Roma Sosnovsky on 9/19/19.
//  Copyright © 2019 Void Digital. All rights reserved.
//

import UIKit

protocol TagInputCellDelegate: AnyObject {
    func add(tag: String)
    func filterTags(text: String)
}

class TagInputCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var inputTextField: UITextField!

    weak var delegate: TagInputCellDelegate?

    override func awakeFromNib() {
        super.awakeFromNib()

        inputTextField.delegate = self
    }

    func startEditing() {
        inputTextField.becomeFirstResponder()
    }

    func update(text: String, placeholder: String) {
        inputTextField.text = text
        inputTextField.placeholder = placeholder
    }
}

extension TagInputCollectionViewCell: UITextFieldDelegate {
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if let text = textField.text, let textRange = Range(range, in: text) {
            let updatedText = text.replacingCharacters(in: textRange, with: string)
            delegate?.filterTags(text: updatedText)
        }

        return true
    }

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if let tag = textField.text?.trimmingCharacters(in: .whitespacesAndNewlines) {
            inputTextField.text = ""
            delegate?.add(tag: tag)
        }

        return true
    }
}
