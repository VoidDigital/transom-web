//
//  TagTableViewCell.swift
//  transom
//
//  Created by Roma Sosnovsky on 9/18/19.
//  Copyright © 2019 Void Digital. All rights reserved.
//

import UIKit

class TagTableViewCell: UITableViewCell {
    @IBOutlet weak var tagLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()

        selectionStyle = .none
    }

    func setup(tag: FBTag) {
        tagLabel.text = tag.name
    }
}
