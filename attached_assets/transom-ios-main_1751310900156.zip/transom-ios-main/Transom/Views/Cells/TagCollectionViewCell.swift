//
//  TagCollectionViewCell.swift
//  transom
//
//  Created by Roma Sosnovsky on 9/19/19.
//  Copyright © 2019 Void Digital. All rights reserved.
//

import UIKit

protocol TagCellDelegate: AnyObject {
    func delete(tag: String)
}

class TagCollectionViewCell: UICollectionViewCell {
    @IBOutlet private weak var wrapView: UIView!
    @IBOutlet private weak var tagLabel: UILabel!
    @IBOutlet private weak var deleteButton: UIButton!

    weak var delegate: TagCellDelegate?

    override func awakeFromNib() {
        super.awakeFromNib()

        contentView.isUserInteractionEnabled = false
        wrapView.layer.cornerRadius = 4
    }

    func setup(tag: String) {
        tagLabel.text = tag
    }

    // MARK: - IBActions
    @IBAction func deleteTag(_ sender: Any) {
        delegate?.delete(tag: tagLabel.text!)
    }
}
