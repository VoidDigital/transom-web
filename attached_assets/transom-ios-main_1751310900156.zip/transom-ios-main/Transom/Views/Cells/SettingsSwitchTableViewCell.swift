//
//  SettingsSwitchTableViewCell.swift
//  transom
//
//  Created by Roma Sosnovsky on 26.08.2020.
//  Copyright © 2020 Void Digital. All rights reserved.
//

import UIKit

protocol SettingsSwitchDelegate: AnyObject {
    func onSwitchChanged(value: Bool)
}

class SettingsSwitchTableViewCell: UITableViewCell {
    @IBOutlet private weak var cellSwitch: UISwitch!

    weak var delegate: SettingsSwitchDelegate?

    func updateSwitch(isOn: Bool) {
        cellSwitch.isOn = isOn
    }

    // MARK: - IBActions
    @IBAction private func onSwitchChanged(_ sender: UISwitch) {
        delegate?.onSwitchChanged(value: sender.isOn)
    }

}
