//
//  AlertMessageText.swift
//  transom
//
//  Created by Gregg Goldner on 10/26/17.
//  Copyright © 2017 Two Sun Traders. All rights reserved.
//

import Foundation

struct AlertMessageText {
    var title: String
    var description: String? = nil
    var yesTitle: String? = nil
    var noTitle: String? = nil
    
    init(title: String, description: String? = nil, yesTitle: String? = nil, noTitle: String? = nil) {
        self.title = title
        self.description = description
        self.yesTitle = yesTitle
        self.noTitle = noTitle
    }
}

extension AlertMessageText {
    static var yesNo: AlertMessageText {
        return AlertMessageText(title: "Are you sure...", yesTitle: "Yes, I'm sure.", noTitle: "No! Go back.")
    }
    
    static func waitASec(withDescription description: String) -> AlertMessageText {
        var yesNo: AlertMessageText = .yesNo
        yesNo.title = "Wait a sec..."
        yesNo.description = description
        return yesNo
    }
}
