//
//  FirebaseCloud.swift
//
//  Created by Gregg Goldner on 6/28/17.
//  Copyright © 2017 Two Sun Traders. All rights reserved.
//

import UIKit

import Firebase
import FirebaseCore
import FirebaseAuth
import FirebaseDatabase

//import NeonSineModel

let cloudDataGlobalChangedNotificationKey = "cloudDataGlobalChangedNotificationKey"
let cloudDataChangedNotificationKey = "cloudDataChangedNotificationKey"

public class FirebaseCloud {
    var globalDictionary: [String: Any] = [:]
    var userDictionary: [String: Any] = [:]

    private var baseRef: DatabaseReference!
    private var userRef: DatabaseReference? {

        guard let userID : String = (Auth.auth().currentUser?.uid) else {
            return nil
        }

        let userKeys = ["users", userID]
        return FirebaseCloud.buildRef(fromBase: baseRef, keys: userKeys)
    }
    private var globalRef: DatabaseReference {
        let globalKeys = ["Locations"]
        return FirebaseCloud.buildRef(fromBase: baseRef, keys: globalKeys)
    }

    private var refGlobalHandle: UInt!
    private var refUserHandle: UInt?

    public var uniqueForUser: String? {
        didSet {
            guard let _ = uniqueForUser else { return }

            refUserHandle = userRef?.observe( .value, with: { [weak self] snapshot in
                let newDictionary = snapshot.value as? [String : AnyObject] ?? [:]
                self?.addNewValues(toDictionary: newDictionary, isGlobal: false)
                NotificationCenter.default.post(name: Notification.Name(rawValue: cloudDataChangedNotificationKey), object: true)
            })
        }
    }
    public var cloudDataChanged: (() -> (Bool))?

    // MARK: - Init
    public init() {

        UIApplication.shared.registerForRemoteNotifications()

        FirebaseConfiguration.shared.setLoggerLevel(.min)
        FirebaseApp.configure()
        Database.database().isPersistenceEnabled = true

        baseRef = Database.database().reference()
        refGlobalHandle = globalRef.observe( .value, with: { [weak self] snapshot in
            let newDictionary = snapshot.value as? [String : AnyObject] ?? [:]
            self?.addNewValues(toDictionary: newDictionary, isGlobal: true)
            NotificationCenter.default.post(name: Notification.Name(rawValue: cloudDataGlobalChangedNotificationKey), object: true)
        })
    }

    // MARK: - Cloud CRUD
    public func create(keyPairs: [String: Any], forStorageKeys storageKeys: [String], isGlobal: Bool) {
        guard let userRef = userRef else { return }
        let ref = (isGlobal) ? globalRef : userRef
        let refToSetValue = FirebaseCloud.buildRef(fromBase: ref, keys: storageKeys)

        var updatedDictionary = read(forStorageKeys: storageKeys, isGlobal: isGlobal)
        for key in keyPairs.keys {
            updatedDictionary[key] = keyPairs[key]
        }

        refToSetValue.setValue(updatedDictionary)
    }

    public func read(keys: [String]? = nil, forStorageKeys storageKeys: [String]?, isGlobal: Bool) -> [String: Any] {
        let dictionaryType = (isGlobal) ? globalDictionary : userDictionary
        guard let storageKeys = storageKeys else {
            return dictionaryType // return whole dictionary
        }

        let storageDictionary = storageKeys.reduce(dictionaryType) { buildDict, storageKey -> [String: Any] in
            return buildDict[storageKey] as? [String: Any] ?? [:]
        }

        guard let keys = keys else {
            return storageDictionary // return whole dictionary
        }

        // return only supplied keys
        var returnValues: [String: Any] = [:]
        for key in keys {
            if let value = storageDictionary[key] {
                returnValues[key] = value
            }
        }
        return returnValues
    }

    public func update(keyPairs: [String: Any], forStorageKeys storageKeys: [String], isGlobal: Bool) {
        guard let userRef = userRef else { return }
        let ref = (isGlobal) ? globalRef : userRef
        let refToSetValue = FirebaseCloud.buildRef(fromBase: ref, keys: storageKeys)
        refToSetValue.updateChildValues(keyPairs)
    }

    public func delete(keys: [String], forStorageKeys storageKeys: [String], isGlobal: Bool) {
        guard let userRef = userRef else { return }
        let ref = (isGlobal) ? globalRef : userRef
        let refToSetValue = FirebaseCloud.buildRef(fromBase: ref, keys: storageKeys)

        var updatedDictionary = read(forStorageKeys: storageKeys, isGlobal: isGlobal)
        for key in keys {
            updatedDictionary[key] = nil
        }

        refToSetValue.setValue(updatedDictionary)
    }

    // MARK: -
    public func userLogedOut() {
        guard let refUserHandle = refUserHandle else { return }
        userRef?.removeObserver(withHandle: refUserHandle)
        self.refUserHandle = nil

        userDictionary = [:]
    }

}

extension FirebaseCloud {
    static func buildRef(fromBase base: DatabaseReference, keys: [String]) -> DatabaseReference {
        return keys.reduce(base) { buildRef, storageKey -> DatabaseReference in
            buildRef.child(storageKey)
        }
    }
}

extension FirebaseCloud {
    func addNewValues(toDictionary newDictionary: [String: Any], isGlobal: Bool) {
        for (key,value) in newDictionary {
            if isGlobal {
                self.globalDictionary[key] = value
            } else {
                self.userDictionary[key] = value
            }
        }
    }
}
