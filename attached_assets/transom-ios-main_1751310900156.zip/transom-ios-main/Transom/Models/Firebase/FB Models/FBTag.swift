//
//  Tag.swift
//  Transom
//
//  Created by Gregg Goldner on 2/2/17.
//  Copyright © 2017 Two Sun Traders. All rights reserved.
//

import Foundation
import FirebaseAuth
import FirebaseDatabase

struct FBTag {
    
    // MARK: -
    static var tagRef: DatabaseReference? {
        guard let uid = Auth.auth().currentUser?.email else { return nil } // fatalError("Should always have a user here") }
        
        let userReference = Database.database().reference(withPath: uid.makeFirebaseString())
        let internalTagsRef = userReference.child("tags")
        return internalTagsRef
    }

    
    // MARK: - Properties
    private(set) var name: String
    private(set) var isPiece = false
    private(set) var createdAt: TimeInterval? //  = Date().timeIntervalSince1970 * 1_000 //?
    private(set) var updatedAt: TimeInterval? //  = Date().timeIntervalSince1970 * 1_000 //?
    private var _itemRef: DatabaseReference?
    private var _itemKey: String?

    var itemKey: String {
        guard let _itemKey = _itemKey else {
            return name.lowercased().makeFirebaseString()
        }
        return _itemKey
    }
    
    var itemRef: DatabaseReference? {
        guard let _itemRef = _itemRef else {
            return FBTag.tagRef?.child(name.lowercased().makeFirebaseString())
        }
        return _itemRef
    }

    var typeName: String {
        return isPiece ? "Project" : "Tag"
    }
    
    // MARK: - Init
    init() {
        self.name = ""
    }
    
    init(name: String, createdAt: TimeInterval, isPiece: Bool = false) {
        self.name = name
        self.isPiece = isPiece
        self.createdAt = createdAt // Date().timeIntervalSince1970 * 1_000 // Firebase server is in Milliseconds
        self.updatedAt = createdAt
        
        
//        itemRef?.updateChildValues(ServerValue.createdAt)
        
//        itemRef.setValue( self.toAnyObject() )
    }
    
    init(snapshot: DataSnapshot) {
        _itemKey = snapshot.key
        guard let snapshotValue = snapshot.value as? [String: AnyObject] else {
            name = "NO DATA---"
            isPiece = false
//            itemRef = nil
            
            return
        }
        name = snapshotValue["name"] as? String ?? ""//"No NAME"
        isPiece = snapshotValue["isPiece"] as? Bool ?? false
        _itemRef = snapshot.ref
        
        // Created at
        if let timeStamp = snapshotValue["createdAt"] as? TimeInterval {
            createdAt = timeStamp
        }
        if let timeStamp = snapshotValue["updatedAt"] as? TimeInterval {
            updatedAt = timeStamp
        }
    }

    // MARK: - Update methods
    mutating func update(name: String, isPiece: Bool) {
        self.name = name
        guard let currentRef = FBTag.tagRef?.child(itemKey) else { return }
        currentRef.updateChildValues([ "name" : name, "isPiece": isPiece ])
        if let createdAt = createdAt {
            currentRef.updateChildValues([ "createdAt" : createdAt ])
        }
//            currentRef.updateChildValues(ServerValue.createdAt)
    }
    
    mutating func update(isPiece: Bool) {
        guard let currentRef = FBTag.tagRef?.child(itemKey) else { return }
        currentRef.updateChildValues([ "isPiece" : isPiece ])
        if let createdAt = createdAt {
            currentRef.updateChildValues([ "createdAt" : createdAt ])
        }
//            currentRef.updateChildValues(ServerValue.createdAt)
    }
    
//    mutating func update(createdAt: TimeInterval) {
//        guard let currentRef = FBTag.tagRef?.child(name) else { return }
//        currentRef.updateChildValues([ "createdAt" : createdAt ])
//    }

    // MARK: - To Any Object
    func toAnyObject() -> Any {
        return [
            "name": name,
            "isPiece": isPiece,
            "createdAt": createdAt ?? 0
        ]
    }
}

extension FBTag {

    static func createTag(name: String, isProject: Bool, completion: ((FBTag) -> Void)?) {
        doesTagExist(withText: name) { existingTag in
            if let existingTag = existingTag {
                completion?(existingTag)
            } else {
                let tag = FBTag(name: name, createdAt: Date().timeIntervalSince1970 * 1_000, isPiece: isProject)
                tag.itemRef?.setValue( tag.toAnyObject() )
                completion?(tag)
            }
        }
    }

    static func createProject(name: String) {
        let piece = FBTag(name: name, createdAt: Date().timeIntervalSince1970 * 1_000, isPiece: true)
        FBTag.tagRef?.child(name.lowercased().makeFirebaseString() ).setValue( piece.toAnyObject() )
    }
    
    /*
    mutating func update(withName name: String) {
        updateName(name)
//        name = updateName
//        itemRef?.setValue( toAnyObject() )
//        itemRef?.updateChildValues(ServerValue.createdAt)
    }
    */
    
    static func getTag(withName getName: String, completion: @escaping (FBTag?) -> ()) {
        let storedTags = FBTagObserver.shared.currentTags
        let foundTag = storedTags.filter { $0.name == getName }.first
        completion( foundTag)
        
//        let tagRef = FBTags.tagsRef().child( getName.lowercased().makeFirebaseString() )
//
//        var handle: UInt = 0
//
//        handle = tagRef.observe(.value, with: { snapshot in
//            //      print("snapshot.value: \(snapshot.value)" )
//
//            completion( FBTag(snapshot: snapshot) )
//            tagRef.removeObserver(withHandle: handle)
//        })
    }
    
    static func getTags(withNames names: [String], completion: @escaping ([FBTag]?) -> ()) {
        // TODO: ---
        
    }
    
    static func doesTagExist(withText tagText: String, completion: @escaping (FBTag?) -> () ) {
        let storedTags = FBTagObserver.shared.currentTags
        let foundTag = storedTags.filter { $0.name == tagText }.first
        completion( foundTag)
        
//        FBTags.tagsRef().observeSingleEvent(of: .value, with: { snapshot in
//            completion( snapshot.hasChild(tagText.lowercased().makeFirebaseString() ) )
//        })
    }
    
}

extension FBTag {
    mutating func changeName(to newName: String?) {
        guard let newName = newName, self.name != newName else { return }

        let isPiece = self.isPiece
        let originalTag = self.name
        let tagThoughts = FBThoughtObserver.shared.allCurrentThoughts.values.filter { $0.tags.contains(self) }

        delete() // remove old tag

        update(name: newName, isPiece: isPiece) // create new one

        for thought in tagThoughts {
            thought.update(oldTag: originalTag, isProject: isPiece, newTag: self)
        }
    }
    
    func delete() {
        
        // blank tag bug
        if name == "" { return }
        itemRef?.removeValue()
        
//          else {
//            FBTag.getTag(withName: self.name) { foundTag in
//                foundTag?.itemRef?.removeValue()
//            }
//        }
        
    }
}

extension FBTag {
    static func combinedTagNamesFrom(tags: Set<FBTag>?) -> String? {
        guard let tags = tags else { return nil }
        let tagNames = tags.map { $0.name }.joined(separator: "~")
        return tagNames
    }
}

extension FBTag: Hashable {
    func hash(into hasher: inout Hasher) {
        hasher.combine(name.hash)
    }
}

func ==(lhs: FBTag, rhs: FBTag) -> Bool {
    return lhs.name.lowercased() == rhs.name.lowercased()
}

extension FBTag: CustomStringConvertible {
    var description: String {
        let typeName = isPiece ? "piece" : "tag"
        return "\n\(typeName) name: \(name)\n itemKey: \(String(describing: itemKey))"
    }
}
