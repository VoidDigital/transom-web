//
//  FBTagObserver.swift
//  Transom
//
//  Created by Gregg Goldner on 2/4/17.
//  Copyright © 2017 Two Sun Traders. All rights reserved.
//

import Foundation

final class FBTagObserver {
    static let shared = FBTagObserver()
    private init() {} //This prevents others from using the default '()' initializer for this class.
    
    private(set) var allCurrentTags: [String: FBTag] = [:]
    
    var currentPieces: [FBTag] {
        return currentTagsAndPieces.filter { $0.isPiece == true }
    }
    var currentTags: [FBTag] {
        return currentTagsAndPieces.filter { $0.isPiece == false }
    }
    var currentTagsAndPieces: [FBTag] {
        return Array(allCurrentTags.values)
    }

    func observerTags(completion: @escaping ([String:FBTag]?) -> ()) {
        
        FBTag.tagRef?
//            .queryOrdered(byChild: "createdAt")
            .observe(.value, with: { [weak self] snapshot in
                //      print("snapshot.value: \(snapshot.value)" )
                
                guard let dictionary = snapshot.value as? [String: Any] else { completion(nil); return }
                
                var buildDict: [String:FBTag] = [:]
                for (key, _ ) in dictionary {
                    let tagDict = dictionary[key] as? [String: Any]
                    let name = tagDict?["name"] as? String ?? ""
                    let isPiece = tagDict?["isPiece"] as? Bool ?? false
                    let createdAt = tagDict?["createdAt"] as? TimeInterval ?? 0

                    let fbTag = FBTag(name: name, createdAt: createdAt, isPiece: isPiece)
                    buildDict[name] = fbTag
                }
                self?.allCurrentTags = buildDict
                completion(buildDict)
            })
    }
    
    func clearCache() {
        allCurrentTags = [:]
    }
    
}
