//
//  FBThought.swift
//  Transom
//
//  Created by Gregg Goldner on 2/2/17.
//  Copyright © 2017 Two Sun Traders. All rights reserved.
//

import Foundation
import FirebaseAuth
import FirebaseDatabase

class FBThought {
    static var thoughtsRef: DatabaseReference? {
        guard let uid = Auth.auth().currentUser?.email else { return nil } //fatalError("Should always have a user here") }
        let userReference = Database.database().reference(withPath: uid.makeFirebaseString())
        let internalRef = userReference.child("thoughts")
        return internalRef
    }
    
    var text: String {
        didSet {
            guard let currentRef = FBThought.thoughtsRef?.child(itemKey!) else { return }
            currentRef.updateChildValues([ "text" : text ])
            currentRef.updateChildValues(ServerValue.createdAt)
            currentRef.updateChildValues(ServerValue.updatedAt)
            
//            currentRef.updateChildValues([ "wordCount" : text.count ])
        }
    }
    var isArchived = false {
        didSet {
            guard let currentRef = FBThought.thoughtsRef?.child(itemKey!) else { return }
            currentRef.updateChildValues([ "isArchived" : isArchived ])
            currentRef.updateChildValues(ServerValue.createdAt)
            currentRef.updateChildValues(ServerValue.updatedAt)
        }
    }
    
    var createdAt: TimeInterval {
        didSet {
            guard let currentRef = FBThought.thoughtsRef?.child(itemKey!) else { return }
            currentRef.updateChildValues([ "createdAt" : createdAt ])
        }
    }

    var updatedAt: TimeInterval {
        didSet {
            guard let currentRef = FBThought.thoughtsRef?.child(itemKey!) else { return }
            currentRef.updateChildValues([ "updatedAt" : updatedAt ])
        }
    }
    
    var tagNames: String?
    var prompt: String? {
        didSet {
            guard let currentRef = FBThought.thoughtsRef?.child(itemKey!),
                  let prompt = prompt
            else { return }
            currentRef.updateChildValues([ "prompt" : prompt ])
        }
    }
    var promptPackId: String? {
        didSet {
            guard let currentRef = FBThought.thoughtsRef?.child(itemKey!),
                  let promptPackId = promptPackId
            else { return }
            currentRef.updateChildValues([ "promptPackId" : promptPackId ])
        }
    }

    var exportString: NSAttributedString? {
        let textWithStyles: String
        if text.hasPrefix("<!DOCTYPE") {
            textWithStyles = text.replacingOccurrences(of: "font-family: 'SFProDisplay-Regular'", with: "font-family: 'HelveticaNeue'")
                                     .replacingOccurrences(of: "font-family: 'SFProDisplay-Semibold'", with: "font-family: 'HelveticaNeue-Medium'")
                                     .replacingOccurrences(of: "font-size: 18.00px", with: "font-size: 14.00px")
        } else {
            textWithStyles = "<style type='text/css'>body{font:14px 'HelveticaNeue',Helvetica,Arial}</style>\(text)"
        }

        guard let data = textWithStyles.data(using: .utf8) else { return nil }
        return try? NSAttributedString(data: data, options: [.documentType: NSAttributedString.DocumentType.html], documentAttributes: nil)
    }

    var attributedString: NSAttributedString? {
       guard text.hasPrefix("<!DOCTYPE"), let data = text.data(using: .utf8) else { return nil }
       return try? NSAttributedString(data: data, options: [.documentType: NSAttributedString.DocumentType.html], documentAttributes: nil)
    }

    var plainText: String {
        if let attributedString = attributedString {
            return attributedString.string.trimmingCharacters(in: .whitespacesAndNewlines)
        }

        return text.trimmingCharacters(in: .whitespacesAndNewlines)
    }
    
    var exportText: String {
        plainText
            .replacingOccurrences(of: "\r\n", with: "\\n")
            .replacingOccurrences(of: "\r", with: "\\n")
    }
    
    private(set) var tags: Set<FBTag> = []
    
    var projectName: String? { tags.first(where: { $0.isPiece })?.name }
    var tagsList: Set<String> { Set(tags.filter { !$0.isPiece }.map { $0.name }) }
    var tagsListString: String { tagsList.joined(separator: ", ") }
    
    func update(withTags tags: Set<FBTag>) {
        tagNames = FBTag.combinedTagNamesFrom(tags: tags)
        self.tags = tags
        syncTagNamesFromTags(tags)
    }
    
    func addTag(_ tag: FBTag) {
        tags.insert(tag)
        syncTagNamesFromTags(tags)
    }

    func removeTag(_ tag: FBTag, withSync: Bool = true) {
        tags.remove(tag)
        syncTagNamesFromTags(tags)
    }

    func update(oldTag: String, isProject: Bool, newTag: FBTag) {
        tags = tags.filter { $0.name != oldTag || $0.isPiece != isProject }
        tags.insert(newTag)
        syncTagNamesFromTags(tags, withTimestamp: false)
    }

    func contains(tag: FBTag) -> Bool {
        let allTags = tagNames?.lowercased() ?? ""
        return allTags.contains(tag.name.lowercased())
    }
    
    func contains(tagName: String) -> Bool {
        let allTags = tagNames?.lowercased() ?? ""
        return allTags.contains(tagName.lowercased())
    }

    private func syncTagNamesFromTags(_ _tags: Set<FBTag>, withTimestamp: Bool = true) {
        guard let internalTagNames = FBTag.combinedTagNamesFrom(tags: _tags) else { return }

        guard let currentRef = FBThought.thoughtsRef?.child(itemKey!) else { return }
        currentRef.updateChildValues(["tagNames" : internalTagNames])

        if withTimestamp {
            currentRef.updateChildValues(ServerValue.updatedAt)
        }
    }

    
    var itemRef: DatabaseReference?
    var itemKey: String?
    
    init(text: String, isArchived: Bool = false, prompt: String? = nil, promptPackId: String? = nil, tags: Set<FBTag> = [], createdAt: Date = Date(), updatedAt: Date? = nil) {
        self.text = text
        self.prompt = prompt
        self.promptPackId = promptPackId
        self.isArchived = isArchived
        self.tags = tags
        self.tagNames = FBTag.combinedTagNamesFrom(tags: tags)
        self.createdAt = createdAt.timeIntervalSince1970

        let updatedDate = updatedAt ?? createdAt
        self.updatedAt = updatedDate.timeIntervalSince1970
        
//        if let createdAt = createdAt {
//            let currentRef = FBThought.thoughtsRef().child(itemKey!)
//            currentRef.updateChildValues( ServerValue.createdAt(fromDate: createdAt ) )
//        }
    }
    
    init(snapshot: DataSnapshot) {
        itemKey = snapshot.key
        
        let snapshotValue = snapshot.value as! [String: AnyObject]
        text = snapshotValue["text"] as! String
        isArchived = snapshotValue["isArchived"] as! Bool
        prompt = snapshotValue["prompt"] as? String
        promptPackId = snapshotValue["promptPackId"] as? String
        
        // Tags
        tagNames = snapshotValue["tagNames"] as? String
        
        // Created at
        let createdAtTime = snapshotValue["createdAt"] as? TimeInterval ?? Date().timeIntervalSince1970
        createdAt = createdAtTime
        updatedAt = snapshotValue["updatedAt"] as? TimeInterval ?? createdAtTime
        
        //
        itemRef = snapshot.ref

        refreshTags()
    }
    
    init(key: String, snapshotValue: [String: AnyObject]) {
        itemKey = key
        
        text = snapshotValue["text"] as? String ?? ""
        isArchived = snapshotValue["isArchived"] as? Bool ?? false
        prompt = snapshotValue["prompt"] as? String
        promptPackId = snapshotValue["promptPackId"] as? String
        
        // Tags
        tagNames = snapshotValue["tagNames"] as? String

        
        // Created at
        let createdAtTime = snapshotValue["createdAt"] as? TimeInterval ?? Date().timeIntervalSince1970
        createdAt = createdAtTime
        updatedAt = snapshotValue["updatedAt"] as? TimeInterval ?? createdAtTime

        itemRef = FBThought.thoughtsRef?.child(key)

        refreshTags()
    }
    
    
    func refreshTags() {
        tags = FBThought.tagsFrom(combinedTagNames: tagNames)
    }
    
    func delete() {
        itemRef?.removeValue()
    }
    
    // Convert Tags to and from Combined String
    static func tagsFrom(combinedTagNames: String?) -> Set<FBTag> {
        guard let combinedTagNames = combinedTagNames else { return Set<FBTag>() }
        var returnValues: Set<FBTag> = []
        let tagStrings = combinedTagNames.split {$0 == "~"}.map(String.init)
        
        let fbTagObserver = FBTagObserver.shared
        let allCurrentTags = fbTagObserver.allCurrentTags
        
        for tagString in tagStrings {
            
            if let tag = allCurrentTags[tagString] {
                returnValues.insert(tag)
            }
        }
        return returnValues
    }
    
    func toAnyObject() -> Any {
        let tagNames = FBTag.combinedTagNamesFrom(tags: tags) ?? ""
        var dictionary: [String: Any] = ["text": text, "isArchived": isArchived, "tagNames": tagNames]
        
        if let prompt = prompt {
            dictionary["prompt"] = prompt
        }
        if let promptPackId = promptPackId {
            dictionary["promptPackId"] = promptPackId
        }
        
        return dictionary
    }
}

extension FBThought {
    static func createThought(text: String, prompt: String? = nil, promptPackId: String? = nil, tags: [String], projectName: String?, completion: ((FBThought) -> Void)?) {
        let thought = FBThought(text: text, isArchived: false, prompt: prompt, promptPackId: promptPackId)

        guard let thoughtRef = thoughtsRef?.childByAutoId(), let key = thoughtRef.key else { return }
        thought.itemKey = thoughtRef.key
        thoughtRef.setValue( thought.toAnyObject() )
        thought.itemRef = thoughtRef.child(key)
        thoughtRef.updateChildValues(ServerValue.createdAt)

        if let projectName = projectName {
            FBTag.createTag(name: projectName, isProject: true) { tag in
                var tags = thought.tags.filter { !$0.isPiece }
                tags.insert(tag)
                thought.update(withTags: tags)
            }
        }

        if !tags.isEmpty {
            tags.forEach { tag in
                FBTag.createTag(name: tag, isProject: false) { tag in
                    var newTags = thought.tags
                    newTags.insert(tag)
                    thought.update(withTags: newTags)
                }
            }
        }

        completion?(thought)
    }
    
    func update(withText updateText: String, prompt: String?, promptPackId: String?) {
        text = updateText
        self.prompt = prompt
        self.promptPackId = promptPackId
    }
}

extension FBThought: Hashable {
    func hash(into hasher: inout Hasher) {
        hasher.combine(itemKey!.hash)
    }
}

func ==(lhs: FBThought, rhs: FBThought) -> Bool {
    return lhs.hashValue == rhs.hashValue
}

extension FBThought: CustomStringConvertible {
    var description: String {
        let archievedText = isArchived ? "Archived" : "NOT Archived"
        let itemKey = self.itemKey ?? ""
        return "\n\(archievedText) - text: \(text)\n itemKey: \(itemKey)\n tags: \(tags)"
    }
}

extension ServerValue {
    static var createdAt: [String: Any] {
        return ["createdAt": ServerValue.timestamp()]
    }
    
    static func createdAt(fromDate date: Date) -> [String: Any] {
        return ["createdAt": date.timeIntervalSince1970]
    }

    static var updatedAt: [String: Any] {
        return ["updatedAt": ServerValue.timestamp()]
    }

    static func updatedAt(fromDate date: Date) -> [String: Any] {
        return ["updatedAt": date.timeIntervalSince1970]
    }
    
}
