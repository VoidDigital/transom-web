//
//  FBThoughtObserver.swift
//  Transom
//
//  Created by Gregg Goldner on 2/4/17.
//  Copyright © 2017 Two Sun Traders. All rights reserved.
//

import Foundation

final class FBThoughtObserver {
    static let shared = FBThoughtObserver()
    private init() {} //This prevents others from using the default '()' initializer for this class.
    
    private var firebaseHandle: UInt?
    
    var allCurrentThoughts: [String: FBThought] = [:]
    
    var archievedThoughts: [FBThought] {
        return Array(allCurrentThoughts.values).filter { $0.isArchived }
    }
    var currentThoughts: [FBThought] {
        return Array(allCurrentThoughts.values).filter { !$0.isArchived }
    }
    
    func observerThoughts(completion: @escaping ([String:FBThought]?) -> ()) {
        
        firebaseHandle = FBThought.thoughtsRef?
            .observe(.value, with: { [weak self] snapshot in
                guard let strongSelf = self else { return }
                
                strongSelf.allCurrentThoughts = [:]
                
                if let json = snapshot.value as? [String: Any] {
                    for key in json.keys {
                        if let snapshotValue = json[key] as? [String: AnyObject] {
                            let fbThought = FBThought(key: key, snapshotValue: snapshotValue)
                            strongSelf.allCurrentThoughts[key] = fbThought
                        }
                    }
                }
                
                completion(strongSelf.allCurrentThoughts)
            })
 
    }
    
    func thoughts(withTag tag: FBTag) -> Set<FBThought> {
        return Set( allCurrentThoughts.values.filter { $0.tags.contains(tag) } )
    }
    
    func clearCache() {
        allCurrentThoughts = [:]
//        FBThought.thoughtsRef().removeAllObservers()
//        if let firebaseHandle = firebaseHandle {
//            FBThought.thoughtsRef().removeObserver(withHandle: firebaseHandle)
//        }
    }
    
}
