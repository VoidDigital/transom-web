//
//  FirebaseLogin.swift
//  Transom
//
//  Created by Gregg Goldner on 5/10/17.
//  Copyright © 2017 Two Sun Traders. All rights reserved.
//

import Foundation
import FirebaseAuth

struct FirebaseLogin {
    func createUser(email: String, password: String, completion: @escaping ((String?) -> Void)) {
        Auth.auth().createUser(withEmail: email, password: password) { user, error in
            if let error = error {
                completion(error.localizedDescription)
            } else {
                completion(nil)
            }
        }
    }
    func signIn(email: String, password: String, completion: @escaping ((String?) -> Void)) {
        Auth.auth().signIn(withEmail: email, password: password) { user, error in
            if let error = error {
                let nsError = error as NSError
                if nsError.code == 17011 {
                    completion("Sorry, we have no record of an account with that email address.\n\nPlease try again or contact us at help@wearetransom.com.")
                } else {
                    completion(error.localizedDescription)
                }
            } else {
                completion(nil)
            }
        }
    }
    func sendPasswordReset(email: String, completion: @escaping ((String?) -> Void)) {
        Auth.auth().sendPasswordReset(withEmail: email) { error in
            if let error = error {
                completion(error.localizedDescription)
            } else {
                completion(nil)
            }
        }
    }
    
    func signOut(completion: @escaping ((String?) -> Void)) {
        do {
            try Auth.auth().signOut()
            completion(nil)
        } catch let error {
            completion(error.localizedDescription)
        }
    }
    
}
