//
//  ThoughtFont.swift
//  transom
//
//  Created by Roma Sosnovsky on 25.10.2019.
//  Copyright © 2019 Void Digital. All rights reserved.
//

import Foundation

enum ThoughtFont: String, CaseIterable {
    case regular = "SFProDisplay-Regular",
         bold = "SFProDisplay-Semibold",
         italic = "SFProDisplay-RegularItalic",
         boldItalic = "SFProDisplay-SemiboldItalic"
}
