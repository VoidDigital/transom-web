//
//  TagType.swift
//  transom
//
//  Created by Roma Sosnovsky on 9/18/19.
//  Copyright © 2019 Void Digital. All rights reserved.
//

import Foundation

enum TagType: String {
    case tag, project

    var modalTitle: String {
        switch self {
        case .project:
            return "Add to a Project"
        case .tag:
            return "Add Tags"
        }
    }
    
    var exportModalTitle: String { "Select \(rawValue.capitalized)s" }
}
