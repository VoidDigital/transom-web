//
//  PromptsCollection.swift
//  transom
//
//  Created by Roma Sosnovsky on 06/05/21.
//  Copyright © 2021 Void Digital. All rights reserved.
//

import FirebaseFirestoreSwift
import Foundation

struct PromptPack: Identifiable, Codable {
    @DocumentID var id: String?
    let name: String
    let author: String?
    let description: String?
    let price: Int?
    let prompts: [String]
    let isHidden: Bool?
}

extension PromptPack {
    var info: String {
        var string = "\(prompts.count) prompts"
        if let author = author {
            string += " by \(author)"
        }
        return string
    }
    
    var costString: String {
        guard let price = price, price > 0 else {
            return "Free"
        }
        
        let word = price == 1 ? "Credit" : "Credits"
        return "\(price) \(word)"
    }
    
    var isPublished: Bool {
        guard let isHidden = isHidden, isHidden else { return true }
        return false
    }
}
