//
//  ModalType.swift
//  transom
//
//  Created by Roma Sosnovsky on 9/20/19.
//  Copyright © 2019 Void Digital. All rights reserved.
//

import Foundation

enum ModalType {
    case newTag, editTag, newProject, editProject, deleteTag, deleteThought, deleteProject, unarchiveThought

    var title: String {
        switch self {
        case .newTag:
            return "Create a New Tag"
        case .editTag:
            return "Edit Tag"
        case .newProject:
            return "Create a New Project"
        case .editProject:
            return "Edit Project Name"
        case .unarchiveThought:
            return "Restore this thought?"
        default:
            return "Wait a sec..."
        }
    }

    var message: String? {
        switch self {
        case .deleteProject:
            return "Are you sure you want to delete this project? It will be permanently removed from your Projects list, but the Thoughts in this Project will not be otherwise affected."
        case .deleteThought:
            return "Are you sure you want to delete this thought? It will be permanently removed from your Thoughts list."
        case .deleteTag:
            return "Are you sure you want to delete this tag? It will be permanently removed from your Tags list, but the Thoughts with this Tag will not be otherwise affected."
        case .unarchiveThought:
            return "Restoring this Thought will move it back to your main Thoughts view, where you can edit it."
        default:
            return nil
        }
    }
}
