//
//  LoginType.swift
//  transom
//
//  Created by Roma Sosnovsky on 9/18/19.
//  Copyright © 2019 Void Digital. All rights reserved.
//

import Foundation

enum LoginType {
    case new, existing

    var title: String {
        switch self {
        case .new:
            return "Create Account"
        case .existing:
            return "Log In"
        }
    }

    var message: String {
        switch self {
        case .new:
            return "Keep your notes safe & secure with a Transom account."
        case .existing:
            return "Ahoy, writer! Drop your email and password below to get back to writing."
        }
    }
}
