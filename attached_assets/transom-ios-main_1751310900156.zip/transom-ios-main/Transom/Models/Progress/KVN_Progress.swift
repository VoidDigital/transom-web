//
//  KVN_Progress.swift
//  Transom
//
//  Created by Gregg Goldner on 5/10/17.
//  Copyright © 2017 Two Sun Traders. All rights reserved.
//

import Foundation
//import KVNProgress

//class KVN_Progress: Progress {
//
//    // MARK: - Private Properties
//    private var isSpinning = false
//    private var isAnimatingCheckmark = false
//
//    // MARK: - Public API
//    func show(withStatus status: String) {
//        guard !isSpinning else { return }
//        isSpinning = true
//
//        KVNProgress.show(withStatus: status)
//    }
//
//    func showSuccess(withStatus status: String, withCompletion completion: @escaping () -> () ) {
//        guard allowBeginCheckmarkAnimation() else { return }
//
//        KVNProgress.showSuccess(withStatus: status) { [weak self] in
//            self?.resetToDefault()
//            completion()
//        }
//    }
//
//    func showError(withStatus status: String) {
//        guard allowBeginCheckmarkAnimation() else { return }
//
//        KVNProgress.showError(withStatus: status) { [weak self] in
//            self?.resetToDefault()
//        }
//    }
//
//    func stopSpinner() {
//        guard !isAnimatingCheckmark else { return }
//
//        KVNProgress.dismiss { [weak self] in
//            self?.isSpinning = false
//        }
//    }
//
//    func showSuccess(withStatus status: String) {
//        showSuccess(withStatus: status) {}
//    }
//
//    // MARK: - Private Helper Methods
//    private func resetToDefault() {
//        isSpinning = false
//        isAnimatingCheckmark = false
//    }
//
//    private func allowBeginCheckmarkAnimation() -> Bool {
//        guard !isAnimatingCheckmark else { return false }
//        isAnimatingCheckmark = true
//        stopSpinner()
//        return true
//    }
//}
