//
//  Progress.swift
//  Transom
//
//  Created by Gregg Goldner on 5/10/17.
//  Copyright © 2017 Two Sun Traders. All rights reserved.
//

import Foundation

//protocol Progress {
//    func show(withStatus: String)
//    func showSuccess(withStatus: String)
//    func showSuccess(withStatus: String, withCompletion: @escaping () -> () )
//    func showError(withStatus: String)
//    func stopSpinner()
//}

