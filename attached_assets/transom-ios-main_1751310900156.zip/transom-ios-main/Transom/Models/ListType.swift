//
//  ListType.swift
//  transom
//
//  Created by Roma Sosnovsky on 8/23/19.
//  Copyright © 2019 Void Digital. All rights reserved.
//

import Foundation

enum ListType: String {
    case thought, project, tag, archive

    var emptyListMessage: String {
        switch self {
        case .thought, .archive:
            return "Writer’s block? Pshaw! Whatever’s on your mind, tap the pencil below and just start writing."
        case .project:
            return "Working on a novel, poetry collection, or script? Group related Thoughts together in a Project. Tap the folder icon at top right to start a new one."
        case .tag:
            return "Tags help you keep Thoughts organized. Add Tags easily whenever you create a new Thought. Tap the pencil to get started."
        }
    }
}
