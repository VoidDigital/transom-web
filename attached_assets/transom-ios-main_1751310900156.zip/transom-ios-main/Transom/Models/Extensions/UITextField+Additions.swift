//
//  UITextField+Additions.swift
//  transom
//
//  Created by Gregg Goldner on 5/17/18.
//  Copyright © 2018 Two Sun Traders. All rights reserved.
//

import UIKit

extension UITextContentType {
    public static let unspecified = UITextContentType(rawValue: "unspecified")
}
