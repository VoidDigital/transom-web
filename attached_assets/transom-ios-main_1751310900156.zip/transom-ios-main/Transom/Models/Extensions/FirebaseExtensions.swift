//
//  FirebaseExtensions.swift
//  Transom
//
//  Created by Gregg Goldner on 2/6/17.
//  Copyright © 2017 Two Sun Traders. All rights reserved.
//

import Foundation

extension String {
  /*
  func makeFirebaseString() -> String{
//    let arrCharacterToReplace = [".","#","$","[","]"]
    let arrCharacterToReplace = [".","#","$","[","]", ":", "“"]
    var finalString = self
    
    for character in arrCharacterToReplace{
      finalString = finalString.replacingOccurrences(of: character, with: " ")
    }
    
    return finalString
  }
 */

  func makeFirebaseString() -> String {
    var finalString = self
    
    finalString = finalString.replacingOccurrences(of: ".", with: "▦")
    
    finalString = finalString.replacingOccurrences(of: "#", with: "▪")
    finalString = finalString.replacingOccurrences(of: "$", with: "▫")
    finalString = finalString.replacingOccurrences(of: "[", with: "▬")
    finalString = finalString.replacingOccurrences(of: "]", with: "▭")
    finalString = finalString.replacingOccurrences(of: ":", with: "▮")
    finalString = finalString.replacingOccurrences(of: "“", with: "▯")
    
    return finalString
  }
  
  func decodeFirebaseString() -> String {
    var finalString = self
    finalString = finalString.replacingOccurrences(of: "▦", with: ".")
    
    finalString = finalString.replacingOccurrences(of:"▪" , with: "#")
    finalString = finalString.replacingOccurrences(of:"▫" , with: "$")
    finalString = finalString.replacingOccurrences(of:"▬" , with: "[")
    finalString = finalString.replacingOccurrences(of:"▭" , with: "]")
    finalString = finalString.replacingOccurrences(of:"▮" , with: ":")
    finalString = finalString.replacingOccurrences(of:"▯" , with: "“")
    
    return finalString
  }
}
