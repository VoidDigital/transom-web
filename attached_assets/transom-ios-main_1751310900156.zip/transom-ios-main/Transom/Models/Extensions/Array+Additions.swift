//
//  Array+Additions.swift
//  transom
//
//  Created by Gregg Goldner on 10/26/17.
//  Copyright © 2017 Two Sun Traders. All rights reserved.
//

import UIKit

extension Array where Element: Equatable {
  // Remove first collection element that is equal to the given `object`:
  mutating func remove(object: Element) {
    if let index = firstIndex(of: object) {
      remove(at: index)
    }
  }
}
