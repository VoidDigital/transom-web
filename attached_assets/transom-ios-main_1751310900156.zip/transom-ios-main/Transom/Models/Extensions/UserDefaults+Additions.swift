//
//  UserDefaults+Additions.swift
//  Transom
//
//  Created by Gregg Goldner on 5/9/17.
//  Copyright © 2017 Two Sun Traders. All rights reserved.
//

import UIKit

extension UserDefaults {
  // MARK: - Keys
  private static let lastUpdatedDateKey = "lastUpdatedDateKey"
  private static let isNewToPieceUIKey = "isNewToPieceUI"
  private static let isWorksToPieceCompleteKey = "isWorksToPieceComplete"
  
  // MARK: - Properties
  class var lastUpdatedDate: Date {
    get {
      return UserDefaults.standard.object(forKey: lastUpdatedDateKey) as? Date ?? Date()
    }
    set {
      UserDefaults.standard.set(newValue, forKey: lastUpdatedDateKey)
      UserDefaults.standard.synchronize()
    }
  }

  class var isNewToPieceUI: Bool {
    get {
      return !UserDefaults.standard.bool(forKey: isNewToPieceUIKey)
    }
    set {
      UserDefaults.standard.set(!newValue, forKey: isNewToPieceUIKey)
      UserDefaults.standard.synchronize()
    }
  }

  class var isWorksToPieceComplete: Bool {
    get {
      return UserDefaults.standard.bool(forKey: isWorksToPieceCompleteKey)
    }
    set {
      UserDefaults.standard.set(newValue, forKey: isWorksToPieceCompleteKey)
      UserDefaults.standard.synchronize()
    }
  }

}
