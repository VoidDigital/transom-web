//
//  AboutTextType.swift
//  transom
//
//  Created by Roma Sosnovsky on 9/19/19.
//  Copyright © 2019 Void Digital. All rights reserved.
//

import UIKit

enum AboutTextType {
    case about, legal

    var title: String {
        switch self {
        case .about:
            return "Who We Are"
        case .legal:
            return "Legal Schmegal"
        }
    }

    var text: NSMutableAttributedString {
        let paragraphStyle = NSMutableParagraphStyle()
        paragraphStyle.lineSpacing = 3
        paragraphStyle.paragraphSpacing = 10
        let attrs: [NSAttributedString.Key: Any] = [.font: UIFont.systemFont(ofSize: 18), .foregroundColor: UIColor(red: 70/255, green: 70/255, blue: 70/255, alpha: 1), .paragraphStyle: paragraphStyle]

        let string: String
        switch self {
        case .about:
            string = """
            Like You, We're Writers.
            Okay, let’s be honest: we’re hobbyists. You’ll find no cinderblock-sized tomes of great literary accomplishment under our names on Amazon. Or even an ebook. But we do love to write, and we share a common frustration over the lack of simple, cheap, and modern writing tools.

            We’re Also Readers.
            As passionate readers, we wanted to make it easier for writers like you to capture and organize your thoughts on the fly. Our hope is that making writing easier will result in more great books for us to read. (No pressure or anything.)

            And We’re Nerds.
            We’re professional software engineers, experience designers, and product developers. We saw a problem and jumped on the chance to fix it with simple design and modern technology. Transom is a labor of love — you finding use in this little app is the only reason we’re keeping it alive.
            So, hey, thanks for being you.
            """
        case .legal:
            string = """
            General
            The most important thing to know: whatever content you enter into this app is yours, and yours alone. We take no credit or responsibility for, or ownership or, anything you write here. We will not share your content with or sell it to anyone.
            We do use third-party analytics tools to track events, actions, and behavior within the app — this helps us learn how people use the app, and apply that to the next set of changes and features that’ll make Transom that much better.
            By using this application, you agree to Apple’s standard Licensed Application End User License Agreement, which can be read in full here. https://www.apple.com/legal/internet-services/itunes/appstore/dev/stdeula/

            GDPR Stuff
            If you’re in the EU and want your information to be downloaded or deleted, please contact us at https://www.chrissteib.com/contact-transom and we will take care of it ASAP. Cheerio!
            """
        }

        let attributedString = NSMutableAttributedString(string: string, attributes: attrs)
        
        let titles = ["Like You, We're Writers.", "We’re Also Readers.", "And We’re Nerds.", "General", "GDPR Stuff"]
        titles.forEach {
            let range = attributedString.mutableString.range(of: $0)
            attributedString.addAttribute(.font, value: UIFont.systemFont(ofSize: 18, weight: .bold), range: range)
        }

        let links = ["https://www.apple.com/legal/internet-services/itunes/appstore/dev/stdeula/", "https://www.chrissteib.com/contact-transom"]
        links.forEach {
            let range = attributedString.mutableString.range(of: $0)
            attributedString.addAttribute(.link, value: $0, range: range)
        }

        return attributedString
    }
}
