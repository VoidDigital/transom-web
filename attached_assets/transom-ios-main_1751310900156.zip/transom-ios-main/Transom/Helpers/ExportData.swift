//
//  ExportData.swift
//  transom
//
//  Created by Roma Sosnovsky on 9/22/19.
//  Copyright © 2019 Void Digital. All rights reserved.
//

import UIKit

enum PdfDataError: Error {
    case noThoughts, unknown
}

enum ExportDataFileType: String, CaseIterable {
    case csv, pdf, rtf

    var description: String {
        switch self {
        case .csv:
            return "CSV"
        case .pdf:
            return "PDF"
        case .rtf:
            return "RTF (Rich Text File)"
        }
    }
}

struct ExportData {
    static func export(fileType: ExportDataFileType, thoughts: [FBThought]) throws -> Data? {
        switch fileType {
        case .csv:
            return try csvExport(thoughts: thoughts)
        case .pdf:
            return try pdfForExport(thoughts: thoughts)
        case .rtf:
            return try rtfExport(thoughts: thoughts)
        }
    }

    static func getExportAttributedString(thoughts: [FBThought]) -> NSMutableAttributedString {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MMM d"

        let textAttributes: [NSAttributedString.Key: Any] = [.font: UIFont(name: "HelveticaNeue", size: 14)!, .foregroundColor: UIColor.red]
        let mediumTextAttributes: [NSAttributedString.Key: Any] = [.font: UIFont(name: "HelveticaNeue-Medium", size: 14)!]
        let italicTextAttributes: [NSAttributedString.Key: Any] = [.font: UIFont(name: "HelveticaNeue-Italic", size: 14)!]

        let today = dateFormatter.string(from: Date())
        let string = NSMutableAttributedString(string: "\nTransom Export on \(today)\n\n", attributes: [.font: UIFont(name: "HelveticaNeue-Medium", size: 16)!])

        for thought in thoughts {
            guard let attributedString = thought.exportString else { continue }

            let updatedAtDate = Date(timeIntervalSince1970: thought.updatedAt / 1000)
            string.append(NSAttributedString(string: "\(dateFormatter.string(from: updatedAtDate))", attributes: mediumTextAttributes))

            if !thought.tags.isEmpty {
                if let project = thought.tags.first(where: { $0.isPiece }) {
                    string.append(NSAttributedString(string: "\nProject: \(project.name)", attributes: italicTextAttributes))
                }
                let tagsList = thought.tags.filter({ !$0.isPiece }).map({ $0.name }).joined(separator: ", ")
                if !tagsList.isEmpty {
                    string.append(NSAttributedString(string: "\nTags: \(tagsList)", attributes: italicTextAttributes))
                }
            }

            string.append(NSAttributedString(string: "\n", attributes: textAttributes))
            string.append(attributedString)
            string.append(NSAttributedString(string: "\n\n"))
        }

        return string
    }

    static func pdfForExport(thoughts: [FBThought]) throws -> Data? {
        let string = getExportAttributedString(thoughts: thoughts)

        do {
            let htmlData = try string.data(from: NSMakeRange(0, string.length), documentAttributes: [.documentType: NSAttributedString.DocumentType.html])
            if let htmlString = String(data: htmlData, encoding: .utf8) {
                return pdfData(htmlString: htmlString)
            }
        }
        catch {
            //      print("error creating HTML from Attributed String")
            throw PdfDataError.unknown
        }

        return nil
    }

    static func pdfData(htmlString html: String) -> Data {
        let fmt = UIMarkupTextPrintFormatter(markupText: html)

        let render = UIPrintPageRenderer()
        render.addPrintFormatter(fmt, startingAtPageAt: 0)

        let page = CGRect(x: 0, y: 0, width: 595.2, height: 841.8) // A4, 72 dpi
        let printable = page.insetBy(dx: 50, dy: 50) // was 0 , 0

        render.setValue(NSValue(cgRect: page), forKey: "paperRect")
        render.setValue(NSValue(cgRect: printable), forKey: "printableRect")

        let pdfData = NSMutableData()
        UIGraphicsBeginPDFContextToData(pdfData, CGRect.zero, nil)

        for i in 1...render.numberOfPages {

            UIGraphicsBeginPDFPage();
            let bounds = UIGraphicsGetPDFContextBounds()
            render.drawPage(at: i - 1, in: bounds)
        }

        UIGraphicsEndPDFContext()

        return pdfData as Data
    }

    static func rtfExport(thoughts: [FBThought]) throws -> Data? {
        let string = getExportAttributedString(thoughts: thoughts)

        do {
            let htmlData = try string.data(from: NSMakeRange(0, string.length), documentAttributes: [.documentType: NSAttributedString.DocumentType.rtf])
            return htmlData
        }
        catch {
            throw PdfDataError.unknown
        }
    }

    static func csvExport(thoughts: [FBThought]) throws -> Data? {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MMM d, YYYY"
        
        var string = "Thought,Project,Tags,Date\n"
        
        for thought in thoughts {
            let updatedAtDate = Date(timeIntervalSince1970: thought.updatedAt / 1000)
            let date = dateFormatter.string(from: updatedAtDate)
            string += "\"\(thought.exportText)\",\"\(thought.projectName ?? "")\",\"\(thought.tagsListString)\",\"\(date)\"\n"
        }

        return string.data(using: .utf8)
    }
}
