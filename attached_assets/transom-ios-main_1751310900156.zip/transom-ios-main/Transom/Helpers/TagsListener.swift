//
//  TagsListener.swift
//  transom
//
//  Created by Roma Sosnovsky on 13.08.2020.
//  Copyright © 2020 Void Digital. All rights reserved.
//

import Foundation

protocol TagsListener: AnyObject {
    func didAdd(tag: FBTag)
    func didUpdated(tag: FBTag)
    func didRemoved(tag: FBTag)
}

final class TagsListenerDelegate: NSObject, TagsListener {

    let multicast = MulticastDelegate<TagsListener>()

    init(delegates: [TagsListener]) {
        super.init()
        delegates.forEach(multicast.add)
    }

    func didAdd(tag: FBTag) {
        multicast.invoke { $0.didAdd(tag: tag) }
    }

    func didUpdated(tag: FBTag) {
        multicast.invoke { $0.didUpdated(tag: tag) }
    }

    func didRemoved(tag: FBTag) {
        multicast.invoke { $0.didRemoved(tag: tag) }
    }
}
