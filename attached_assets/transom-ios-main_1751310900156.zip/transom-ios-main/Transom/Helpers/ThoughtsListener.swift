//
//  ThoughtsListener.swift
//  transom
//
//  Created by Roma Sosnovsky on 13.08.2020.
//  Copyright © 2020 Void Digital. All rights reserved.
//

import Foundation

protocol ThoughtsListener: AnyObject {
    func didAdd(thought: FBThought)
    func didUpdated(thought: FBThought)
    func didRemoved(thought: FBThought)
}

final class ThoughtsListenerDelegate: NSObject, ThoughtsListener {

    let multicast = MulticastDelegate<ThoughtsListener>()

    init(delegates: [ThoughtsListener]) {
        super.init()
        delegates.forEach(multicast.add)
    }

    func didAdd(thought: FBThought) {
        multicast.invoke { $0.didAdd(thought: thought) }
    }

    func didUpdated(thought: FBThought) {
        multicast.invoke { $0.didUpdated(thought: thought) }
    }

    func didRemoved(thought: FBThought) {
        multicast.invoke { $0.didRemoved(thought: thought) }
    }
}
