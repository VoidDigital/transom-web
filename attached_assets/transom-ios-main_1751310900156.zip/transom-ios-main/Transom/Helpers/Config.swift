//
//  Config.swift
//  transom
//
//  Created by Roma Sosnovsky on 31.08.2020.
//  Copyright © 2020 Void Digital. All rights reserved.
//

import Foundation

struct Config {
    static let dailyWordsGoal = 100

    struct Notifications {
        static let didUpdateWordsCount = "didUpdateWordsCount"
    }
}
