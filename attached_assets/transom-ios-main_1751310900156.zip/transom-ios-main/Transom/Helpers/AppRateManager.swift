//
//  AppRateManager.swift
//  transom
//

import StoreKit
import UIKit

class AppRateManager {
    
    //MARK: - Consts
    
    private enum Consts {
        static let requiredNumberOfThoughts = 3
        static let requiredNumberOfDaysToLeftBetweenReviewRequests = 3
    }
    
    //MARK: - Functionality
    
    func askForReview() {
        guard shouldAskForReview() else { return }
        SKStoreReviewController.requestReview()
        UserDefaults.setReviewRequestLastDate()
        UserDefaults.setReviewRequestLastVersion()
    }
    
    //MARK: - Helpers
    
    private func shouldAskForReview() -> Bool {
        if let reviewRequestLastDate = UserDefaults.getReviewRequestLastDate() {
            let now = Date()
            let calendar = Calendar.current
            let daysLeft = calendar.dateComponents([.day], from: reviewRequestLastDate, to: now).day
            if let daysLeft = daysLeft, daysLeft <= Consts.requiredNumberOfDaysToLeftBetweenReviewRequests {
                return false
            }
        }
        
        return FBThoughtObserver.shared.currentThoughts.count % Consts.requiredNumberOfThoughts == 0
    }
}
