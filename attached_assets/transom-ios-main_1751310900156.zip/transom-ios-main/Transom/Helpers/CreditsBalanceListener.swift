//
//  CreditsBalanceListener.swift
//  transom
//
//  Created by Roma Sosnovsky on 31/08/21.
//  Copyright © 2021 Void Digital. All rights reserved.
//

import Foundation

protocol CreditsBalanceListener: AnyObject {
    func creditsBalanceDidChange()
}

final class CreditsBalanceListenerDelegate: NSObject, CreditsBalanceListener {

    let multicast = MulticastDelegate<CreditsBalanceListener>()

    init(delegates: [CreditsBalanceListener]) {
        super.init()
        delegates.forEach(multicast.add)
    }

    func creditsBalanceDidChange() {
        multicast.invoke { $0.creditsBalanceDidChange() }
    }
}
