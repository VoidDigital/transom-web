//
//  MixPanelEventTracker.swift
//  transom
//

import Foundation
import Mixpanel

class EventTracker {
    static let shared = EventTracker()
    
    private let tracker: MixpanelInstance?
    
    init() {
        tracker = Mixpanel.mainInstance()
    }
    
    func track(event: EventName) {
        track(event: event, with: nil)
    }
    
    func track(event: EventName, with parameter: EventParameter?) {
        tracker?.track(event: event.rawValue, properties: parameter?.asDictionary)
    }
    
}
