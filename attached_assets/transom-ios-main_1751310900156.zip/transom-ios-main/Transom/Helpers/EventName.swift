//
//  EventTracker.swift
//  transom
//

import Foundation

enum EventName: String {
    case createAccountInitiated = "create account initiated"
    case loginInitiated = "login initiated"
    case authenticationInfoTapped = "authentication info tapped"
    case emailLinkTapped = "email link tapped"
    case createAccountSuccessful = "create account successful"
    case loginSuccessful = "login successful"
    case passwordResetInitiated = "password reset initiated"
    case passwordResetRequested = "password reset requested"
    case addItemMenuToggled = "add item menu toggled"
    case newItemAdded = "new item added"
    case globalNavMenuToggled = "global nav menu toggled"
    case globalNavMenuSelection = "global nav menu selection"
    case thoughtSelected = "thought selected"
    case filterInitiated = "filter initiated"
    case filterRemoved = "filter removed"
    case tagSelectionToggled = "tag selection toggled"
    case tagFilterSelected = "tag filter selected"
    case thoughtArchived = "thought archived"
    case deleteThoughtInitiated = "delete thought initiated"
    case deleteThoughtCanceled = "delete thought canceled"
    case deleteThoughtSuccessful = "delete thought successful"
    case editThought = "edit thought"
    case addTagsInitiated = "add tags initiated"
    case newThoughtSaved = "new thought saved"
    case feedbackDismissed = "feedback dismissed"
    case tagSelected = "tag selected"
    case newTagAdded = "new tag added"
    case pieceSelected = "piece selected"
    case tabMenuSelection = "tab menu selection"
    case newPieceCreated = "new piece created"
    case restoreThoughtCanceled = "restore thought canceled"
    case restoreThoughtSuccessful = "restore thought successful"
    case searchInitiated = "search initiated"
    case feedbackSent = "feedback sent"
    case feedbackCanceled = "feedback canceled"
    case feedbackLinkTapped = "feedback link tapped"
    case appleLegalLinkTapped = "Apple legal link tapped"
}

enum EventParameter: String {
    case newThought = "new thought"
    case newPiece = "new piece"
    case newTag = "new tag"
    case thoughts = "thoughts"
    case tags = "tags"
    case pieces = "pieces"
    case archivedThoughts = "archived thoughts"
    case exportThoughts = "export thoughts"
    case feedback = "feedback"
    case whoWeAre = "who we are"
    case aboutLegal = "about_legal"
    case logOut = "log out"
    
    var asDictionary: [String: String] { [rawValue: rawValue] }
}
