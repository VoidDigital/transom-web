//
//  BoughtPromptPacksListener.swift
//  transom
//
//  Created by Roma Sosnovsky on 03/09/21.
//  Copyright © 2021 Void Digital. All rights reserved.
//

import Foundation

protocol BoughtPromptPacksListener: AnyObject {
    func boughtPacksDidChange()
}

final class BoughtPromptPacksListenerDelegate: NSObject, BoughtPromptPacksListener {

    let multicast = MulticastDelegate<BoughtPromptPacksListener>()

    init(delegates: [BoughtPromptPacksListener]) {
        super.init()
        delegates.forEach(multicast.add)
    }

    func boughtPacksDidChange() {
        multicast.invoke { $0.boughtPacksDidChange() }
    }
}
