//
//  ColdOpeningVC.swift
//  Transom
//
//  Created by Gregg Goldner on 5/9/17.
//  Copyright © 2017 Two Sun Traders. All rights reserved.
//

import UIKit

class ColdOpeningVC: UIViewController {
    @IBOutlet private weak var bottomView: UIView!
    @IBOutlet private weak var loginButton: UIButton!
    @IBOutlet private weak var createAccountButton: UIButton!

    static func instantiate() -> UINavigationController? {
        let authVC = UIStoryboard(name: "Auth", bundle: nil).instantiateViewController(withIdentifier: "ColdOpeningVC")
        let navigationVC = UINavigationController(rootViewController: authVC)
        let backImage = UIImage(named: "back")?.withRenderingMode(.alwaysOriginal)
        navigationVC.navigationBar.backIndicatorImage = backImage
        navigationVC.navigationBar.backIndicatorTransitionMaskImage = backImage
        navigationVC.setNavigationBarHidden(true, animated: false)
        return navigationVC
    }

    private var didLayoutSubviews = false
    private var didAppear = false
    
    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()

        bottomView.alpha = 0

        setupButtons()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)

        navigationController?.setNavigationBarHidden(true, animated: true)
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()

        guard !didLayoutSubviews else { return }

        didLayoutSubviews = true
        setupButtonsBackground()

        bottomView.center.y += 120
        view.layoutIfNeeded()
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)

        guard !didAppear else { return }

        didAppear = true
        showBottomView()
    }

    private func setupButtons() {
        loginButton.layer.borderColor = UIColor.white.cgColor
        loginButton.layer.borderWidth = 2

        [loginButton, createAccountButton].forEach {
            $0?.layer.cornerRadius = 4
            $0?.clipsToBounds = true
        }

        navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
        navigationItem.backBarButtonItem?.tintColor = UIColor(named: "Settings Button Text")

        let color = UIColor(red: 218/255, green: 218/255, blue: 218/255, alpha: 1)
        navigationController?.navigationBar.shadowImage = UIImage.imageWithColor(color: color)
    }

    private func setupButtonsBackground() {
        addTriangle(to: loginButton, backgroundColor: UIColor(red: 1/255, green: 60/255, blue: 220/255, alpha: 1))
        addTriangle(to: createAccountButton, backgroundColor: UIColor(red: 245/255, green: 245/255, blue: 245/255, alpha: 1))
    }

    private func addTriangle(to view: UIView, backgroundColor: UIColor, offset: CGFloat = 8) {
        let backgroundLayer = CAShapeLayer()
        backgroundLayer.fillColor = backgroundColor.cgColor

        let path = UIBezierPath()

        path.move(to: CGPoint(x: -offset, y: 0))
        path.addLine(to: CGPoint(x: view.bounds.width + offset, y: view.bounds.height))
        path.addLine(to: CGPoint(x: 0, y: view.bounds.height))
        path.close()

        backgroundLayer.path = path.cgPath

        view.layer.addSublayer(backgroundLayer)
    }

    private func showBottomView() {
        UIView.animate(withDuration: 1.2, delay: 0.2, usingSpringWithDamping: 0.8, initialSpringVelocity: 0.2, animations: {
            self.bottomView.center.y -= 120
            self.bottomView.alpha = 1
        }, completion: nil)
    }

    // MARK: - Actions
    @IBAction private func openLogin(_ sender: Any) {
        EventTracker.shared.track(event: .loginInitiated)
        let vc = LoginViewController.instantiate(type: .existing)
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction private func createAccount(_ sender: Any) {
        EventTracker.shared.track(event: .createAccountInitiated)
        let vc = LoginViewController.instantiate(type: .new)
        navigationController?.pushViewController(vc, animated: true)
    }
}
