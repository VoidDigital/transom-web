//
//  ExportFormatViewController.swift
//  transom
//
//  Created by Roma Sosnovsky on 05/03/21.
//  Copyright © 2021 Void Digital. All rights reserved.
//

import UIKit

class ExportFormatViewController: UIViewController {
    // MARK: - Members
    @IBOutlet private weak var topLabel: UILabel!
    @IBOutlet private weak var formatStackView: UIStackView!
    @IBOutlet private weak var exportButton: UIButton!
    
    private var modalOverlayView: UIView?
    private var modalView: ExportCompletionModalView?
    
    private var buttons: [UIButton] = []
    private var exportType: ExportDataFileType = .csv
    private var exportTypeIndex: Int { ExportDataFileType.allCases.firstIndex(of: exportType) ?? 0 }
    
    private var projects: [String] = []
    private var tags: [String] = []
    
    // MARK: - Setup
    static func instantiate(projects: [String] = [], tags: [String] = []) -> ExportFormatViewController {
        let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ExportFormatViewController") as! ExportFormatViewController
        vc.projects = projects
        vc.tags = tags
        return vc
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupNavigationItem()
        setupFormatButtons()
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
        buttons.forEach { $0.addBorder() }
    }
    
    private func setupNavigationItem() {
        let backButton = UIBarButtonItem(image: UIImage(named: "back"), style: .plain, target: self, action: #selector(goBack))
        navigationItem.leftBarButtonItem = backButton
        navigationItem.title = "Export"
    }
    
    private func setupFormatButtons() {
        buttons = ExportDataFileType.allCases.enumerated().map { index, type in
            let button = UIButton()
            button.tag = index
            button.setTitle(type.description, for: .normal)
            button.setTitleColor(UIColor(red: 43/255, green: 43/255, blue: 43/255, alpha: 1), for: .normal)
            button.setImage(UIImage(named: "export-checkbox"), for: .normal)
            button.backgroundColor = .white
            button.titleLabel?.font = .systemFont(ofSize: 13)
            button.contentHorizontalAlignment = .left
            button.contentEdgeInsets = UIEdgeInsets(top: 0, left: 12, bottom: 0, right: 0)
            button.titleEdgeInsets = UIEdgeInsets(top: 0, left: 12, bottom: 0, right: 0)
            let tapGesture = UITapGestureRecognizer(target: self, action: #selector(onFormatButtonTap))
            button.addGestureRecognizer(tapGesture)
            formatStackView.addArrangedSubview(button)
            return button
        }
        
        updateButtons()
    }
    
    // MARK: - Buttons
    @objc private func onFormatButtonTap(recognizer: UITapGestureRecognizer) {
        guard let index = recognizer.view?.tag else { return }
        
        exportType = ExportDataFileType.allCases[index]
        updateButtons()
    }
    
    private func updateButtons() {
        buttons.enumerated().forEach { index, button in
            let imageName = index == exportTypeIndex ? "export-checkbox-checked" : "export-checkbox"
            button.setImage(UIImage(named: imageName), for: .normal)
        }
    }
    
    // MARK: - Export
    private func exportThoughts(fileType: ExportDataFileType) {
        guard let navigationController = navigationController as? SettingsNavigationController else { return }
        
        var thoughts = FBThoughtObserver.shared.currentThoughts.sorted(by: { $0.updatedAt > $1.updatedAt })
        
        if !projects.isEmpty {
            thoughts = thoughts.filter { $0.projectName != nil && projects.contains($0.projectName!) }
        }
        
        if !tags.isEmpty {
            let tagsSet = Set(tags)
            thoughts = thoughts.filter { !tagsSet.intersection($0.tagsList).isEmpty }
        }
        
        do {
            guard let data = try ExportData.export(fileType: fileType, thoughts: thoughts) else { return }

            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "MM-dd"

            let documentsPath = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0]
            let filePath = "\(documentsPath)/Transom-\(dateFormatter.string(from: Date())).\(fileType.rawValue)"
            try? data.write(to: URL(fileURLWithPath: filePath), options: [.atomic])
            let fileData = URL(fileURLWithPath: filePath)

            let objectsToShare = [fileData]

            let activityVC = UIActivityViewController(activityItems: objectsToShare, applicationActivities: nil)
            activityVC.popoverPresentationController?.sourceView = exportButton
            activityVC.popoverPresentationController?.sourceRect = exportButton.bounds
            activityVC.completionWithItemsHandler = { activityType, completed, returnedItems, activityError in
                guard completed else { return }
                
                DispatchQueue.main.async {
                    navigationController.showExportCompletionModal()
                }
            }

            present(activityVC, animated: true, completion: nil)

        } catch PdfDataError.noThoughts {
            showError(text: "No thoughts found to export")
        } catch PdfDataError.unknown {
            showError(text: "Unknown Error")
        } catch {
            showError(text: "Sorry")
        }
    }
    
    // MARK: - IBActions
    @IBAction func exportThoughts() {
        exportThoughts(fileType: exportType)
    }
}
