//
//  ExportSelectionViewController.swift
//  transom
//
//  Created by Roma Sosnovsky on 05/03/21.
//  Copyright © 2021 Void Digital. All rights reserved.
//

import UIKit

class ExportSelectionViewController: UIViewController {
    // MARK: - Members
    @IBOutlet private weak var projectsLabel: UILabel!
    @IBOutlet private weak var tagsLabel: UILabel!
    @IBOutlet private weak var continueButton: UIButton!
    
    private var modalOverlayView: UIView?
    private var modalView: ThoughtTagsView?
    private var currentModalType: TagType = .project
    
    private var allTags: [FBTag] = []
    private var preselectedTag: FBTag?
    private var shouldShowCloseButton = false
    
    private var selectedProjects: [String] = [] {
        didSet {
            update(label: projectsLabel, tags: selectedProjects, type: .project)
        }
    }
    
    private var selectedTags: [String] = [] {
        didSet {
            update(label: tagsLabel, tags: selectedTags, type: .tag)
        }
    }
    
    private var availableTags: [FBTag] {
        let tags = allTags.filter { !$0.isPiece }
        
        guard !selectedProjects.isEmpty else { return tags }
        
        return selectedProjects
                .reduce([FBThought](), { $0 + firebaseService.thoughts(for: $1) })
                .flatMap { $0.tags.filter { !$0.isPiece } }
    }
    
    private var thoughtsToExport: [FBThought] {
        var thoughts = FBThoughtObserver.shared.currentThoughts.sorted(by: { $0.updatedAt > $1.updatedAt })
        
        if !selectedProjects.isEmpty {
            thoughts = thoughts.filter { $0.projectName != nil && selectedProjects.contains($0.projectName!) }
        }
        
        if !selectedTags.isEmpty {
            let tagsSet = Set(selectedTags)
            thoughts = thoughts.filter { !tagsSet.intersection($0.tagsList).isEmpty }
        }
        
        return thoughts
    }
    
    private let firebaseService = FirebaseService.shared
    
    // MARK: - Setup
    static func instantiate(withNavigationController: Bool = false, preselectedTag: FBTag? = nil) -> UIViewController {
        let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ExportSelectionViewController") as! ExportSelectionViewController
        vc.preselectedTag = preselectedTag
        
        if withNavigationController {
            vc.shouldShowCloseButton = true
            return SettingsNavigationController(rootViewController: vc)
        } else {
            return vc
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        getAllTags()
        setupNavigationItem()
        setupLabels()
        checkPreselectedTag()
        updateContinueButton()
    }
    
    private func setupNavigationItem() {
        navigationItem.title = "Export"
        navigationItem.backButtonTitle = ""
        
        if shouldShowCloseButton {
            let closeBarButtonItem = UIBarButtonItem(image: UIImage(named: "navigation-bar-close"), style: .plain, target: self, action: #selector(close))
            navigationItem.leftBarButtonItem = closeBarButtonItem
        } else {
            let closeBarButtonItem = UIBarButtonItem(image: UIImage(named: "back"), style: .plain, target: self, action: #selector(goBack))
            navigationItem.leftBarButtonItem = closeBarButtonItem
        }
    }
    
    private func setupLabels() {
        let projectTapGesture = UITapGestureRecognizer(target: self, action: #selector(showProjectsModal))
        projectsLabel.isUserInteractionEnabled = true
        projectsLabel.addGestureRecognizer(projectTapGesture)
        
        let tagTapGesture = UITapGestureRecognizer(target: self, action: #selector(showTagsModal))
        tagsLabel.isUserInteractionEnabled = true
        tagsLabel.addGestureRecognizer(tagTapGesture)
    }
    
    private func checkPreselectedTag() {
        guard let tag = preselectedTag else { return }
        
        if tag.isPiece {
            selectedProjects = [tag.name]
        } else {
            selectedTags = [tag.name]
        }
    }
    
    private func update(label: UILabel, tags: [String], type: TagType) {
        updateContinueButton()
        
        guard !tags.isEmpty else {
            label.textColor = UIColor(red: 129/255, green: 134/255, blue: 155/255, alpha: 1)
            label.text = type == .project ? "All Projects" : "All Tags"
            return
        }
        
        let string = tags.joined(separator: ", ")
        let paragraphStyle = NSMutableParagraphStyle()
        paragraphStyle.lineSpacing = 8
        let attributes: [NSAttributedString.Key: Any] = [.paragraphStyle: paragraphStyle]
        
        label.textColor = UIColor(red: 43/255, green: 43/255, blue: 43/255, alpha: 1)
        label.attributedText = NSAttributedString(string: string, attributes: attributes)
    }
    
    private func updateContinueButton() {
        if thoughtsToExport.isEmpty {
            continueButton.setTitle("No thoughts to export", for: .normal)
            continueButton.backgroundColor = UIColor(red: 199/255, green: 199/255, blue: 199/255, alpha: 1)
        } else {
            let word = thoughtsToExport.count == 1 ? "Thought" : "Thoughts"
            continueButton.setTitle("Export \(thoughtsToExport.count) \(word)", for: .normal)
            continueButton.backgroundColor = UIColor(named: "Button")
        }
        
        continueButton.isEnabled = !thoughtsToExport.isEmpty
    }
    
    private func getAllTags() {
        FirebaseService.shared.getUserTags { [weak self] in self?.allTags = $0 }
    }
    
    func resetCurrentExport() {
        selectedProjects = []
        selectedTags = []
    }
    
    @objc private func close() {
        dismiss(animated: true, completion: nil)
    }
    
    override var preferredStatusBarStyle: UIStatusBarStyle { .default }
    
    // MARK: - Modals
    @objc private func showProjectsModal() {
        showModal(type: .project)
    }
    
    @objc private func showTagsModal() {
        showModal(type: .tag)
    }
    
    private func showModal(type: TagType) {
        guard let navigationController = navigationController else { return }

        modalOverlayView = UIView(frame: navigationController.view.frame)
        modalOverlayView?.backgroundColor = UIColor(red: 0/255, green: 41/255, blue: 105/255, alpha: 1)
        modalOverlayView?.alpha = 0
        navigationController.view.addSubview(modalOverlayView!)

        let width = min(view.frame.width - 20, 360)
        let x = (view.frame.width - width) / 2
        modalView = ThoughtTagsView(frame: CGRect(x: x, y: 1.5 * view.frame.height, width: width, height: 320))
        modalView?.delegate = self
        navigationController.view.addSubview(modalView!)

        view.endEditing(true)

        currentModalType = type

        let currentTags: [String]
        let modalTags: [FBTag]
        switch type {
        case .project:
            currentTags = selectedProjects
            modalTags = allTags.filter { $0.isPiece }
        case .tag:
            currentTags = selectedTags
            modalTags = availableTags
        }
        modalView?.setup(type: type, tags: currentTags, allTags: modalTags, allowsMultipleSelection: true, allowsCreation: false)

        UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 0.8, initialSpringVelocity: 0.2, animations: {
            self.modalOverlayView?.alpha = 0.45
            let centerY: CGFloat
            if UIDevice.current.userInterfaceIdiom == .pad && UIApplication.shared.statusBarOrientation.isLandscape {
                centerY = navigationController.view.frame.height + 290
            } else {
                centerY = navigationController.view.frame.height + 160
            }
            self.modalView?.center.y -= centerY
            self.view.layoutIfNeeded()
        }, completion: { _ in
            self.modalView?.focusInput()
        })
    }
    
    // MARK: - IBActions
    @IBAction func chooseExportType() {
        let vc = ExportFormatViewController.instantiate(projects: selectedProjects, tags: selectedTags)
        navigationController?.pushViewController(vc, animated: true)
    }
}

// MARK: - ThoughtTagsViewDelegate
extension ExportSelectionViewController: ThoughtTagsViewDelegate {
    func update(tags: [String], type: TagType) {
        view.endEditing(true)
        
        switch type {
        case .project:
            selectedProjects = tags
        case .tag:
            selectedTags = tags
        }
        
        UIView.animate(withDuration: 0.4, animations: {
            self.modalOverlayView?.alpha = 0
            self.modalView?.center.y += UIScreen.main.bounds.height
        }, completion: { _ in
            self.modalOverlayView = nil
            self.modalView = nil
        })
    }
}
