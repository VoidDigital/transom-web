//
//  WordsCalendarViewController.swift
//  transom
//
//  Created by Roma Sosnovsky on 26.08.2020.
//  Copyright © 2020 Void Digital. All rights reserved.
//

import FSCalendar
import UIKit

class WordsCalendarViewController: UIViewController {
    private var navigationTitleLabel: UILabel!
    private var navigationSubtitleLabel: UILabel!

    private lazy var calendarView = FSCalendar()
    private lazy var calendar = Calendar.current

    private let dayDateFormatter = DateFormatter()
    private var wordsCount: [String: Int] = [:]

    static func instantiate() -> UINavigationController {
        let vc = WordsCalendarViewController.init(nibName: nil, bundle: nil)
        let navigationController = UINavigationController(rootViewController: vc)
        navigationController.navigationBar.isTranslucent = false
        navigationController.navigationBar.barTintColor = UIColor(red: 247/255, green: 248/255, blue: 250/255, alpha: 1)
        return navigationController
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        view.backgroundColor = .white
        dayDateFormatter.dateFormat = "yyyy-MM-dd"

        setupNavigationTitle()
        setupNavigationButtons()
        loadDailyWordsCount()
        setupCalendar()
    }

    private func loadDailyWordsCount() {
        FirebaseService.shared.getDailyWordsCount { [weak self] days in
            guard let self = self else { return }

            self.wordsCount = days

            let currentStreak = self.getCurrentStreak()
            let streakWord = currentStreak == 1 ? "Day" : "Days"

            DispatchQueue.main.async {
                self.navigationSubtitleLabel.text = "Current Streak: \(currentStreak) \(streakWord)"
                self.calendarView.reloadData()
            }
        }
    }

    private func getCurrentStreak() -> Int {
        let dates = Array(wordsCount.keys)
            .filter { wordsCount[$0]! >= Config.dailyWordsGoal }
            .compactMap { dayDateFormatter.date(from: $0) }
            .sorted { $0 > $1 }

        guard let lastDay = dates.first,
              calendar.isDateInToday(lastDay) || calendar.isDateInYesterday(lastDay)
        else { return 0 }

        var daysCount = 1
        var currentIndex = 1
        var currentDate = calendar.date(byAdding: .day, value: -1, to: lastDay)!

        if dates.count > 1 {
            while currentIndex < dates.count {
                if calendar.isDate(dates[currentIndex], inSameDayAs: currentDate) {
                    daysCount += 1
                    currentIndex += 1
                    currentDate = calendar.date(byAdding: .day, value: -1, to: currentDate)!
                } else {
                    break
                }
            }
        }

        return daysCount
    }

    private func setupNavigationTitle() {
        guard navigationTitleLabel == nil && navigationSubtitleLabel == nil else { return }

        navigationTitleLabel = UILabel()
        navigationTitleLabel.font = UIFont.systemFont(ofSize: 16, weight: .medium)
        navigationTitleLabel.textColor = UIColor(red: 65/255, green: 65/255, blue: 65/255, alpha: 1)
        navigationTitleLabel.text = "\(Config.dailyWordsGoal) Words a Day"
        navigationTitleLabel.sizeToFit()

        navigationSubtitleLabel = UILabel()
        navigationSubtitleLabel.font = UIFont.systemFont(ofSize: 12)
        navigationSubtitleLabel.textColor = UIColor(red: 162/255, green: 168/255, blue: 172/255, alpha: 1)
        navigationSubtitleLabel.textAlignment = .center
        navigationSubtitleLabel.text = ""

        let stackView = UIStackView(arrangedSubviews: [navigationTitleLabel, navigationSubtitleLabel])
        stackView.distribution = .equalCentering
        stackView.axis = .vertical
        stackView.alignment = .center

        let width = max(navigationTitleLabel.frame.size.width, navigationSubtitleLabel.frame.size.width)
        stackView.frame = CGRect(x: 0, y: 0, width: width, height: 35)

        navigationTitleLabel.sizeToFit()
        navigationSubtitleLabel.sizeToFit()

        navigationItem.titleView = stackView
    }

    private func setupNavigationButtons() {
        navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
        navigationItem.leftBarButtonItem = UIBarButtonItem(image: UIImage(named: "navigation-bar-cross"), style: .plain, target: self, action: #selector(closeCalendar))
        navigationItem.rightBarButtonItem = UIBarButtonItem(image: UIImage(named: "calendar-info"), style: .plain, target: self, action: #selector(showCalendarInfo))
    }

    private func setupCalendar() {
        calendarView.dataSource = self
        calendarView.delegate = self
        calendarView.clipsToBounds = true

        calendarView.appearance.caseOptions = FSCalendarCaseOptions.weekdayUsesSingleUpperCase

        calendarView.appearance.headerTitleFont = UIFont.systemFont(ofSize: 16)
        calendarView.appearance.headerTitleColor = UIColor(red: 24/255, green: 24/255, blue: 24/255, alpha: 1)

        calendarView.appearance.weekdayFont = UIFont(name: "NotoSerif", size: 10)
        calendarView.appearance.weekdayTextColor = UIColor(red: 24/255, green: 24/255, blue: 24/255, alpha: 0.5)

        calendarView.appearance.titleFont = UIFont.systemFont(ofSize: 13)

        calendarView.appearance.todayColor = UIColor.clear //(red: 252/255, green: 165/255, blue: 98/255, alpha: 1)

        calendarView.appearance.titleSelectionColor = UIColor(red: 24/255, green: 24/255, blue: 24/255, alpha: 1)
        calendarView.appearance.selectionColor = UIColor.clear

        calendarView.scrollDirection = .vertical
        calendarView.pagingEnabled = false

        calendarView.register(TransomCalendarCell.self, forCellReuseIdentifier: "cell")
        //calendarView.collectionViewLayout.sectionInsets = UIEdgeInsets.zero

        view.addSubview(calendarView)
        calendarView.translatesAutoresizingMaskIntoConstraints = false

        NSLayoutConstraint.activate([
            calendarView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 12),
            calendarView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor),
            calendarView.topAnchor.constraint(equalTo: view.layoutMarginsGuide.topAnchor),
            calendarView.bottomAnchor.constraint(equalTo: view.layoutMarginsGuide.bottomAnchor),
        ])
    }

    @objc private func closeCalendar() {
        navigationController?.dismiss(animated: true, completion: nil)
    }

    @objc private func showCalendarInfo() {
        let vc = WordsInfoViewController.init(nibName: nil, bundle: nil)
        navigationController?.pushViewController(vc, animated: true)
    }
}

// MARK: - FSCalendarDataSource
extension WordsCalendarViewController: FSCalendarDataSource {
    func minimumDate(for calendar: FSCalendar) -> Date {
        var dateComponents = DateComponents()
        dateComponents.year = 2020
        dateComponents.month = 6
        dateComponents.day = 1

        return self.calendar.date(from: dateComponents)!
    }

    func maximumDate(for calendar: FSCalendar) -> Date {
        guard let interval = self.calendar.dateInterval(of: .month, for: Date()),
              let lastMonthDay = self.calendar.date(byAdding: .day, value: -1, to: interval.end)
        else { return Date() }

        return self.calendar.date(byAdding: .month, value: 1, to: lastMonthDay)!
    }
}

extension WordsCalendarViewController: FSCalendarDelegate {
    func calendar(_ calendar: FSCalendar, cellFor date: Date, at position: FSCalendarMonthPosition) -> FSCalendarCell {
        guard let cell = calendar.dequeueReusableCell(withIdentifier: "cell", for: date, at: position) as? TransomCalendarCell
            else { return FSCalendarCell() }

        var backgroundColor = UIColor.clear
        var borderColor = UIColor.clear
        var titleColor: UIColor?
        let dateString = dayDateFormatter.string(from: date)

        if position == .current {
            titleColor = UIColor(red: 24/255, green: 24/255, blue: 24/255, alpha: 1)
            if let dayWordsCount = wordsCount[dateString] {
                if dayWordsCount < Config.dailyWordsGoal {
                    if self.calendar.isDateInToday(date) {
                        borderColor = UIColor(red: 34/255, green: 34/255, blue: 34/255, alpha: 1)
                    } else {
                        backgroundColor = UIColor(red: 160/255, green: 160/255, blue: 160/255, alpha: 1)
                        titleColor = .white
                    }
                } else {
                    backgroundColor = UIColor(red: 34/255, green: 34/255, blue: 34/255, alpha: 1)
                    titleColor = .white
                }
            } else if self.calendar.isDateInToday(date) {
                borderColor = UIColor(red: 34/255, green: 34/255, blue: 34/255, alpha: 1)
            }
        }

        cell.setup(backgroundColor: backgroundColor, borderColor: borderColor, titleColor: titleColor)

        return cell
    }
}
