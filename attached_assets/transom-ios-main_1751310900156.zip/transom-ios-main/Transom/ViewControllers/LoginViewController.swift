//
//  LoginViewController.swift
//  transom
//
//  Created by Roma Sosnovsky on 9/17/19.
//  Copyright © 2019 Void Digital. All rights reserved.
//

import FirebaseAuth
import UIKit

class LoginViewController: UIViewController {
    @IBOutlet private weak var messageLabel: UILabel!
    @IBOutlet private weak var emailTextField: AuthTextField!
    @IBOutlet private weak var passwordTextField: AuthTextField!
    @IBOutlet private weak var loginButton: UIButton!
    @IBOutlet private weak var forgotPasswordButton: UIButton!
    @IBOutlet private weak var activityIndicatorView: UIActivityIndicatorView!
    @IBOutlet private weak var createAccountButton: UIButton!

    private var type: LoginType = .new

    static func instantiate(type: LoginType) -> LoginViewController {
        let vc = UIStoryboard(name: "Auth", bundle: nil).instantiateViewController(withIdentifier: "LoginViewController") as! LoginViewController
        vc.type = type
        return vc
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        setupUI()
        setupSwitchTypeButton()
        setupTextFields()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)

        navigationController?.setNavigationBarHidden(false, animated: true)
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)

        emailTextField.startEditing()
    }

    private func setupUI() {
        title = type.title
        messageLabel.text = type.message

        loginButton.setTitle(type.title, for: .normal)

        forgotPasswordButton.isHidden = type == .new
        createAccountButton.isHidden = type == .new
    }

    private func setupSwitchTypeButton() {
        guard let newAccountButtonTitle = createAccountButton.titleLabel?.text else { return }

        let newAccountAttributedString = NSMutableAttributedString(string: newAccountButtonTitle)
        let range = newAccountAttributedString.mutableString.range(of: "Create an account here")
        newAccountAttributedString.addAttribute(.underlineStyle, value: NSUnderlineStyle.single.rawValue, range: range)
        createAccountButton.setAttributedTitle(newAccountAttributedString, for: .normal)
    }

    private func setupTextFields() {
        emailTextField.setup(placeholder: "Email address", keyboardType: .emailAddress, isSecureTextEntry: false, returnKeyType: .next, delegate: self)
        passwordTextField.setup(placeholder: "Password", keyboardType: .default, isSecureTextEntry: true, returnKeyType: .done, delegate: self)
    }
    
    private func showLoader() {
        view.endEditing(true)
        
        activityIndicatorView.startAnimating()
        loginButton.setTitle("", for: .normal)
        loginButton.isUserInteractionEnabled = false

        UIView.animate(withDuration: 0.2) {
            self.loginButton.alpha = 0.2
        }
    }

    private func hideLoader() {
        activityIndicatorView.stopAnimating()
        loginButton.setTitle(type.title, for: .normal)
        loginButton.isUserInteractionEnabled = true

        UIView.animate(withDuration: 0.2) {
            self.loginButton.alpha = 1
        }
    }

    private func signInUser() {
        guard let email = emailTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines), email.isValidEmail else {
            showError(text: "Please enter a valid email")
            return
        }

        guard let password = passwordTextField.text, password.count > 5 else {
            showError(text: "Password should have at least 6 symbols")
            return
        }

        showLoader()

        switch type {
        case .new:
            createNewUser(email: email, password: password)
        case .existing:
            signIn(email: email, password: password)
        }
    }

    private func createNewUser(email: String, password: String) {
        FirebaseLogin().createUser(email: email, password: password) { [weak self] error in
            guard let self = self else { return }

            self.hideLoader()

            if let error = error {
                self.showError(text: error)
            } else {
                EventTracker.shared.track(event: .createAccountSuccessful)
                guard let vc = MainTabBarController.instantiate() else { return }
                self.setRootViewController(viewController: vc)
            }
        }
    }

    private func signIn(email: String, password: String) {
        FirebaseLogin().signIn(email: email, password: password) { [weak self] error in
            guard let self = self else { return }

            DispatchQueue.main.async {
                self.hideLoader()

                if let error = error {
                    self.showError(text: error)
                } else {
                    EventTracker.shared.track(event: .loginSuccessful)
                    guard let vc = MainTabBarController.instantiate(isExistingUser: true) else { return }
                    self.setRootViewController(viewController: vc)
                }
            }
        }
    }

    // MARK: - IBActions
    @IBAction private func logIn(_ sender: Any) {
        signInUser()
    }
    @IBAction private func switchToNewAccount(_ sender: Any) {
        type = .new

        UIView.animate(withDuration: 0.3) {
            self.setupUI()
        }
    }

    @IBAction private func forgotPassword(_ sender: Any) {
        guard let email = emailTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines), email.isValidEmail else {
            showError(text: "Please enter a valid email")
            return
        }

        view.endEditing(true)

        Auth.auth().sendPasswordReset(withEmail: email) { [weak self] error in
            guard let self = self else { return }

            DispatchQueue.main.async {
                if let error = error {
                    self.showError(text: error.localizedDescription)
                } else {
                    self.showMessage(title: "Email successfully sent", text: "Please check your inbox for password reset instructions")
                }
            }
        }
    }

}

extension LoginViewController: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if textField == emailTextField {
            passwordTextField.startEditing()
        } else if textField == passwordTextField {
            signInUser()
        }

        return true
    }
}

extension LoginViewController: AuthTextFieldDelegate {
    func didEndEditing(textField: AuthTextField) {
        if textField == emailTextField {
            passwordTextField.startEditing()
        } else if textField == passwordTextField {
            signInUser()
        }
    }
}
