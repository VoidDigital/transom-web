//
//  SettingsNavigationController.swift
//  transom
//
//  Created by Roma Sosnovsky on 07/04/21.
//  Copyright © 2021 Void Digital. All rights reserved.
//

import UIKit

class SettingsNavigationController: UINavigationController {
    private var modalOverlayView: UIView?
    private var modalView: ExportCompletionModalView?

    override func viewDidLoad() {
        super.viewDidLoad()

        setupStyles()
    }
    
    private func setupStyles() {
        tabBarItem = UITabBarItem(title: nil, image: UIImage(named: "tab-settings"), selectedImage: nil)
        navigationBar.backIndicatorImage = UIImage(named: "back")
        navigationBar.backIndicatorTransitionMaskImage = UIImage(named: "back")
        navigationBar.shadowImage = UIImage.imageWithColor(color: UIColor(red: 218/255, green: 218/255, blue: 218/255, alpha: 1))
        navigationBar.isTranslucent = false

        if #available(iOS 15, *) {
            let appearance = UINavigationBarAppearance()
            appearance.configureWithOpaqueBackground()
            appearance.titleTextAttributes = [.foregroundColor: UIColor.black]
            appearance.backgroundColor = .white
            navigationBar.standardAppearance = appearance
            navigationBar.scrollEdgeAppearance = appearance
            navigationBar.compactAppearance = appearance
        }
    }

    // MARK: - Export
    func showExportCompletionModal() {
        modalOverlayView = UIView(frame: view.frame)
        modalOverlayView?.backgroundColor = UIColor(red: 0/255, green: 41/255, blue: 105/255, alpha: 1)
        modalOverlayView?.alpha = 0
        view.addSubview(modalOverlayView!)

        let width = min(view.frame.width - 20, 360)
        let x = (view.frame.width - width) / 2
        modalView = ExportCompletionModalView(frame: CGRect(x: x, y: 1.5 * view.frame.height, width: width, height: 214))
        modalView?.delegate = self
        view.addSubview(modalView!)

        UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 0.8, initialSpringVelocity: 0.2, animations: {
            self.modalOverlayView?.alpha = 0.45
            self.modalView?.center.y -= self.view.frame.height + 110
            self.view.layoutIfNeeded()
        }, completion: nil)
    }
    
    private func closeExportCompletionModal(handler: (() -> Void)?) {
        UIView.animate(withDuration: 0.3, animations: {
            self.modalView?.center.y = self.view.frame.height * 1.5
            self.modalOverlayView?.alpha = 0
        }, completion: { _ in
            self.modalView = nil
            handler?()
        })
    }
}

extension SettingsNavigationController: ExportCompletionDelegate {
    func goToHome() {
        closeExportCompletionModal { [weak self] in
            DispatchQueue.main.async {
                self?.dismiss(animated: true)
            }
        }
    }
    
    func goToNewExport() {
        viewControllers.forEach {
            guard let exportVC = $0 as? ExportSelectionViewController else { return }
            
            exportVC.resetCurrentExport()
        }
        
        closeExportCompletionModal { [weak self] in
            DispatchQueue.main.async {
                self?.popViewController(animated: true)
            }
        }
    }
}
