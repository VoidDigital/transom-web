//
//  ListViewController.swift
//  transom
//
//  Created by Roma Sosnovsky on 8/23/19.
//  Copyright © 2019 Void Digital. All rights reserved.
//

import UIKit
import UserNotifications

class ListViewController: UIViewController {
    @IBOutlet private weak var alertLabel: UIButton!
    @IBOutlet private weak var alertLabelMarginTop: NSLayoutConstraint!
    @IBOutlet private weak var wrapTableView: UIView!
    @IBOutlet private weak var wrapSearchView: UIView!
    @IBOutlet private weak var searchBar: UISearchBar!
    @IBOutlet private weak var tableView: UITableView!
    @IBOutlet private weak var emptyView: UIView!
    @IBOutlet private weak var emptyImageView: UIImageView!
    @IBOutlet private weak var emptyTitleLabel: UILabel!
    @IBOutlet private weak var emptyMessageLabel: UILabel!
    @IBOutlet private weak var modalOverlayView: UIView!
    
    private let promptsService = PromptsService.shared
    
    private var calendarBarButton: UIBarButtonItem?

    private let searchController = UISearchController(searchResultsController: nil)
    private let refreshControl = UIRefreshControl()

    private var listType: ListType = .thought
    var selectedTag: FBTag?

    private var thoughts: [FBThought] = []
    private var tags: [FBTag] = []

    private var searchText = ""
    private var filteredThoughts: [FBThought] {
        thoughts.filter { $0.text.lowercased().contains(searchText) }
    }
    private var filteredTags: [FBTag] {
        tags.filter { $0.name.lowercased().contains(searchText) }
    }

    private var modalView: ProjectModalView?
    private var didLayoutSubviews = false
    private var selectedIndexPath: IndexPath?

    private var isStatusBarHidden = false
    private var shouldShowWelcomeMessage = false

    private var searchBarIsEmpty: Bool {
        return searchController.searchBar.text?.isEmpty ?? true
    }

    private var isFiltering: Bool {
        if UIDevice.current.userInterfaceIdiom == .pad {
            return searchBar.text != nil && !searchBar.text!.isEmpty
        }
        return searchController.isActive && !searchBarIsEmpty
    }

    static func instantiate(listType: ListType, tag: FBTag? = nil, withNavigationController: Bool = false, shouldShowWelcomeMessage: Bool = false) -> UIViewController {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)

        let vc = storyboard.instantiateViewController(withIdentifier: "ListViewController") as! ListViewController
        if let tag = tag {
            vc.title = "\"\(tag.name)\""
        } else if listType == .archive {
            vc.title = "Archived Thoughts"
        } else {
            vc.title = "\(listType.rawValue.capitalized)s"
        }
        vc.shouldShowWelcomeMessage = shouldShowWelcomeMessage
        vc.listType = listType
        vc.selectedTag = tag

        if withNavigationController {
            let navigationController = UINavigationController(rootViewController: vc)
            navigationController.tabBarItem = UITabBarItem(title: nil, image: UIImage(named: "tab-\(listType.rawValue)"), selectedImage: nil)
            navigationController.navigationBar.isTranslucent = false
            navigationController.navigationBar.backIndicatorImage = UIImage(named: "back")
            navigationController.navigationBar.backIndicatorTransitionMaskImage = UIImage(named: "back")
            navigationController.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
            navigationController.navigationBar.isOpaque = true
            navigationController.navigationBar.backgroundColor = UIColor(named: "Blue")
            navigationController.navigationBar.barTintColor = UIColor(named: "Blue")
            navigationController.navigationBar.tintColor = .white

            if #available(iOS 15, *) {
                let appearance = UINavigationBarAppearance()
                appearance.configureWithOpaqueBackground()
                appearance.titleTextAttributes = [.foregroundColor: UIColor.white]
                appearance.backgroundColor = UIColor(named: "Blue")
                navigationController.navigationBar.standardAppearance = appearance
                navigationController.navigationBar.scrollEdgeAppearance = appearance
                navigationController.navigationBar.compactAppearance = appearance
            }

            return navigationController
        } else {
            return vc
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        setupKeyboardNotifications()
        setupNavigationBar()
        setupTableView()
        setupEmptyView()
        setupAlertLabel()
        setupNotifications()
        setupWordsCountNotifications()
        getData()

        if listType == .thought {
            registerForPreviewing(with: self, sourceView: tableView)
            FirebaseService.shared.getTodayWordsCount()
        } else {
            didUpdateWordsCount()
        }

        switch listType {
        case .thought, .archive:
            FirebaseService.shared.thoughtsListener.multicast.add(self)
        case .project, .tag:
            FirebaseService.shared.tagsListener.multicast.add(self)
        }
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)

        setNeedsStatusBarAppearanceUpdate()

        view.bringSubviewToFront(alertLabel)

        if shouldShowWelcomeMessage {
            shouldShowWelcomeMessage = false

            DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) {
                self.showAlertLabel(message: "Welcome back, writer")
            }
        }
        
        switch listType {
        case .project, .tag:
            if let indexPath = selectedIndexPath {
                tableView.reloadRows(at: [indexPath], with: .automatic)
                selectedIndexPath = nil
            }
        default:
            break
        }
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()

        guard !didLayoutSubviews else { return }

        didLayoutSubviews = true

        guard let contentView = navigationController?.navigationBar.subviews.first(where: { String(describing: $0).contains("ContentView") }) else { return }

        for constraint in contentView.constraints {
            if constraint.firstAttribute == .trailing && constraint.secondAttribute == .trailing {
                constraint.constant = -4
            }
        }

        setupSearchController()
    }

    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }

    override var preferredStatusBarUpdateAnimation: UIStatusBarAnimation {
        return .fade
    }

    override var prefersStatusBarHidden: Bool {
        return isStatusBarHidden
    }

    private func setupKeyboardNotifications() {
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow), name: UIResponder.keyboardWillShowNotification, object: nil)

        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide), name: UIResponder.keyboardWillHideNotification, object: nil)
    }

    @objc private func keyboardWillShow(_ notification:Notification) {
        if let keyboardSize = (notification.userInfo?[UIResponder.keyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue {
            tableView.contentInset = UIEdgeInsets(top: 0, left: 0, bottom: keyboardSize.height, right: 0)
        }
    }

    @objc private func keyboardWillHide(_ notification:Notification) {
        tableView.contentInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
    }

    private func setupWordsCountNotifications() {
        NotificationCenter.default.addObserver(self, selector: #selector(didUpdateWordsCount), name: Notification.Name(Config.Notifications.didUpdateWordsCount), object: nil)
    }

    @objc private func didUpdateWordsCount() {
        guard listType != .archive, selectedTag == nil else { return }
        
        let imageName = UserDefaults.todayWordsCount >= Config.dailyWordsGoal ? "calendar-tick" : "calendar-badge"
        
        DispatchQueue.main.async {
            let button = UIButton(type: .custom) //(frame: CGRect(x: -40, y: 0, width: 32, height: 32))

            let image = UIImage(named: imageName)
            button.setImage(image, for: .normal)
            button.imageView?.contentMode = .scaleAspectFit
            button.frame = CGRect(x: 0, y: 0, width: 30, height: 30)
    //        button.imageEdgeInsets = UIEdgeInsets(top: 14, left: 0, bottom: 8, right: 0)

            let tapGesture = UITapGestureRecognizer(target: self, action: #selector(self.showWordsCalendar))
            button.addGestureRecognizer(tapGesture)

            self.calendarBarButton = UIBarButtonItem(customView: button)
            self.setupNavigationBar()
        }
    }

    private func setupNavigationBar() {
        navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)

        let menuButton = UIBarButtonItem(image: UIImage(named: "navigation-bar-burger"), style: .plain, target: self, action: #selector(showSettings))
        
        switch listType {
        case .project, .tag:
            let button = UIButton(frame: CGRect(x: -40, y: 0, width: 32, height: 32))

            let image = UIImage(named: "navigation-bar-new-\(listType.rawValue)")
            button.setImage(image, for: .normal)
            button.imageView?.contentMode = .scaleAspectFit
            button.imageEdgeInsets = UIEdgeInsets(top: 14, left: 0, bottom: 8, right: 0)

            let tapGesture = UITapGestureRecognizer(target: self, action: #selector(showNewProjectModal))
            button.addGestureRecognizer(tapGesture)

            let newProjectBarButtonItem = UIBarButtonItem(customView: button)
            navigationItem.rightBarButtonItems = [calendarBarButton, newProjectBarButtonItem].compactMap { $0 }
            navigationItem.leftBarButtonItem = menuButton
        case .thought:
            if selectedTag != nil {
                let editProjectBarButtonItem = UIBarButtonItem(image: UIImage(named: "navigation-bar-more"), style: .plain, target: self, action: #selector(editSelectedTag))
                navigationItem.rightBarButtonItems = [calendarBarButton, editProjectBarButtonItem].compactMap { $0 }
            } else {
                calendarBarButton?.customView?.frame = CGRect(x: 10, y: 0, width: 30, height: 30)
                navigationItem.rightBarButtonItem = calendarBarButton
                navigationItem.leftBarButtonItem = menuButton
            }
        case .archive:
            let closeBarButtonItem = UIBarButtonItem(image: UIImage(named: "back"), style: .plain, target: self, action: #selector(goBack))
            navigationItem.leftBarButtonItem = closeBarButtonItem
        }
    }
    
    @objc private func showSettings() {
        let vc = SettingsViewController.instantiate()
        vc.modalPresentationStyle = .overFullScreen
        vc.modalPresentationCapturesStatusBarAppearance = true
        present(vc, animated: true, completion: nil)
    }

    @objc private func showWordsCalendar() {
        let vc = WordsCalendarViewController.instantiate()
        present(vc, animated: true, completion: nil)
    }

    private func setupTableView() {
        tableView.separatorColor = .clear
        tableView.separatorStyle = .none
        tableView.isHidden = true
        tableView.dataSource = self
        tableView.delegate = self
        tableView.register(UINib(nibName: "ListItemTableViewCell", bundle: nil), forCellReuseIdentifier: "itemCell")

        addTableViewShadow()

        if (listType == .thought) {
            tableView.refreshControl = refreshControl
            refreshControl.addTarget(self, action: #selector(getData), for: .valueChanged)
        }
    }

    private func addTableViewShadow() {
        guard UIDevice.current.userInterfaceIdiom == .pad else { return }

        wrapTableView.layer.shadowColor = UIColor.black.cgColor
        wrapTableView.layer.shadowOpacity = 0.1
        wrapTableView.layer.shadowOffset = .zero
        wrapTableView.layer.shadowRadius = 20
        wrapTableView.layer.shadowPath = UIBezierPath(rect: tableView.bounds).cgPath
        wrapTableView.layer.rasterizationScale = UIScreen.main.scale
        wrapTableView.layer.shouldRasterize = true
    }

    private func setupSearchController() {
        guard UIDevice.current.userInterfaceIdiom != .pad else {
            searchBar.delegate = self
            setupSearchBar(searchBar)
            return
        }

        definesPresentationContext = true
        searchController.searchResultsUpdater = self
        searchController.obscuresBackgroundDuringPresentation = false
        setupSearchBar(searchController.searchBar)
        tableView.tableHeaderView = searchController.searchBar
    }

    private func setupSearchBar(_ searchBar: UISearchBar) {
        searchBar.backgroundColor = .white
        searchBar.searchBarStyle = .prominent
        searchBar.setBackgroundImage(UIImage(), for: .any, barMetrics: .default)
        searchBar.placeholder = "Search \(listType.rawValue)s"
        searchBar.textField?.backgroundColor = UIColor(red: 230/255, green: 230/255, blue: 230/255, alpha: 1)
        searchBar.textField?.textColor = UIColor(red: 70/255, green: 70/255, blue: 70/255, alpha: 1)
    }
    
    private func setupEmptyView() {
        emptyImageView.image = UIImage(named: listType.rawValue)
        emptyTitleLabel.text = "No \(listType.rawValue.capitalized)s"
        emptyMessageLabel.text = listType.emptyListMessage
        emptyView.isHidden = true
    }

    private func setupNotifications() {
        guard listType != .thought && listType != .archive else { return }
        NotificationCenter.default.addObserver(self, selector: #selector(getData), name: Notification.Name("thoughtsUpdated"), object: nil)
    }

    @objc private func editSelectedTag() {
        guard let tag = selectedTag else { return }

        let alertController = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)
        alertController.popoverPresentationController?.barButtonItem = navigationItem.rightBarButtonItem

        let exportAction = UIAlertAction(title: "Export Thoughts", style: .default) { [weak self] _ in
            self?.exportThoughts(tag: tag)
        }
        
        let editAction = UIAlertAction(title: "Edit \(tag.typeName) Name", style: .default) { [weak self] _ in
            self?.showRenameProjectModal(tag: tag)
        }

        let deleteAction = UIAlertAction(title: "Delete \(tag.typeName)", style: .destructive) { [weak self] _ in
            self?.showDeleteProjectModal(tag: tag)
        }

        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)

        alertController.addAction(exportAction)
        alertController.addAction(editAction)
        alertController.addAction(deleteAction)
        alertController.addAction(cancelAction)

        present(alertController, animated: true, completion: nil)
    }

    private func setupAlertLabel() {
        alertLabel.layer.cornerRadius = 24
        alertLabel.clipsToBounds = true
        alertLabel.isUserInteractionEnabled = false
        alertLabelMarginTop.constant = -120
    }

    func showAlertLabel(message: String) {
        DispatchQueue.main.async {
            UIView.performWithoutAnimation {
                self.alertLabel.setTitle(message, for: .normal)
                self.alertLabel.layoutIfNeeded()
            }

            if self.searchController.isActive {
                self.alertLabelMarginTop.constant = 0
                self.view.layoutIfNeeded()

                UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 0.8, initialSpringVelocity: 0.2, animations: {
                   self.alertLabelMarginTop.constant = 56
                   self.view.layoutIfNeeded()
               }, completion: nil)
            } else {
                UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 0.8, initialSpringVelocity: 0.2, animations: {
                    self.alertLabelMarginTop.constant = 4
                    self.view.layoutIfNeeded()
                }, completion: nil)
            }
        }

        DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
            UIView.animate(withDuration: 0.3, animations: {
                self.alertLabelMarginTop.constant = self.searchController.isActive ? 0 : -80
                self.view.layoutIfNeeded()
            }, completion: { _ in
                self.alertLabelMarginTop.constant = -120
            })
        }
    }
    
    func scrollToTop() {
        tableView.scrollToRow(at: IndexPath(row: 0, section: 0), at: .top, animated: true)
    }

    private func updateList(withReload: Bool = true) {
        switch listType {
        case .thought, .archive:
            updateView(isEmpty: thoughts.isEmpty, withReload: withReload)
        default:
            updateView(isEmpty: tags.isEmpty, withReload: withReload)
        }
    }

    private func updateView(isEmpty: Bool, withReload: Bool = true) {
        DispatchQueue.main.async {
            self.emptyView.isHidden = !isEmpty
            self.tableView.isHidden = isEmpty

            if (withReload) {
                self.tableView.reloadData()
                self.refreshControl.endRefreshing()
            }
        }
    }

    @objc private func getData() {
        switch listType {
        case .project:
            FirebaseService.shared.getUserTags(type: .project) { [weak self] projects in
                guard let self = self else { return }

                self.tags = projects
                self.updateList()
            }
        case .thought:
            promptsService.loadData()
            
            FirebaseService.shared.getUserThoughts { thoughts in
                if let tag = self.selectedTag {
                    self.thoughts = FirebaseService.shared.thoughts(for: tag)
                } else {
                    self.thoughts = thoughts
                }

                self.updateList()
            }
        case .archive:
            FirebaseService.shared.getUserArchivedThoughts { thoughts in
                self.thoughts = thoughts

                self.updateList()
            }
        case .tag:
            FirebaseService.shared.getUserTags(type: .tag) { tags in
                self.tags = tags
                self.updateList()
            }
        }
    }

    private func filterContentForSearchText(_ text: String) {
        self.searchText = text.lowercased()
        tableView.reloadData()
    }

    private func thoughtViewController(for indexPath: IndexPath, isPreview: Bool = false) -> UIViewController? {
        guard let tabBarController = tabBarController as? MainTabBarController else { return nil }

        let thought = isFiltering ? filteredThoughts[indexPath.row] : thoughts[indexPath.row]
        let vc = ThoughtViewController.instantiate(thought: thought, delegate: tabBarController, listDelegate: self, isPreview: isPreview)
        vc.modalPresentationCapturesStatusBarAppearance = true
        vc.modalPresentationStyle = .overFullScreen
        return vc
    }

    private func showShareSheet(thought: FBThought) {
        let activityVC = UIActivityViewController(activityItems: [thought.plainText], applicationActivities: nil)
        activityVC.popoverPresentationController?.sourceView = view
        activityVC.popoverPresentationController?.sourceRect = view.bounds

        present(activityVC, animated: true, completion: nil)
    }

    private func archive(thought: FBThought) {
        thought.isArchived = true
        remove(thought: thought)
    }

    // MARK: - Projects
    @objc private func showNewProjectModal() {
        let type: ModalType = listType == .project ? .newProject : .newTag
        showProjectModal(type: type)
    }
    
    private func exportThoughts(tag: FBTag) {
        let vc = ExportSelectionViewController.instantiate(withNavigationController: true, preselectedTag: tag)
        vc.modalPresentationStyle = .fullScreen
        present(vc, animated: true, completion: nil)
    }

    private func showRenameProjectModal(tag: FBTag) {
        let type: ModalType = tag.isPiece ? .editProject : .editTag
        showProjectModal(type: type, tag: tag)
    }

    private func showDeleteProjectModal(tag: FBTag) {
        let type: ModalType = tag.isPiece ? .deleteProject : .deleteTag
        showProjectModal(type: type, tag: tag)
    }

    private func showDeleteThoughtModal(thought: FBThought) {
        showProjectModal(type: .deleteThought, thought: thought)
    }

    private func showUnarchiveModal(thought: FBThought) {
        showProjectModal(type: .unarchiveThought, thought: thought)
    }

    private func showProjectModal(type: ModalType, tag: FBTag? = nil, thought: FBThought? = nil) {
        guard modalView == nil else { return }

        let height: CGFloat
        switch type {
        case .deleteThought, .deleteProject, .deleteTag, .unarchiveThought:
            height = 240
        default:
            height = 194
        }

        let width = min(view.frame.width - 20, 360)
        let x = (view.frame.width - width) / 2

        self.modalView = ProjectModalView(frame: CGRect(x: x, y: view.frame.height * 1.5, width: width, height: height))
        modalView?.setup(type: type)
        if let tag = tag {
            modalView?.setup(tag: tag)
        }
        if let thought = thought {
            modalView?.setup(thought: thought)
        }
        modalView?.delegate = self
        view.addSubview(modalView!)

        UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 0.8, initialSpringVelocity: 0.2, animations: {
            self.modalOverlayView.alpha = 0.3
            let centerY: CGFloat
            if UIDevice.current.userInterfaceIdiom == .pad && UIApplication.shared.statusBarOrientation.isLandscape {
                centerY = self.view.center.y - 250
            } else {
                centerY = self.view.center.y - 100
            }
            self.modalView?.center.y = centerY
        }, completion: { _ in
            self.modalView?.startEditing()
        })
    }
}

// MARK: - UITableViewDataSource
extension ListViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch listType {
        case .thought, .archive:
            return isFiltering ? filteredThoughts.count : thoughts.count
        default:
            return isFiltering ? filteredTags.count : tags.count
        }
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "itemCell", for: indexPath) as? ListItemTableViewCell
        else { return UITableViewCell() }

        let isFirstRow = indexPath.row == 0
        cell.setTopBorderView(isHidden: !isFirstRow)

        switch listType {
        case .thought, .archive:
            let thought = isFiltering ? filteredThoughts[indexPath.row] : thoughts[indexPath.row]
            cell.setup(thought: thought)
        default:
            let tag = isFiltering ? filteredTags[indexPath.row] : tags[indexPath.row]
            cell.setup(tag: tag)
        }

        return cell
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 65
    }

    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return UIView()
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        switch listType {
        case .thought:
            guard let vc = thoughtViewController(for: indexPath) else { return }
            if isFiltering {
                selectedIndexPath = indexPath
            }
            present(vc, animated: true, completion: nil)
        case .archive:
            let thought = isFiltering ? filteredThoughts[indexPath.row] : thoughts[indexPath.row]
            showUnarchiveModal(thought: thought)
        default:
            selectedIndexPath = indexPath
            let tag = isFiltering ? filteredTags[indexPath.row] : tags[indexPath.row]
            let vc = ListViewController.instantiate(listType: .thought, tag: tag)
            navigationController?.pushViewController(vc, animated: true)
        }
    }

    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        switch listType {
        case .thought, .archive:
            let thought = isFiltering ? filteredThoughts[indexPath.row] : thoughts[indexPath.row]
            let deleteAction = UIContextualAction(style: .normal, title: "Delete",
                                                  handler: { (action, view, completionHandler) in
                                                    self.showDeleteThoughtModal(thought: thought)
                                                    completionHandler(true)
            })
            deleteAction.backgroundColor = .red

            let configuration = UISwipeActionsConfiguration(actions: [deleteAction])
            return configuration
        case .project, .tag:
            let tag = isFiltering ? filteredTags[indexPath.row] : tags[indexPath.row]
            let renameAction = UIContextualAction(style: .normal, title: "Rename",
                                                   handler: { (action, view, completionHandler) in
                                                    self.showRenameProjectModal(tag: tag)
                                                    completionHandler(true)
            })
            renameAction.backgroundColor = UIColor(red: 2/255, green: 144/255, blue: 255/255, alpha: 1)

            let deleteAction = UIContextualAction(style: .normal, title: "Delete",
                                                  handler: { (action, view, completionHandler) in
                                                    self.showDeleteProjectModal(tag: tag)
                                                    completionHandler(true)
            })
            deleteAction.backgroundColor = .red
            let configuration = UISwipeActionsConfiguration(actions: [deleteAction, renameAction])
            return configuration
        }
    }

    func tableView(_ tableView: UITableView, leadingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        guard listType == .archive || listType == .thought else { return nil }

        let thought = isFiltering ? filteredThoughts[indexPath.row] : thoughts[indexPath.row]
        let archiveTitle = thought.isArchived ? "Unarchive" : "Archive"

        let archiveAction = UIContextualAction(style: .normal, title: archiveTitle) { (action, view, completionHandler) in
                                            thought.isArchived = !thought.isArchived
                                            self.remove(thought: thought)

                                            completionHandler(true)
        }
        archiveAction.backgroundColor = UIColor(red: 2/255, green: 144/255, blue: 255/255, alpha: 1)
        let configuration = UISwipeActionsConfiguration(actions: [archiveAction])
        return configuration
    }
    
    @available(iOS 13.0, *)
    func tableView(_ tableView: UITableView, contextMenuConfigurationForRowAt indexPath: IndexPath, point: CGPoint) -> UIContextMenuConfiguration? {
        UIContextMenuConfiguration(identifier: "\(indexPath.row)" as NSString, previewProvider: { [weak self] in
            guard let self = self else { return nil }
            let vc = self.thoughtViewController(for: indexPath, isPreview: true)!
            vc.preferredContentSize = CGSize(width: 0, height: 360)
            return vc
        }, actionProvider: nil)
    }
    
    @available(iOS 13.0, *)
    func tableView(_ tableView: UITableView, willPerformPreviewActionForMenuWith configuration: UIContextMenuConfiguration, animator: UIContextMenuInteractionCommitAnimating) {
        guard let identifier = configuration.identifier as? String,
              let index = Int(identifier)
        else { return }
        
        let indexPath = IndexPath(row: index, section: 0)
        
        guard let vc = thoughtViewController(for: indexPath) else { return }
        
        animator.addCompletion {
            self.present(vc, animated: true, completion: nil)
        }
    }
}

// MARK: - UISearchResultsUpdating
extension ListViewController: UISearchResultsUpdating {
    func updateSearchResults(for searchController: UISearchController) {
        filterContentForSearchText(searchController.searchBar.text ?? "")
    }
}

// MARK: - ProjectModalDelegate
extension ListViewController: ProjectModalDelegate {
    func didChange(tag: FBTag) {
        guard selectedTag != nil else { return }

        selectedTag = tag
        title = "\"\(tag.name)\""
    }

    func didDelete(tag: FBTag) {
        guard selectedTag != nil else { return }

        navigationController?.popViewController(animated: true)
    }

    func closeProjectModal(message: String?) {
        UIView.animate(withDuration: 0.3, animations: {
            self.modalView?.center.y = self.view.frame.height * 1.5
            self.modalOverlayView.alpha = 0
        }, completion: { _ in
            self.modalView = nil
            if let message = message {
                self.showAlertLabel(message: message)
            }
        })
    }
}

extension ListViewController: ThoughtListDelegate {
    func didSelect(action: ThoughtAction, for thought: FBThought) {
        switch action {
        case .share:
            DispatchQueue.main.async {
                self.showShareSheet(thought: thought)
            }
        case .archive:
            archive(thought: thought)
        case .delete:
            DispatchQueue.main.async {
                self.showDeleteThoughtModal(thought: thought)
            }
        }
    }
    
    func remove(thought: FBThought) {
        let filteredIndex = filteredThoughts.firstIndex(of: thought)
        
        guard let index = thoughts.firstIndex(of: thought) else {
            showAlertLabel(message: "Thought Deleted")
            return
        }

        thoughts.remove(at: index)
        
        if isFiltering {
            if let filteredIndex = filteredIndex {
                tableView.deleteRows(at: [IndexPath(row: filteredIndex, section: 0)], with: .automatic)
            }
        } else {
            tableView.deleteRows(at: [IndexPath(row: index, section: 0)], with: .automatic)
        }

        if thought.isArchived {
            showAlertLabel(message: "Thought sent to the Archives")
        } else if (listType == .archive) {
            showAlertLabel(message: "Thought Restored")
        } else {
            showAlertLabel(message: "Thought Deleted")
        }
    }
}

extension ListViewController: UIViewControllerPreviewingDelegate {
    func previewingContext(_ previewingContext: UIViewControllerPreviewing, viewControllerForLocation location: CGPoint) -> UIViewController? {
        guard let indexPath = tableView.indexPathForRow(at: location) else { return nil }

        previewingContext.sourceRect = tableView.rectForRow(at: indexPath)
        let vc = thoughtViewController(for: indexPath, isPreview: true)!
        vc.preferredContentSize = CGSize(width: 0, height: 360)
        return vc
    }

    func previewingContext(_ previewingContext: UIViewControllerPreviewing, commit viewControllerToCommit: UIViewController) {
        present(viewControllerToCommit, animated: true, completion: nil)
    }
}

extension ListViewController: ThoughtsListener {
    func didAdd(thought: FBThought) {
        guard (thought.isArchived && listType == .archive) || (!thought.isArchived && listType == .thought) else { return }
        
        guard selectedTag == nil || thought.contains(tag: selectedTag!) else { return }

        let initialNumberOfThoughts = isFiltering ? filteredThoughts.count : thoughts.count
        thoughts.insert(thought, at: 0)
        
        if !isFiltering || (isFiltering && filteredThoughts.contains(thought)) {
            tableView.beginUpdates()
            tableView.insertRows(at: [IndexPath(row: 0, section: 0)], with: .automatic)
            if (initialNumberOfThoughts > 0) {
                tableView.reloadRows(at: [IndexPath(row: 0, section: 0)], with: .automatic)
            }
            tableView.endUpdates()
        }

        updateList(withReload: false)
    }

    func didUpdated(thought: FBThought) {
        let filteredIndex = filteredThoughts.firstIndex(of: thought)

        if let index = self.thoughts.firstIndex(of: thought) {
            let indexPath: IndexPath?
            if !self.isFiltering {
                indexPath = IndexPath(row: index, section: 0)
            } else if let filteredIndex = filteredIndex {
                indexPath = IndexPath(row: filteredIndex, section: 0)
            } else {
                indexPath = nil
            }
            
            if let indexPath = indexPath, let cell = self.tableView.cellForRow(at: indexPath) as? ListItemTableViewCell {
                cell.setup(thought: thought)
            }
            
            self.thoughts.remove(at: index)

            self.tableView.beginUpdates()
            if (self.listType == .thought && thought.isArchived) || (self.listType == .archive && !thought.isArchived) {
                if !self.isFiltering {
                    self.tableView.deleteRows(at: [IndexPath(row: index, section: 0)], with: .automatic)
                } else if let selectedIndexPath = selectedIndexPath {
                    self.tableView.deleteRows(at: [selectedIndexPath], with: .automatic)
                    self.selectedIndexPath = nil
                }
            } else {
                self.thoughts.insert(thought, at: 0)
                
                if !self.isFiltering {
                    self.tableView.moveRow(at: IndexPath(row: index, section: 0), to: IndexPath(row: 0, section: 0))
                } else {
                    if let filteredIndex = filteredIndex, filteredThoughts.contains(thought) {
                        self.tableView.moveRow(at: IndexPath(row: filteredIndex, section: 0), to: IndexPath(row: 0, section: 0))
                    } else if let selectedIndexPath = selectedIndexPath {
                        self.tableView.deleteRows(at: [selectedIndexPath], with: .automatic)
                        self.selectedIndexPath = nil
                    }
                }
            }
            self.tableView.endUpdates()
        } else if (thought.isArchived && self.listType == .archive) || (!thought.isArchived && self.listType == .thought)  {
            if selectedTag == nil || thought.contains(tag: selectedTag!) {
                let initialNumberOfThoughts = self.isFiltering ? self.filteredThoughts.count : self.thoughts.count
                self.thoughts.insert(thought, at: 0)
            
                self.tableView.beginUpdates()
                if !self.isFiltering || self.filteredThoughts.contains(thought) {
                    self.tableView.insertRows(at: [IndexPath(row: 0, section: 0)], with: .automatic)
                    if (initialNumberOfThoughts > 0) {
                        self.tableView.reloadRows(at: [IndexPath(row: 0, section: 0)], with: .automatic)
                    }
                }
                
                self.tableView.endUpdates()
            }
        }
        
        self.updateList(withReload: false)
    }

    func didRemoved(thought: FBThought) {
        let filteredIndex = filteredThoughts.firstIndex(of: thought)
        
        guard let index = thoughts.firstIndex(of: thought) else { return }

        thoughts.remove(at: index)
        
        if !isFiltering {
            tableView.beginUpdates()
            tableView.deleteRows(at: [IndexPath(row: index, section: 0)], with: .automatic)
            tableView.endUpdates()
        } else if let filteredIndex = filteredIndex {
            tableView.beginUpdates()
            tableView.deleteRows(at: [IndexPath(row: filteredIndex, section: 0)], with: .automatic)
            tableView.endUpdates()
        } else if let selectedIndexPath = selectedIndexPath {
            tableView.beginUpdates()
            tableView.deleteRows(at: [selectedIndexPath], with: .automatic)
            tableView.endUpdates()
            self.selectedIndexPath = nil
        }

        updateList(withReload: false)
    }
}

extension ListViewController: TagsListener {
    func didAdd(tag: FBTag) {
        guard (tag.isPiece && listType == .project) || (!tag.isPiece && listType == .tag) else { return }
        tags.append(tag)
        tags.sort(by: { $0.name.lowercased() < $1.name.lowercased() })

        guard let index = tags.firstIndex(of: tag) else { return }
        tableView.beginUpdates()
        tableView.insertRows(at: [IndexPath(row: index, section: 0)], with: .automatic)
        tableView.endUpdates()

        updateList(withReload: false)
    }

    func didUpdated(tag: FBTag) {
        guard let index = tags.firstIndex(of: tag) else { return }

        tableView.beginUpdates()
        tags[index] = tag
        tableView.reloadRows(at: [IndexPath(row: index, section: 0)], with: .automatic)
        tableView.endUpdates()

        updateList(withReload: false)
    }

    func didRemoved(tag: FBTag) {
        guard let filteredIndex = filteredTags.firstIndex(of: tag),
              let index = tags.firstIndex(of: tag)
        else { return }

        tags.remove(at: index)

        tableView.beginUpdates()
        tableView.deleteRows(at: [IndexPath(row: filteredIndex, section: 0)], with: .automatic)
        tableView.endUpdates()

        updateList(withReload: false)
    }
}

extension ListViewController: UISearchBarDelegate {
    func searchBarShouldBeginEditing(_ searchBar: UISearchBar) -> Bool {
        searchBar.setShowsCancelButton(true, animated: true)
        return true
    }

    func searchBarShouldEndEditing(_ searchBar: UISearchBar) -> Bool {
        searchBar.setShowsCancelButton(false, animated: true)
        return true
    }

    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        filterContentForSearchText(searchText)
    }

    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searchBar.text = ""
        searchBar.endEditing(true)
        filterContentForSearchText("")
    }
}
