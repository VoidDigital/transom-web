//
//  NewThoughtViewController.swift
//  transom
//
//  Created by Roma Sosnovsky on 8/22/19.
//  Copyright © 2019 Void Digital. All rights reserved.
//

import UIKit

protocol ThoughtControllerDelegate: AnyObject {
    func didSave(thought: FBThought?, isNew: Bool)
}

protocol ThoughtListDelegate: AnyObject {
    func didSelect(action: ThoughtAction, for thought: FBThought)
    func remove(thought: FBThought)
}

class ThoughtViewController: UIViewController {
    @IBOutlet private weak var promptView: UIView!
    @IBOutlet private weak var promptViewZeroHeightConstraint: NSLayoutConstraint!
    @IBOutlet private weak var promptLabel: UILabel!
    @IBOutlet private weak var textView: UITextView!
    @IBOutlet private weak var placeholderLabel: UILabel!
    @IBOutlet private weak var placeholderLabelMarginLeft: NSLayoutConstraint!
    @IBOutlet private weak var toolbarView: UIScrollView!
    @IBOutlet private weak var toolbarMarginBottom: NSLayoutConstraint!
    @IBOutlet private weak var styleToolbarView: UIView!
    @IBOutlet private weak var styleToolbarViewMarginTop: NSLayoutConstraint!
    @IBOutlet private weak var previewToolbarView: UIView!
    @IBOutlet private weak var previewProjectButton: UIButton!
    @IBOutlet private weak var previewProjectButtonHeight: NSLayoutConstraint!
    @IBOutlet private weak var previewSeparatorView: UIView!
    @IBOutlet private weak var previewTagsButton: UIButton!
    @IBOutlet private weak var previewTagsButtonHeight: NSLayoutConstraint!
    @IBOutlet private weak var keyboardToggleButton: UIButton!
    @IBOutlet private weak var projectButton: UIButton!
    @IBOutlet private weak var projectButtonWidth: NSLayoutConstraint!
    @IBOutlet private weak var tagsButton: UIButton!
    @IBOutlet private weak var tagsButtonWidth: NSLayoutConstraint!

    private weak var delegate: ThoughtControllerDelegate?
    private weak var listDelegate: ThoughtListDelegate?

    private var modalOverlayView: UIView?
    private var modalView: ThoughtTagsView?
    private var alertModalView: ProjectModalView?
    
    private var isKeyboardVisible = true {
        didSet {
            let imageName = isKeyboardVisible ? "keyboard-hide" : "keyboard-show"
            keyboardToggleButton.setImage(UIImage(named: imageName), for: .normal)
        }
    }

    private var wordsCount: Int = 0 {
        didSet {
            guard UserDefaults.showWordsCount() else { return }

            updateNavigationSubtitle()
        }
    }

    private var initialText: String?
    private var typedWords = 0

    private var prompt: String?
    private var promptPackId: String?
    private var tags: [FBTag] = []
    private var filteredTags: [FBTag] = []
    private var selectedTags: [String] = []
    private var projectName: String?
    private var filterText = ""
    private let fontSize: CGFloat = 18

    private var thought: FBThought?
    private var thoughtTags: Set<FBTag> = []
    private var currentModalType: TagType = .project
    private var didLayoutSubviews = false
    private var shouldRemovePrompt = false

    private var navigationTitleLabel: UILabel!
    private var navigationSubtitleLabel: UILabel!
    private var lastUpdatedText: String?
    private var previousRect: CGRect = .zero
    private var isPreview = false

    private let maxTextWidth: CGFloat = 640
    private let textSidePadding: CGFloat = 12

    private var autosaveTimer: Timer?
    private let promptsService = PromptsService.shared
    
    private lazy var actionsButtonItem: UIBarButtonItem = {
        let actionsButton = UIButton(type: .custom)
        actionsButton.setImage(UIImage(named: "navigation-bar-more")?.withRenderingMode(.alwaysTemplate), for: [])
        actionsButton.addTarget(self, action: #selector(showThoughtActions), for: .touchUpInside)
        actionsButton.frame = CGRect(x: 0, y: 0, width: 30, height: 30)
        actionsButton.tintColor = .black
        let actionsButtonItem = UIBarButtonItem(customView: actionsButton)
        actionsButtonItem.tintColor = .black
        return actionsButtonItem
    }()
    
    private lazy var promptsButtonItem: UIBarButtonItem = {
        let promptsButton = UIButton(type: .custom)
        promptsButton.setImage(UIImage(named: "navigation-bar-prompt"), for: [])
        promptsButton.addTarget(self, action: #selector(showPromptsModal), for: .touchUpInside)
        promptsButton.frame = CGRect(x: 0, y: 0, width: 30, height: 30)
        return UIBarButtonItem(customView: promptsButton)
    }()

    static func instantiate(thought: FBThought? = nil,
                            prompt: String? = nil,
                            promptPackId: String? = nil,
                            tag: FBTag? = nil,
                            delegate: ThoughtControllerDelegate? = nil,
                            listDelegate: ThoughtListDelegate? = nil,
                            isPreview: Bool = false) -> UIViewController {
        let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ThoughtViewController") as! ThoughtViewController
        vc.prompt = prompt ?? thought?.prompt
        vc.promptPackId = promptPackId ?? thought?.promptPackId
        vc.shouldRemovePrompt = prompt != nil
        vc.delegate = delegate
        vc.listDelegate = listDelegate
        vc.thought = thought
        vc.isPreview = isPreview

        if let tag = tag {
            if tag.isPiece {
                vc.projectName = tag.name
            } else {
                vc.selectedTags = [tag.name]
            }
        }
        
        return ThoughtNavigationController.instantiate(thought: thought, rootViewController: vc, previewDelegate: listDelegate)
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        setupTextView()
        setupKeyboard()
        setupToolbar()
        addLeftBarButtonItem()
        updateLeftBarButtonItem()

        getAllTags()
        setupThoughtData()
        setupAutosave()
        
        updateProjectButton()
        updateTagsButton()
        setupPreviewView()

        NotificationCenter.default.addObserver(self, selector: #selector(updateTextViewPadding), name: UIDevice.orientationDidChangeNotification, object: nil)
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)

        if thought == nil {
            textView.becomeFirstResponder()
        }

        setNeedsStatusBarAppearanceUpdate()
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)

        view.endEditing(true)

        NotificationCenter.default.post(name: Notification.Name("thoughtsUpdated"), object: nil)

        stopAutosaveTimer(withSave: false)
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()

        guard !didLayoutSubviews else { return }

        didLayoutSubviews = true
        textView.setContentOffset(.zero, animated: false)
    }

    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .default
    }

    private func setupTextView() {
        let paragraphStyle = NSMutableParagraphStyle()
        paragraphStyle.lineSpacing = 3
        let attrs: [NSAttributedString.Key: Any] = [.paragraphStyle: paragraphStyle, .font: UIFont(name: ThoughtFont.regular.rawValue, size: fontSize)!, .foregroundColor: UIColor(red: 56/255, green: 56/255, blue: 56/255, alpha: 1), .kern: 0.6]
        textView.typingAttributes = attrs

        if let thought = thought {
            isKeyboardVisible = false
            if let attributedString = thought.attributedString {
                textView.attributedText = attributedString
            } else {
                textView.attributedText = NSAttributedString(string: thought.plainText, attributes: attrs)
            }
            placeholderLabel.isHidden = true
            wordsCount = textView.text.components(separatedBy: .whitespacesAndNewlines).filter { !$0.isEmpty }.count
        }

        textView.delegate = self

        styleToolbarViewMarginTop.constant = 45

        updateTextViewPadding()
    }

    @objc private func updateTextViewPadding() {
        guard UIDevice.current.userInterfaceIdiom == .pad else {
            textView.textContainerInset = UIEdgeInsets(top: 16, left: textSidePadding, bottom: 16, right: textSidePadding)
            textView.layoutIfNeeded()
            return
        }

        let currentWidth = didLayoutSubviews ? UIScreen.main.bounds.height : UIScreen.main.bounds.width

        if currentWidth > maxTextWidth + 2 * textSidePadding {
            let sidePadding = (currentWidth - maxTextWidth) / 2
            textView.textContainerInset = UIEdgeInsets(top: 16, left: textSidePadding + sidePadding, bottom: 16, right: textSidePadding + sidePadding)
        } else {
            textView.textContainerInset = UIEdgeInsets(top: 16, left: textSidePadding, bottom: 16, right: textSidePadding)
        }

        textView.layoutIfNeeded()

        placeholderLabelMarginLeft.constant = textView.textContainerInset.left + 8
        view.layoutIfNeeded()
    }

    private func setupThoughtData() {
        promptLabel.text = prompt
        
        setupNavigationBarButtons()
        
        guard let thought = thought else { return }

        initialText = thought.text
        thoughtTags = FBThought.tagsFrom(combinedTagNames: thought.tagNames)

        let updatedAtDate = Date(timeIntervalSince1970: thought.updatedAt / 1000)
        lastUpdatedText = updatedAtDate.relativeDateString

        updateNavigationSubtitle()

        if let project = thoughtTags.first(where: { $0.isPiece }) {
            projectName = project.name
            updateProjectButton()
        }

        let tags = thoughtTags.filter { !$0.isPiece }
        if !tags.isEmpty {
            selectedTags = tags.map { $0.name }
            updateTagsButton()
        }
    }
    
    private func setupNavigationBarButtons() {
        promptLabel.text = thought?.prompt ?? prompt
        
        let hasPrompt = !(promptLabel.text ?? "").isEmpty
        promptView.isHidden = !hasPrompt
        promptViewZeroHeightConstraint.isActive = !hasPrompt
  
        if hasPrompt || !textView.text.isEmpty {
            navigationItem.rightBarButtonItem = thought != nil ? actionsButtonItem : nil
        } else {
            navigationItem.rightBarButtonItems = thought != nil ? [actionsButtonItem, promptsButtonItem] : [promptsButtonItem]
        }
    }

    private func setupAutosave() {
        startAutosaveTimer()

        NotificationCenter.default.addObserver(self, selector: #selector(startAutosaveTimer), name: UIApplication.willEnterForegroundNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(goToBackground), name: UIApplication.willResignActiveNotification, object: nil)
    }

    @objc private func startAutosaveTimer() {
        autosaveTimer = Timer.scheduledTimer(timeInterval: 60, target: self, selector: #selector(autosaveThought), userInfo: nil, repeats: true)
    }

    @objc private func stopAutosaveTimer(withSave: Bool = true) {
        if withSave {
            autosaveThought()
        }

        autosaveTimer?.invalidate()
        autosaveTimer = nil
    }

    @objc private func goToBackground() {
        stopAutosaveTimer(withSave: true)
        updateDailyWords()
    }

    private func setupNavigationBar() {
        guard navigationTitleLabel == nil && navigationSubtitleLabel == nil else { return }

        navigationTitleLabel = UILabel()
        navigationTitleLabel.font = UIFont.systemFont(ofSize: 16, weight: .medium)
        navigationTitleLabel.textColor = UIColor(red: 65/255, green: 65/255, blue: 65/255, alpha: 1)
        navigationTitleLabel.text = "Thought"
        navigationTitleLabel.sizeToFit()

        navigationSubtitleLabel = UILabel()
        navigationSubtitleLabel.font = UIFont.systemFont(ofSize: 12)
        navigationSubtitleLabel.textColor = UIColor(red: 162/255, green: 168/255, blue: 172/255, alpha: 1)
        navigationSubtitleLabel.textAlignment = .center

        let stackView = UIStackView(arrangedSubviews: [navigationTitleLabel, navigationSubtitleLabel])
        stackView.distribution = .equalCentering
        stackView.axis = .vertical
        stackView.alignment = .center

        let width = max(navigationTitleLabel.frame.size.width, navigationSubtitleLabel.frame.size.width)
        stackView.frame = CGRect(x: 0, y: 0, width: width, height: 35)

        navigationTitleLabel.sizeToFit()
        navigationSubtitleLabel.sizeToFit()

        navigationItem.titleView = stackView
    }

    private func setupPreviewView() {
        guard isPreview else { return }

        toolbarMarginBottom.constant = -45

        if let projectName = projectName {
            previewProjectButton.setTitle(projectName, for: .normal)
            previewToolbarView.isHidden = false
        } else {
            previewProjectButtonHeight.constant = 0
        }

        let tagsList = selectedTags.joined(separator: ", ")
        if !tagsList.isEmpty {
            previewTagsButton.setTitle(tagsList, for: .normal)
            previewToolbarView.isHidden = false
        } else {
            previewTagsButtonHeight.constant = 0
        }

        if projectName == nil || tagsList.isEmpty {
            previewSeparatorView.isHidden = true
        }
    }

    private func setupKeyboard() {
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillChangeFrame), name: UIResponder.keyboardWillChangeFrameNotification, object: nil)
    }

    @objc private func keyboardWillChangeFrame(notification: NSNotification) {
        guard modalView == nil,
              let keyboardScreenEndFrame = (notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue
        else { return }

        let keyboardOffset = view.frame.size.height - keyboardScreenEndFrame.origin.y
        isKeyboardVisible = keyboardOffset > 0
        let marginBottom: CGFloat

        if isKeyboardVisible {
            marginBottom = keyboardOffset - view.safeAreaInsets.bottom
        } else {
            marginBottom = 0
        }

        if toolbarMarginBottom.constant != marginBottom {
            toolbarMarginBottom.constant = marginBottom
            view.layoutIfNeeded()
        }
    }

    private func updateDailyWords() {
        guard typedWords > 0 else { return }

        FirebaseService.shared.updateDailyWordsCount(typedWords)
    }

    private func updateNavigationSubtitle() {
        guard thought != nil || UserDefaults.showWordsCount() else { return }

        setupNavigationBar()

        if UserDefaults.showWordsCount() {
            let wordsCountSuffix = wordsCount == 1 ? "word" : "words"
            let wordsCountText = "\(wordsCount) \(wordsCountSuffix)"
            navigationSubtitleLabel.text = [lastUpdatedText, wordsCountText].compactMap { $0 }.joined(separator: " • ")
        } else if let lastUpdatedText = lastUpdatedText {
            navigationSubtitleLabel.text = lastUpdatedText
        }

        navigationSubtitleLabel.sizeToFit()
    }

    private func showTagsModal(type: TagType) {
        guard let navigationController = navigationController else { return }

        toolbarMarginBottom.constant = 0

        modalOverlayView = UIView(frame: navigationController.view.frame)
        modalOverlayView?.backgroundColor = UIColor(red: 0/255, green: 41/255, blue: 105/255, alpha: 1)
        modalOverlayView?.alpha = 0
        navigationController.view.addSubview(modalOverlayView!)

        let width = min(view.frame.width - 20, 360)
        let x = (view.frame.width - width) / 2
        modalView = ThoughtTagsView(frame: CGRect(x: x, y: 1.5 * view.frame.height, width: width, height: 320))
        modalView?.delegate = self
        navigationController.view.addSubview(modalView!)

        view.endEditing(true)

        currentModalType = type

        let currentTags: [String]
        let modalTags: [FBTag]
        switch type {
        case .project:
            currentTags = [projectName].compactMap { $0 }
            modalTags = tags.filter { $0.isPiece }
        case .tag:
            currentTags = selectedTags
            modalTags = tags.filter { !$0.isPiece }
        }
        modalView?.setup(type: type, tags: currentTags, allTags: modalTags)

        UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 0.8, initialSpringVelocity: 0.2, animations: {
            self.modalOverlayView?.alpha = 0.45
            let centerY: CGFloat
            if UIDevice.current.userInterfaceIdiom == .pad && UIApplication.shared.statusBarOrientation.isLandscape {
                centerY = navigationController.view.frame.height + 360
            } else {
                centerY = navigationController.view.frame.height + 230
            }
            self.modalView?.center.y -= centerY
            self.view.layoutIfNeeded()
        }, completion: { _ in
            self.modalView?.focusInput()
        })
    }

    private func addLeftBarButtonItem() {
        let button = UIBarButtonItem(image: UIImage(named: "navigation-bar-tick"), style: .plain, target: self, action: #selector(closeThought))
        navigationItem.leftBarButtonItem = button
    }

    private func updateLeftBarButtonItem() {
        guard thought == nil else { return }

        let imageName = textView.text.isEmpty ? "navigation-bar-cross" : "navigation-bar-tick"
        navigationItem.leftBarButtonItem?.image = UIImage(named: imageName)
    }
    
    @objc private func showPromptsModal() {
        view.endEditing(true)
  
        let vc = PromptsViewController.instantiate(delegate: self)
        present(vc, animated: true)
    }

    @objc private func showThoughtActions() {
        let alertController = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)
        alertController.popoverPresentationController?.barButtonItem = navigationItem.rightBarButtonItem

        let shareAction = UIAlertAction(title: "Share this Thought", style: .default) { _ in
            DispatchQueue.main.async {
                self.showShareSheet()
            }
        }

        let archiveAction = UIAlertAction(title: "Send to Archives", style: .default) { _ in
            guard let thought = self.thought else { return }

            thought.isArchived = true
            self.listDelegate?.remove(thought: thought)
            self.dismiss(animated: true, completion: nil)
        }

        let deleteAction = UIAlertAction(title: "Delete it Forever", style: .destructive) { _ in
            self.showDeleteModal()
        }

        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)

        alertController.addAction(shareAction)
        alertController.addAction(archiveAction)
        alertController.addAction(deleteAction)
        alertController.addAction(cancelAction)

        present(alertController, animated: true, completion: nil)
    }

    private func showShareSheet() {
        guard let thought = thought else { return }

        let activityVC = UIActivityViewController(activityItems: [thought.plainText], applicationActivities: nil)
//        activityVC.popoverPresentationController?.sourceView = view
//        activityVC.popoverPresentationController?.sourceRect = view.bounds
        activityVC.popoverPresentationController?.barButtonItem = navigationItem.rightBarButtonItem

        present(activityVC, animated: true, completion: nil)
    }

    private func setupToolbar() {
        [keyboardToggleButton, projectButton, tagsButton].forEach {
            $0?.layer.cornerRadius = 3
            $0?.layer.borderWidth = 0.5
            $0?.layer.borderColor = UIColor(named: "Toolbar Button Background")!.cgColor
            $0?.clipsToBounds = true
        }
    }

    @objc private func closeThought() {
        saveThought(withDismiss: true)
        updateDailyWords()
    }

    private func saveThought(withDismiss: Bool = true) {
        let isNew = thought == nil

        let didThoughtChanged: Bool

        if let thought = thought {
            if let oldAttributedString = thought.attributedString {
                didThoughtChanged = textView.attributedText != oldAttributedString
            } else {
                let paragraphStyle = NSMutableParagraphStyle()
                paragraphStyle.lineSpacing = 3
                let attrs: [NSAttributedString.Key: Any] = [.paragraphStyle: paragraphStyle, .font: UIFont(name: ThoughtFont.regular.rawValue, size: fontSize)!, .foregroundColor: UIColor(red: 56/255, green: 56/255, blue: 56/255, alpha: 1), .kern: 0.6]
                let oldAttributedString = NSAttributedString(string: thought.plainText, attributes: attrs)
                didThoughtChanged = textView.attributedText != oldAttributedString
            }
        } else {
            didThoughtChanged = true
        }

        let isThoughtEmpty = textView.text.isEmpty

        if let attributedText = textView.attributedText {
            let documentAttributes: [NSAttributedString.DocumentAttributeKey: Any] = [.documentType: NSAttributedString.DocumentType.html]
            do {
                let htmlData = try attributedText.data(from: NSRange(location: 0, length: attributedText.length), documentAttributes: documentAttributes)
                var htmlString = String(data: htmlData, encoding: .utf8) ?? ""
                htmlString = htmlString.replacingOccurrences(of: "<span class=\"s1\"></span><br></p>", with: "<span class=\"s1\"></span></p>")

                if isNew {
                    if !isThoughtEmpty {
                        createThought(withText: htmlString, isAutosave: !withDismiss)
                    }
                } else {
                    guard !isThoughtEmpty else {
                        if withDismiss {
                            if let thought = thought {
                                if let prompt = thought.prompt {
                                    promptsService.add(prompt: prompt, packId: promptPackId)
                                }
                                thought.delete()
                                listDelegate?.remove(thought: thought)
                            }
                            
                            dismiss(animated: true)
                        }
                        return
                    }

                    if didThoughtChanged {
                        updateThought(withText: htmlString, isAutosave: !withDismiss)
                    }
                }

                if withDismiss {
                    dismiss(animated: true) {
                        if didThoughtChanged && !isThoughtEmpty {
                            self.delegate?.didSave(thought: self.thought, isNew: isNew)
                        }
                    }
                }
            } catch {
                print(error)
            }
        }
    }

    private func createThought(withText text: String, isAutosave: Bool = false) {
        FBThought.createThought(text: text, prompt: prompt, promptPackId: promptPackId, tags: selectedTags, projectName: projectName) { [weak self] thought in
            guard let self = self else { return }
            
            if isAutosave {
                self.thought = thought
                self.updateLastUpdatedLabel()
            }
            if let prompt = self.prompt, self.shouldRemovePrompt {
                self.shouldRemovePrompt = false
                self.promptsService.use(prompt: prompt, packId: self.promptPackId)
            }
        }
    }

    private func updateThought(withText text: String, isAutosave: Bool = false) {
        thought?.update(withText: text, prompt: prompt, promptPackId: promptPackId)

        if isAutosave {
            updateLastUpdatedLabel()
        }
        if let prompt = self.prompt, self.shouldRemovePrompt {
            self.shouldRemovePrompt = false
            promptsService.use(prompt: prompt, packId: self.promptPackId)
        }
    }

    @objc private func autosaveThought() {
        saveThought(withDismiss: false)
    }

    private func updateLastUpdatedLabel() {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "h:mm a"
        lastUpdatedText = "Saved at \(dateFormatter.string(from: Date()))"
        updateNavigationSubtitle()
    }

    private func getAllTags() {
        FirebaseService.shared.getUserTags { tags in
            self.tags = tags
        }
    }

    private func updateProjectButton() {
        let projectButtonTitle = projectName ?? "Add to Project"
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 13)
        label.text = projectButtonTitle
        let size = label.sizeThatFits(toolbarView.frame.size)
        projectButton.setTitle(projectButtonTitle, for: .normal)
        projectButtonWidth.constant = size.width + 46

        updateToolbarButton(projectButton, isActive: projectName != nil)
    }

    private func updateTagsButton() {
        let tagsButtonTitle = selectedTags.isEmpty ? "Add Tags" : selectedTags.joined(separator: ", ")
        let width: CGFloat

        if !selectedTags.isEmpty {
            let label = UILabel()
            label.font = UIFont.systemFont(ofSize: 13)
            label.text = tagsButtonTitle
            let size = label.sizeThatFits(toolbarView.frame.size)
            width = size.width + 46

            tagsButton.layer.borderColor = UIColor(red: 170/255, green: 169/255, blue: 169/255, alpha: 1).cgColor
            tagsButton.titleLabel?.textColor = UIColor(red: 107/255, green: 108/255, blue: 108/255, alpha: 1)
            tagsButton.tintColor = UIColor(red: 107/255, green: 108/255, blue: 108/255, alpha: 1)
        } else {
            width = 96
            tagsButton.layer.borderColor = UIColor(named: "Toolbar Button Background")!.cgColor
            tagsButton.titleLabel?.textColor = UIColor(named: "Toolbar Button Text")
            tagsButton.tintColor = UIColor(named: "Toolbar Button Text")
        }

        tagsButton.setTitle(tagsButtonTitle, for: .normal)
        tagsButtonWidth.constant = width

        updateToolbarButton(tagsButton, isActive: !selectedTags.isEmpty)
    }

    private func showDeleteModal() {
        guard let thought = thought, let navigationController = navigationController else { return }

        modalOverlayView = UIView(frame: navigationController.view.frame)
        modalOverlayView?.backgroundColor = UIColor(red: 0/255, green: 41/255, blue: 105/255, alpha: 1)
        modalOverlayView?.alpha = 0
        navigationController.view.addSubview(modalOverlayView!)

        let width = min(view.frame.width - 20, 360)
        let x = (view.frame.width - width) / 2

        self.alertModalView = ProjectModalView(frame: CGRect(x: x, y: view.frame.height * 1.5, width: width, height: 240))
        alertModalView?.setup(type: .deleteThought)
        alertModalView?.setup(thought: thought)
        alertModalView?.delegate = self
        navigationController.view.addSubview(alertModalView!)

        UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 0.8, initialSpringVelocity: 0.2, animations: {
            self.modalOverlayView?.alpha = 0.45
            let centerY: CGFloat
            if UIDevice.current.userInterfaceIdiom == .pad && UIApplication.shared.statusBarOrientation.isLandscape {
                centerY = navigationController.view.frame.height + 360
            } else {
                centerY = navigationController.view.frame.height + 230
            }
            self.alertModalView?.center.y -= centerY
            self.view.layoutIfNeeded()
        }, completion: { _ in })
    }

    private func updateToolbarButton(_ button: UIButton, isActive: Bool) {
        if isActive {
            button.layer.borderColor = UIColor(red: 170/255, green: 169/255, blue: 169/255, alpha: 1).cgColor
            button.setTitleColor(UIColor(red: 107/255, green: 108/255, blue: 108/255, alpha: 1), for: .normal)
            button.tintColor = UIColor(red: 107/255, green: 108/255, blue: 108/255, alpha: 1)
        } else {
            button.layer.borderColor = UIColor(named: "Toolbar Button Background")!.cgColor
            button.setTitleColor(UIColor(named: "Toolbar Button Text"), for: .normal)
            button.tintColor = UIColor(named: "Toolbar Button Text")
        }
    }

    // MARK: - IBActions
    @IBAction private func toggleKeyboard(_ sender: Any) {
        if isKeyboardVisible {
            view.endEditing(true)
        } else {
            textView.becomeFirstResponder()
        }
    }

    @IBAction private func changeProject(_ sender: Any) {
        showTagsModal(type: .project)
    }

    @IBAction private func updateTags(_ sender: Any) {
        showTagsModal(type: .tag)
    }

    @IBAction func toggleBold(_ sender: Any) {
        let attributedString = NSAttributedString(attributedString: textView.attributedText)

        attributedString.enumerateAttribute(.font, in: textView.selectedRange, options: []) { (font, range, pointee) in
            guard let font = font as? UIFont else { return }

            let newFont: UIFont
            switch font.fontName {
            case ThoughtFont.bold.rawValue:
                newFont = UIFont(name: ThoughtFont.regular.rawValue, size: fontSize)!
            case ThoughtFont.boldItalic.rawValue:
                newFont = UIFont(name: ThoughtFont.italic.rawValue, size: fontSize)!
            case ThoughtFont.italic.rawValue:
                newFont = UIFont(name: ThoughtFont.boldItalic.rawValue, size: fontSize)!
            default:
                newFont = UIFont(name: ThoughtFont.bold.rawValue, size: fontSize)!
            }

            textView.textStorage.addAttributes([.font : newFont], range: range)
        }
    }

    @IBAction func toggleTextUnderline(_ sender: Any) {
        let attributedString = NSAttributedString(attributedString: textView.attributedText)

        attributedString.enumerateAttribute(.underlineStyle, in: textView.selectedRange, options: []) { (value, range, pointee) in
            if value != nil {
                textView.textStorage.removeAttribute(.underlineStyle, range: range)
            } else {
                textView.textStorage.addAttribute(.underlineStyle, value: NSUnderlineStyle.single.rawValue, range: range)
            }
        }
    }
    
    @IBAction func toggleItalic(_ sender: Any) {
        let attributedString = NSAttributedString(attributedString: textView.attributedText)

        attributedString.enumerateAttribute(.font, in: textView.selectedRange, options: []) { (font, range, pointee) in
            guard let font = font as? UIFont else { return }

            let newFont: UIFont
            switch font.fontName {
            case ThoughtFont.bold.rawValue:
                newFont = UIFont(name: ThoughtFont.boldItalic.rawValue, size: fontSize)!
            case ThoughtFont.boldItalic.rawValue:
                newFont = UIFont(name: ThoughtFont.bold.rawValue, size: fontSize)!
            case ThoughtFont.italic.rawValue:
                newFont = UIFont(name: ThoughtFont.regular.rawValue, size: fontSize)!
            default:
                newFont = UIFont(name: ThoughtFont.italic.rawValue, size: fontSize)!
            }

            textView.textStorage.addAttribute(.font, value: newFont, range: range)
        }
    }
}

// MARK: - UITextViewDelegate
extension ThoughtViewController: UITextViewDelegate {
    func textViewDidChange(_ textView: UITextView) {
        placeholderLabel.isHidden = !textView.text.isEmpty

        wordsCount = textView.text.components(separatedBy: .whitespacesAndNewlines).filter { !$0.isEmpty }.count

        updateLeftBarButtonItem()
        setupNavigationBarButtons()
    }

    func textViewDidChangeSelection(_ textView: UITextView) {
        let alpha: CGFloat = textView.selectedRange.length > 0 ? 1 : 0

        guard styleToolbarView.alpha != alpha else { return }

        UIView.animate(withDuration: 0.4) {
            self.styleToolbarView.alpha = alpha
            self.styleToolbarViewMarginTop.constant = textView.selectedRange.length > 0 ? 0 : 45
            self.view.layoutIfNeeded()
        }
    }

    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        if (text.count > 1) {
            typedWords += text.components(separatedBy: .whitespacesAndNewlines).filter { !$0.isEmpty }.count
        }

        var previousCharacter: Character?
        if (!text.isEmpty && !text.contains("'") && text.trimmingCharacters(in: .whitespacesAndNewlines).trimmingCharacters(in: .punctuationCharacters).isEmpty) {
            let currentText = Array(textView.text)
            let previousCharacterIndex = range.location - 1

            if currentText.indices.contains(previousCharacterIndex) {
                previousCharacter = currentText[previousCharacterIndex]

                if (previousCharacter!.isLetter || previousCharacter!.isNumber) {
                    typedWords += 1
                }
            }
        }
        
        let fullText = textView.text as NSString
        let precedingText = fullText.substring(to: range.upperBound)
        let precedingLines = precedingText.components(separatedBy: .newlines)

        guard let precedingLineString = precedingLines.last else { return true }

        let precedingLineNSString = precedingLineString as NSString

        if text.first == "-" && (previousCharacter == nil || previousCharacter!.isNewline) {
            let paragraphStyle = NSMutableParagraphStyle()
            paragraphStyle.lineSpacing = 3
            paragraphStyle.headIndent = 18
            paragraphStyle.firstLineHeadIndent = 6
            let attrs: [NSAttributedString.Key: Any] =
                [.paragraphStyle: paragraphStyle, .font: UIFont(name: ThoughtFont.regular.rawValue, size: fontSize)!, .foregroundColor: UIColor(red: 56/255, green: 56/255, blue: 56/255, alpha: 1), .kern: 0.6]

            let string = NSAttributedString(string: "• ", attributes: attrs)
            textView.textStorage.replaceCharacters(in: range, with: string)

            let estimatedCursor = NSMakeRange(range.location + 2, 0)
            textView.selectedRange = estimatedCursor

            return false
        } else if text.first == "\n" {
            guard let filledLineRegex = try? NSRegularExpression(pattern: "^(?:(?:(\\d+).)|([-+*•]))\\s.+$", options: .anchorsMatchLines) else { return true }

            let options = NSRegularExpression.MatchingOptions(rawValue: 0)
            let precedingLineRange = NSMakeRange(0, precedingLineNSString.length)

            if let match = filledLineRegex.matches(in: precedingLineString, options: options, range: precedingLineRange).first {
                let bulletRange = match.range(at: 2)
                if bulletRange.location != NSNotFound {
                    let paragraphStyle = NSMutableParagraphStyle()
                    paragraphStyle.lineSpacing = 3
                    paragraphStyle.headIndent = 18
                    paragraphStyle.firstLineHeadIndent = 6
                    let attrs: [NSAttributedString.Key: Any] =
                        [.paragraphStyle: paragraphStyle, .font: UIFont(name: ThoughtFont.regular.rawValue, size: fontSize)!, .foregroundColor: UIColor(red: 56/255, green: 56/255, blue: 56/255, alpha: 1), .kern: 0.6]
                    let newText = "\(text)• "
                    let string = NSAttributedString(string: newText, attributes: attrs)

                    textView.textStorage.replaceCharacters(in: range, with: string)

                    let estimatedCursor = NSMakeRange(range.location + newText.count, 0)
                    textView.selectedRange = estimatedCursor

                    return false
                }
            }

            guard let emptyLineRegex = try? NSRegularExpression(pattern: "^([-+*•])\\s?$", options: .anchorsMatchLines) else { return true }

            if let _ = emptyLineRegex.matches(in: precedingLineString, options: options, range: precedingLineRange).first {
                let updatingRange = (precedingText as NSString).range(of: precedingLineString, options: .backwards)

                let paragraphStyle = NSMutableParagraphStyle()
                paragraphStyle.lineSpacing = 3
                paragraphStyle.headIndent = 0
                paragraphStyle.firstLineHeadIndent = 0
                let attrs: [NSAttributedString.Key: Any] =
                    [.paragraphStyle: paragraphStyle, .font: UIFont(name: ThoughtFont.regular.rawValue, size: fontSize)!, .foregroundColor: UIColor(red: 56/255, green: 56/255, blue: 56/255, alpha: 1), .kern: 0.6]
                let string = NSAttributedString(string: " ", attributes: attrs)
                textView.textStorage.replaceCharacters(in: updatingRange, with: string)

                let estimatedCursor = NSMakeRange(updatingRange.location, 0)
                textView.selectedRange = estimatedCursor

                return false
            }
        }

        return true
    }
}

// MARK: - ThoughtTagsViewDelegate
extension ThoughtViewController: ThoughtTagsViewDelegate {
    func update(tags: [String], type: TagType) {
        view.endEditing(true)

        switch currentModalType {
        case .project:
            projectName = tags.first
            updateProjectButton()

            if let thought = thought {
                if let projectName = projectName {
                    FBTag.createTag(name: projectName, isProject: true) { tag in
                        var tags = thought.tags.filter { !$0.isPiece }
                        tags.insert(tag)
                        thought.update(withTags: tags)
                    }
                } else {
                    let tags = thought.tags.filter { !$0.isPiece }
                    thought.update(withTags: tags)
                }
            }
        case .tag:
            self.selectedTags = tags
            if let thought = thought {
                if tags.isEmpty {
                    let thoughtTags = thought.tags.filter { $0.isPiece }
                    thought.update(withTags: thoughtTags)
                } else {
                    var thoughtTags: Set<FBTag> = []
                    tags.forEach { tag in
                        FBTag.createTag(name: tag, isProject: false) { tag in
                            thoughtTags.insert(tag)
                            if thoughtTags.count == tags.count {
                                var allTags = thought.tags.filter { $0.isPiece }
                                thoughtTags.forEach { newTag in
                                    allTags.insert(newTag)
                                }
                                thought.update(withTags: allTags)
                            }
                        }
                    }
                }
            }
            updateTagsButton()
        }

        UIView.animate(withDuration: 0.4, animations: {
            self.modalOverlayView?.alpha = 0
            self.modalView?.center.y += UIScreen.main.bounds.height
        }, completion: { _ in
            self.modalOverlayView = nil
            self.modalView = nil
        })
    }
}

// MARK: - ProjectModalDelegate
extension ThoughtViewController: ProjectModalDelegate {
    func didChange(tag: FBTag) { }

    func didDelete(tag: FBTag) { }

    func closeProjectModal(message: String?) {
        guard let thought = thought else { return }

        UIView.animate(withDuration: 0.3, animations: {
            self.alertModalView?.center.y = self.view.frame.height * 1.5
            self.modalOverlayView?.alpha = 0
        }, completion: { _ in
            self.alertModalView = nil
            self.modalOverlayView = nil

            if message != nil {
                self.listDelegate?.remove(thought: thought)
                self.dismiss(animated: true, completion: nil)
            }
        })
    }
}

extension ThoughtViewController: PromptsViewDelegate {
    func didSelect(prompt: String, promptPackId: String?) {
        self.prompt = prompt
        self.promptPackId = promptPackId
        self.shouldRemovePrompt = true
        self.thought?.prompt = prompt
        setupNavigationBarButtons()

        textView.becomeFirstResponder()
    }
}
