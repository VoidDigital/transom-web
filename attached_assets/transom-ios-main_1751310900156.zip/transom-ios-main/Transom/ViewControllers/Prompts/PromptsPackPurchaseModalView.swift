//
//  PromptsPackPurchaseModalView.swift
//  transom
//
//  Created by Roma Sosnovsky on 01/09/21.
//  Copyright © 2021 Void Digital. All rights reserved.
//

import UIKit

protocol PromptsPackPurchaseModalDelegate: AnyObject {
    func showPackBuySuccessAlert(pack: PromptPack)
    func hidePromptsPackPurchaseModal()
}

class PromptsPackPurchaseModalView: UIView {
    @IBOutlet private var view: UIView!
    @IBOutlet private weak var currentCreditsLabel: UILabel!
    @IBOutlet private weak var packNameLabel: UILabel!
    @IBOutlet private weak var packAuthorLabel: UILabel!
    @IBOutlet private weak var promptsCountLabel: UILabel!
    @IBOutlet private weak var packsCostLabel: UILabel!
    @IBOutlet private weak var buyButton: UIButton!
    @IBOutlet private weak var activityIndicatorView: UIActivityIndicatorView!

    private let iapManager = IAPManager.shared
    private let promptsService = PromptsService.shared
    
    weak var delegate: PromptsPackPurchaseModalDelegate?
    private var pack: PromptPack?
    
    override init(frame: CGRect) {
        super.init(frame: frame)

        setupView()
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)

        setupView()
    }

    override func prepareForInterfaceBuilder() {
        super.prepareForInterfaceBuilder()

        setupView()
    }

    private func setupView() {
        Bundle.main.loadNibNamed("PromptsPackPurchaseModalView", owner: self, options: nil)

        guard let view = view else { return }

        view.layer.cornerRadius = 6
        view.frame = bounds
        view.autoresizingMask = [.flexibleHeight, .flexibleWidth]
        addSubview(view)
        
        updateCurrentCreditsLabel()
    }
    
    func updateCurrentCreditsLabel() {
        let word = promptsService.creditsAmount == 1 ? "credit" : "credits"
        let attributes: [NSAttributedString.Key: Any] = [.font: UIFont.systemFont(ofSize: 16),
                                                         .foregroundColor: UIColor(named: "Text") ?? UIColor.black]
        let boldAttributes: [NSAttributedString.Key: Any] = [.font: UIFont.systemFont(ofSize: 16, weight: .bold)]
        let attributedString = NSMutableAttributedString(string: "You have \(promptsService.creditsAmount) \(word)",
                                                         attributes: attributes)
        
        let range = attributedString.mutableString.range(of: "\(promptsService.creditsAmount)")
        attributedString.addAttributes(boldAttributes, range: range)

        DispatchQueue.main.async {
            self.currentCreditsLabel.attributedText = attributedString
        }
    }
    
    func setup(pack: PromptPack) {
        self.pack = pack
        
        packNameLabel.text = pack.name
        if let author = pack.author {
            packAuthorLabel.text = "by \(author)"
        } else {
            packAuthorLabel.text = ""
        }
        promptsCountLabel.text = "\(pack.prompts.count)"
        packsCostLabel.text = "\(pack.costString)"

        buyButton.setTitle(getBuyButtonTitle(), for: UIControl.State())
    }

    private func enableBuyButton() {
        buyButton.setTitle(getBuyButtonTitle(), for: UIControl.State())
        buyButton.isEnabled = true
        buyButton.alpha = 1

        activityIndicatorView.stopAnimating()
    }

    private func disableBuyButton() {
        buyButton.setTitle("", for: .normal)
        buyButton.isEnabled = false
        buyButton.alpha = 0.6

        activityIndicatorView.startAnimating()
    }

    private func getBuyButtonTitle() -> String {
        if let price = pack?.price, price > promptsService.creditsAmount {
            let difference = price - promptsService.creditsAmount
            let word = difference == 1 ? "Credit" : "Credits"
            return "Buy \(difference) \(word)"
        } else {
            return "Confirm"
        }
    }
    
    // MARK: - IBActions
    @IBAction private func onBuyButtonTap() {
        guard let pack = pack else { return }
        
        if let price = pack.price, price > promptsService.creditsAmount {
            guard let product = iapManager.getProduct(id: .promptCredit) else { return }
            let quantity = price - promptsService.creditsAmount
            disableBuyButton()
            iapManager.buy(product: product, quantity: quantity) { [weak self] result in
                switch result {
                case .success:
                    self?.promptsService.updateCreditsAmount(change: quantity) { _ in
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                            self?.updateCurrentCreditsLabel()
                            self?.enableBuyButton()
                        }
                    }
                case .failure:
                    break
                }
            }
        } else {
            promptsService.buy(pack: pack) { [weak self] success in
                guard success else { return }
                self?.delegate?.showPackBuySuccessAlert(pack: pack)
            }
            delegate?.hidePromptsPackPurchaseModal()
        }
    }
    
    @IBAction private func close() {
        delegate?.hidePromptsPackPurchaseModal()
    }
    
}
