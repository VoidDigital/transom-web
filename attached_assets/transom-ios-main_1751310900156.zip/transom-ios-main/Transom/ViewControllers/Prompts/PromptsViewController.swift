//
//  PromptsViewController.swift
//  transom
//
//  Created by Roma Sosnovsky on 13/08/21.
//  Copyright © 2021 Void Digital. All rights reserved.
//

import UIKit

protocol PromptsViewDelegate: AnyObject {
    func didSelect(prompt: String, promptPackId: String?)
}

class PromptsViewController: UIViewController, PromptsStoreDelegate {
    @IBOutlet private weak var containerView: UIView!
    @IBOutlet private weak var bottomView: UIView!
    @IBOutlet private weak var libraryButton: UIButton!
    @IBOutlet private weak var storeButton: UIButton!
    
    private var indicatorImage: UIImageView?
    private var modalOverlayView: UIView?
    private var modalView: UIView?
    private var creditsModalView: PromptsCreditsPurchaseView?
    private var promptPackModalView: PromptsPackPurchaseModalView?
    private var promptsModalView: PromptsModalView?
    
    private var pageController: UIPageViewController!
    private var controllers = [UIViewController]()
    
    private weak var delegate: PromptsViewDelegate?
    
    private enum PromptsScreen {
        case library, store
    }
    
    private let promptsService = PromptsService.shared
    
    private var currentScreen: PromptsScreen = .library {
        didSet {
            let indicatorMidX: CGFloat
            
            switch currentScreen {
            case .library:
                indicatorMidX = containerView.bounds.width / 4
                guard let vc = controllers.first else { return }
                pageController.setViewControllers([vc], direction: .reverse, animated: true)
            case .store:
                indicatorMidX = containerView.bounds.width / 4 * 3
                guard let vc = controllers.last else { return }
                pageController.setViewControllers([vc], direction: .forward, animated: true)
            }
            
            UIView.animate(withDuration: 0.3) {
                self.libraryButton.alpha = self.currentScreen == .library ? 1 : 0.25
                self.storeButton.alpha = self.currentScreen == .store ? 1 : 0.25
                self.indicatorImage?.center.x = indicatorMidX
            }
        }
    }
    
    private lazy var closeButton: UIBarButtonItem = {
        UIBarButtonItem(image: UIImage(named: "prompts-close"),
                        style: .plain,
                        target: self,
                        action: #selector(close))
    }()
    
    static func instantiate(delegate: PromptsViewDelegate?) -> UINavigationController {
        let vc = UIStoryboard(name: "Prompts", bundle: nil).instantiateViewController(withIdentifier: "PromptsViewController") as! PromptsViewController
        vc.delegate = delegate
        
        let navigationController = UINavigationController(rootViewController: vc)
        navigationController.modalPresentationStyle = .overFullScreen
        navigationController.modalPresentationCapturesStatusBarAppearance = true
        return navigationController
    }
    
    override var preferredStatusBarStyle: UIStatusBarStyle { .default }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        setupNavigationBar()
        setupContainerView()
        setupBottomView()
        
        promptsService.creditsListener.multicast.add(self)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        setNeedsStatusBarAppearanceUpdate()

        if !promptsService.didShowOnboarding {
            showPromptsOnboarding()
        }
    }
    
    // MARK: - Setup
    private func setupNavigationBar() {
        title = "Prompts"
        
        navigationItem.leftBarButtonItem = closeButton
        navigationItem.rightBarButtonItem = createCreditsButton()
    }
    
    private func createCreditsButton() -> UIBarButtonItem {
        let word = promptsService.creditsAmount == 1 ? "credit" : "credits"
        let button = UIButton()
        button.frame = CGRect(x: 0, y: 0, width: 70, height: 28)
        button.setTitle("\(promptsService.creditsAmount) \(word)", for: .normal)
        button.setTitleColor(.white, for: UIControl.State())
        button.titleLabel?.font = .systemFont(ofSize: 12)
        button.layer.backgroundColor = UIColor(red: 2/255, green: 195/255, blue: 154/255, alpha: 1).cgColor
        button.layer.cornerRadius = 4
        button.addTarget(self, action: #selector(showCreditsStore), for: .touchUpInside)
        
        return UIBarButtonItem(customView: button)
    }
    
    private func setupContainerView() {
        pageController = UIPageViewController(transitionStyle: .scroll, navigationOrientation: .horizontal, options: nil)
        pageController.dataSource = self
        pageController.delegate = self

        addChild(pageController)
        pageController.view.translatesAutoresizingMaskIntoConstraints = false
        containerView.addSubview(pageController.view)

        NSLayoutConstraint.activate([
            pageController.view.topAnchor.constraint(equalTo: containerView.topAnchor, constant: 0.0),
            pageController.view.bottomAnchor.constraint(equalTo: containerView.bottomAnchor, constant: 0.0),
            pageController.view.leadingAnchor.constraint(equalTo: containerView.leadingAnchor, constant: 0.0),
            pageController.view.trailingAnchor.constraint(equalTo: containerView.trailingAnchor, constant: 0.0),
        ])

        pageController.didMove(toParent: self)

        controllers = [PromptsLibraryViewController.instantiate(delegate: self),
                       PromptsStoreViewController.instantiate(delegate: self)]
        pageController.setViewControllers([controllers[0]], direction: .forward, animated: false)
    }
    
    private func setupBottomView() {
        bottomView.layer.shadowColor = UIColor.lightGray.cgColor
        bottomView.layer.shadowOpacity = 0.5
        bottomView.layer.shadowOffset = .zero
        bottomView.layer.shadowRadius = 5
        bottomView.layer.shadowPath = UIBezierPath(rect: CGRect(x: 0,
                                                                y: 0,
                                                                width: bottomView.bounds.width,
                                                                height: 5)).cgPath
        
        setupTabIndicator()
    }
    
    private func setupTabIndicator() {
        let indicatorWidth = UIScreen.main.bounds.width / CGFloat(controllers.count)
        indicatorImage = UIImageView(image: UIImage(named: "tab-indicator"))
        indicatorImage?.contentMode = .center
        indicatorImage?.frame = CGRect(x: 0, y: 0, width: indicatorWidth, height: 3)
        indicatorImage?.tintColor = UIColor.black
        bottomView.addSubview(indicatorImage!)
    }
    
    @objc private func close() {
        dismiss(animated: true)
    }

    // MARK: - Modals
    private func showPromptsOnboarding() {
        modalOverlayView = UIView(frame: view.frame)
        modalOverlayView?.backgroundColor = UIColor(red: 0/255, green: 41/255, blue: 105/255, alpha: 1)
        modalOverlayView?.alpha = 0
        navigationController?.view.addSubview(modalOverlayView!)

        let hidePromptsTapGesture = UITapGestureRecognizer(target: self, action: #selector(closePromptsOnboarding))
        modalOverlayView?.addGestureRecognizer(hidePromptsTapGesture)

        let promptsService = PromptsService.shared

        promptsService.didShowOnboarding = true
        let width = min(view.frame.width - 30, 360)
        let x = (view.frame.width - width) / 2
        modalView = PromptsOnboardingView(frame: CGRect(x: x, y: 1.5 * view.frame.height, width: width, height: 400), delegate: self)
        navigationController?.view.addSubview(modalView!)

        view.endEditing(true)

        UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 0.8, initialSpringVelocity: 0.2, animations: {
            self.modalOverlayView?.alpha = 0.45
            let centerY: CGFloat
            if UIDevice.current.userInterfaceIdiom == .pad && UIApplication.shared.statusBarOrientation.isLandscape {
                centerY = self.view.frame.height + 250
            } else {
                centerY = self.view.frame.height + 200
            }
            self.modalView?.center.y -= centerY
            self.view.layoutIfNeeded()
        }, completion: nil)
    }

    @objc private func showCreditsStore() {
        guard let navigationController = navigationController else { return }

        modalOverlayView = UIView(frame: navigationController.view.frame)
        modalOverlayView?.backgroundColor = UIColor(red: 0/255, green: 41/255, blue: 105/255, alpha: 1)
        modalOverlayView?.alpha = 0
        navigationController.view.addSubview(modalOverlayView!)
        
        let width = min(view.frame.width - 20, 360)
        let x = (view.frame.width - width) / 2
        creditsModalView = PromptsCreditsPurchaseView(frame: CGRect(x: x, y: 1.5 * view.frame.height, width: width, height: 230))
        creditsModalView?.delegate = self
        navigationController.view.addSubview(creditsModalView!)

        UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 0.8, initialSpringVelocity: 0.2, animations: {
            self.modalOverlayView?.alpha = 0.45
            let centerY: CGFloat
            if UIDevice.current.userInterfaceIdiom == .pad && UIApplication.shared.statusBarOrientation.isLandscape {
                centerY = navigationController.view.frame.height + 245
            } else {
                centerY = navigationController.view.frame.height + 115
            }
            self.creditsModalView?.center.y -= centerY
            self.view.layoutIfNeeded()
        }, completion: nil)
    }
    
    private func showPromptsModal(pack: PromptPack) {
        guard let navigationController = navigationController else { return }
        
        view.endEditing(true)
        
        modalOverlayView = UIView(frame: navigationController.view.frame)
        modalOverlayView?.backgroundColor = UIColor(red: 0/255, green: 41/255, blue: 105/255, alpha: 1)
        modalOverlayView?.alpha = 0
        navigationController.view.addSubview(modalOverlayView!)
        
        let width = min(610, UIScreen.main.bounds.width)
        let x = (UIScreen.main.bounds.width - width) / 2
        promptsModalView = PromptsModalView(frame: CGRect(x: x, y: 1.5 * self.view.frame.height, width: width, height: 420), delegate: self, pack: pack)
        navigationController.view.addSubview(promptsModalView!)
        
        UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 0.8, initialSpringVelocity: 0.2, animations: {
            self.modalOverlayView?.alpha = 0.45
            self.promptsModalView?.center.y = self.view.frame.height - 180
            self.view.layoutIfNeeded()
        }, completion: nil)
    }
    
    func closePromptsModal() {
        UIView.animate(withDuration: 0.4, animations: {
            self.modalOverlayView?.alpha = 0
            self.promptsModalView?.center.y += UIScreen.main.bounds.height
        }, completion: { _ in
            self.modalOverlayView = nil
            self.promptsModalView = nil
        })
    }
    
    // MARK: - IBActions
    @IBAction func showLibrary() {
        currentScreen = .library
    }
    
    @IBAction private func showStore() {
        currentScreen = .store
    }
}

extension PromptsViewController: UIPageViewControllerDataSource, UIPageViewControllerDelegate {
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerBefore viewController: UIViewController) -> UIViewController? {
        if let index = controllers.firstIndex(of: viewController) {
            if index > 0 {
                return controllers[index - 1]
            } else {
                return nil
            }
        }

        return nil
    }
    
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerAfter viewController: UIViewController) -> UIViewController? {
        if let index = controllers.firstIndex(of: viewController) {
            if index < controllers.count - 1 {
                return controllers[index + 1]
            } else {
                return nil
            }
        }

        return nil
    }
    
    func pageViewController(_ pageViewController: UIPageViewController, willTransitionTo pendingViewControllers: [UIViewController]) {
        guard let pending = pendingViewControllers.first else { return }
        
        if pending is PromptsLibraryViewController {
            currentScreen = .library
        } else if pending is PromptsStoreViewController {
            currentScreen = .store
        }
    }
}

extension PromptsViewController: CreditsBalanceListener {
    func creditsBalanceDidChange() {
        navigationItem.rightBarButtonItem = createCreditsButton()
    }
}

extension PromptsViewController: PromptsCreditsPurchaseViewDelegate {
    func hideCreditsModal() {
        UIView.animate(withDuration: 0.3, animations: {
            self.creditsModalView?.center.y = self.view.frame.height * 1.5
            self.modalOverlayView?.alpha = 0
        }, completion: { _ in
            self.creditsModalView = nil
        })
    }
}

extension PromptsViewController: PromptsLibraryDelegate {
    func usePromptPack(pack: PromptPack) {
        showPromptsModal(pack: pack)
    }
}

extension PromptsViewController: PromptsModalDelegate {
    func didSelect(prompt: String, promptPackId: String?) {
        delegate?.didSelect(prompt: prompt, promptPackId: promptPackId)
        
        dismiss(animated: true, completion: nil)
    }
    
    func shouldHidePromptsModal() {
        closePromptsModal()
    }
}

extension PromptsViewController: PromptsOnboardingDelegate {
    @objc func closePromptsOnboarding() {
        UIView.animate(withDuration: 0.4, animations: {
            self.modalOverlayView?.alpha = 0
            self.modalView?.center.y += UIScreen.main.bounds.height
        }, completion: { _ in
            self.modalOverlayView = nil
            self.modalView = nil
        })
    }
}
