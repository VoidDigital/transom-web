//
//  PromptsCreditsPurchaseView.swift
//  transom
//
//  Created by Roma Sosnovsky on 26/08/21.
//  Copyright © 2021 Void Digital. All rights reserved.
//

import UIKit

protocol PromptsCreditsPurchaseViewDelegate: AnyObject {
    func hideCreditsModal()
}

class PromptsCreditsPurchaseView: UIView {
    @IBOutlet private var view: UIView!
    @IBOutlet private weak var currentCreditsLabel: UILabel!
    @IBOutlet private weak var creditsLabel: UILabel!
    @IBOutlet private weak var minusButton: UIButton!
    @IBOutlet private weak var plusButton: UIButton!
    @IBOutlet private weak var activityIndicatorView: UIActivityIndicatorView!
    @IBOutlet private weak var buyButton: UIButton!
    
    private let iapManager = IAPManager.shared
    private let promptsService = PromptsService.shared
    
    weak var delegate: PromptsCreditsPurchaseViewDelegate?
    
    private var creditsAmount = 1 {
        didSet {
            creditsLabel.text = creditsString
            buyButton.setTitle("Buy for \(priceString)", for: UIControl.State())
        }
    }
    
    private var creditsString: String {
        let word = creditsAmount == 1 ? "Credit" : "Credits"
        return "\(creditsAmount) \(word)"
    }
    
    private var priceString: String {
        guard let product = iapManager.getProduct(id: .promptCredit)
        else { return "" }
        
        return iapManager.getPriceFormatted(for: product, amount: creditsAmount) ?? ""
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)

        setupView()
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)

        setupView()
    }

    override func prepareForInterfaceBuilder() {
        super.prepareForInterfaceBuilder()

        setupView()
    }

    private func setupView() {
        Bundle.main.loadNibNamed("PromptsCreditsPurchaseView", owner: self, options: nil)

        guard let view = view else { return }

        view.layer.cornerRadius = 6
        view.frame = bounds
        view.autoresizingMask = [.flexibleHeight, .flexibleWidth]
        addSubview(view)
        
        updateCurrentCreditsLabel()
    }
    
    private func updateCurrentCreditsLabel() {
        let word = promptsService.creditsAmount == 1 ? "credit" : "credits"
        let attributes: [NSAttributedString.Key: Any] = [.font: UIFont.systemFont(ofSize: 16),
                                                         .foregroundColor: UIColor(named: "Text") ?? UIColor.black]
        let boldAttributes: [NSAttributedString.Key: Any] = [.font: UIFont.systemFont(ofSize: 16, weight: .bold)]
        let attributedString = NSMutableAttributedString(string: "You have \(promptsService.creditsAmount) \(word)",
                                                         attributes: attributes)
        
        let range = attributedString.mutableString.range(of: "\(promptsService.creditsAmount)")
        attributedString.addAttributes(boldAttributes, range: range)
        
        currentCreditsLabel.attributedText = attributedString
    }
    
    private func enableBuyButton() {
        buyButton.setTitle("Buy for \(priceString)", for: UIControl.State())
        buyButton.isEnabled = true
        buyButton.alpha = 1
        
        activityIndicatorView.stopAnimating()
    }
    
    private func disableBuyButton() {
        buyButton.setTitle("", for: .normal)
        buyButton.isEnabled = false
        buyButton.alpha = 0.6
        
        activityIndicatorView.startAnimating()
    }
    
    // MARK: - IBActions
    @IBAction func increaseCreditsAmount() {
        guard creditsAmount < 10 else { return }
        creditsAmount += 1
    }
    
    @IBAction func decreaseCreditsAmount() {
        guard creditsAmount > 1 else { return }
        creditsAmount -= 1
    }
    
    @IBAction func buyCredits() {
        guard let product = iapManager.getProduct(id: .promptCredit) else { return }
        
        disableBuyButton()
        let quantity = creditsAmount
        iapManager.buy(product: product, quantity: quantity) { [weak self] result in
            guard let self = self else { return }
            
            switch result {
            case .success:
                self.promptsService.updateCreditsAmount(change: quantity)
                self.delegate?.hideCreditsModal()
            case .failure:
                self.enableBuyButton()
            }
        }
    }
    
    @IBAction func close() {
        delegate?.hideCreditsModal()
    }
}
