//
//  PromptsLibraryViewController.swift
//  transom
//
//  Created by Roma Sosnovsky on 13/08/21.
//  Copyright © 2021 Void Digital. All rights reserved.
//

import UIKit

protocol PromptsLibraryDelegate: AnyObject {
    func usePromptPack(pack: PromptPack)
}

class PromptsLibraryViewController: UIViewController {
    @IBOutlet private weak var tableView: UITableView!
    
    private let promptsService = PromptsService.shared
    private weak var delegate: PromptsLibraryDelegate?
    
    static func instantiate(delegate: PromptsLibraryDelegate?) -> PromptsLibraryViewController {
        let vc = UIStoryboard(name: "Prompts", bundle: nil).instantiateViewController(withIdentifier: "PromptsLibraryViewController") as! PromptsLibraryViewController
        vc.delegate = delegate
        return vc
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        setupTableView()
        
        promptsService.boughtPacksListener.multicast.add(self)
    }
    
    // MARK: - Setup
    private func setupTableView() {
        tableView.dataSource = self
        tableView.delegate = self
        
        tableView.register(UINib(nibName: "PromptPackTableViewCell", bundle: nil), forCellReuseIdentifier: "promptPackCell")
    }
}

extension PromptsLibraryViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "promptPackCell", for: indexPath) as? PromptPackTableViewCell
        else { return UITableViewCell() }
        
        cell.setup(pack: promptsService.boughtPacks[indexPath.row])
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        promptsService.boughtPacks.count
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard let cell = tableView.cellForRow(at: indexPath) as? PromptPackTableViewCell,
              let pack = cell.pack
        else { return }
        
        delegate?.usePromptPack(pack: pack)
    }
}

extension PromptsLibraryViewController: BoughtPromptPacksListener {
    func boughtPacksDidChange() {
        tableView.reloadData()
    }
}
