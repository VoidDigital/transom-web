//
//  PromptsStoreViewController.swift
//  transom
//
//  Created by Roma Sosnovsky on 13/08/21.
//  Copyright © 2021 Void Digital. All rights reserved.
//

import UIKit

protocol PromptsStoreDelegate: AnyObject {
    func showLibrary()
}

class PromptsStoreViewController: UIViewController {
    @IBOutlet private weak var tableView: UITableView!
    @IBOutlet private weak var placeholderView: UIView!
    @IBOutlet private weak var placeholderLabel: UILabel!

    private var modalOverlayView: UIView?
    private var promptPackModalView: PromptsPackPurchaseModalView?
    private weak var delegate: PromptsStoreDelegate?
    
    private let promptsService = PromptsService.shared
    
    static func instantiate(delegate: PromptsStoreDelegate) -> PromptsStoreViewController {
        let vc = UIStoryboard(name: "Prompts", bundle: nil).instantiateViewController(withIdentifier: "PromptsStoreViewController") as! PromptsStoreViewController
        vc.delegate = delegate
        return vc
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        setupTableView()
        setupPlaceholderView()
        checkAvailablePacks()

        promptsService.boughtPacksListener.multicast.add(self)
    }
    
    // MARK: - Setup
    private func setupTableView() {
        tableView.dataSource = self
        tableView.delegate = self
        
        tableView.register(UINib(nibName: "PromptPackTableViewCell", bundle: nil), forCellReuseIdentifier: "promptPackCell")
    }

    private func setupPlaceholderView() {
        let paragraphStyle = NSMutableParagraphStyle()
        paragraphStyle.lineHeightMultiple = 1.4
        paragraphStyle.alignment = .center
        let attributes: [NSAttributedString.Key: Any] = [.paragraphStyle: paragraphStyle]
        let attributedText = NSAttributedString(string: placeholderLabel.text ?? "", attributes: attributes)
        placeholderLabel.attributedText = attributedText
    }

    private func checkAvailablePacks() {
        placeholderView.isHidden = !promptsService.storePacks.isEmpty
    }

    // MARK: Purchase
    func getPromptsPack(pack: PromptPack) {
        guard let navigationController = navigationController else { return }

        modalOverlayView = UIView(frame: navigationController.view.frame)
        modalOverlayView?.backgroundColor = UIColor(red: 0/255, green: 41/255, blue: 105/255, alpha: 1)
        modalOverlayView?.alpha = 0
        navigationController.view.addSubview(modalOverlayView!)

        let width = min(view.frame.width - 20, 360)
        let x = (view.frame.width - width) / 2
        promptPackModalView = PromptsPackPurchaseModalView(frame: CGRect(x: x, y: 1.5 * view.frame.height, width: width, height: 300))
        promptPackModalView?.setup(pack: pack)
        promptPackModalView?.delegate = self
        navigationController.view.addSubview(promptPackModalView!)

        UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 0.8, initialSpringVelocity: 0.2, animations: {
            self.modalOverlayView?.alpha = 0.45
            let centerY: CGFloat
            if UIDevice.current.userInterfaceIdiom == .pad && UIApplication.shared.statusBarOrientation.isLandscape {
                centerY = navigationController.view.frame.height //+ 245
            } else {
                centerY = navigationController.view.frame.height - 60
            }
            self.promptPackModalView?.center.y -= centerY
            self.view.layoutIfNeeded()
        }, completion: nil)
    }
}

extension PromptsStoreViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "promptPackCell", for: indexPath) as? PromptPackTableViewCell
        else { return UITableViewCell() }
        
        cell.setup(pack: promptsService.storePacks[indexPath.row], shouldShowInfo: true)
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        promptsService.storePacks.count
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        getPromptsPack(pack: promptsService.storePacks[indexPath.row])
    }
}

extension PromptsStoreViewController: PromptsPackPurchaseModalDelegate {
    func showPackBuySuccessAlert(pack: PromptPack) {
        showMessage(title: "Success",
                    text: "You've purchased \(pack.name) pack. Happy writing!",
                    buttonTitle: "Got it") { [weak self] _ in
            self?.delegate?.showLibrary()
        }
    }

    func hidePromptsPackPurchaseModal() {
        UIView.animate(withDuration: 0.3, animations: {
            self.promptPackModalView?.center.y = self.view.frame.height * 1.5
            self.modalOverlayView?.alpha = 0
        }, completion: { _ in
            self.promptPackModalView = nil
        })
    }
}

extension PromptsStoreViewController: BoughtPromptPacksListener {
    func boughtPacksDidChange() {
        tableView.reloadData()
        checkAvailablePacks()
    }
}
