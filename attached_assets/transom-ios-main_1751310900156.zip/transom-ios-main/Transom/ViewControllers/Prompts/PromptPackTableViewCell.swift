//
//  PromptPackTableViewCell.swift
//  transom
//
//  Created by Roma Sosnovsky on 18/08/21.
//  Copyright © 2021 Void Digital. All rights reserved.
//

import UIKit

protocol PromptPackCellDelegate: AnyObject {
    func getPromptsPack(pack: PromptPack)
}

class PromptPackTableViewCell: UITableViewCell {
    @IBOutlet private weak var wrapView: UIView!
    @IBOutlet private weak var nameLabel: UILabel!
    @IBOutlet private weak var infoLabel: UILabel!
    @IBOutlet private weak var descriptionLabel: UILabel!
    @IBOutlet private weak var infoView: UIView!
    @IBOutlet private weak var infoViewHeight: NSLayoutConstraint!
    @IBOutlet private weak var infoViewBottomPadding: NSLayoutConstraint!
    @IBOutlet private weak var promptsCountLabel: UILabel!
    @IBOutlet private weak var costLabel: UILabel!
    
    var pack: PromptPack?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        setupStyle()
    }
    
    private func setupStyle() {
        selectionStyle = .none
        
        wrapView.layer.cornerRadius = 15
        wrapView.layer.shadowColor = UIColor.black.cgColor
        wrapView.layer.shadowOpacity = 0.05
        wrapView.layer.shadowOffset = .zero
        wrapView.layer.shadowRadius = 6
        wrapView.layer.rasterizationScale = UIScreen.main.scale
        wrapView.layer.shouldRasterize = true
    }
    
    func setup(pack: PromptPack, shouldShowInfo: Bool = false) {
        self.pack = pack
        
        nameLabel.text = pack.name
        infoLabel.text = pack.info
        descriptionLabel.text = pack.description
        
        if shouldShowInfo {
            promptsCountLabel.text = "\(pack.prompts.count)"
            costLabel.text = pack.costString
        } else {
            infoView.isHidden = true
            infoViewHeight.constant = 0
            infoViewBottomPadding.constant = 0
        }
    }
}
