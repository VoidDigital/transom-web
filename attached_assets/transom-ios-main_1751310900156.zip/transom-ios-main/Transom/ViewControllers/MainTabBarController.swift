//
//  MainTabBarController.swift
//  transom
//
//  Created by Roma Sosnovsky on 8/22/19.
//  Copyright © 2019 Void Digital. All rights reserved.
//

import FirebaseAuth
import EasyTipView
import UIKit

class MainTabBarController: UITabBarController {
    private var indicatorImage: UIImageView?
    private let appRateManager = AppRateManager()
    private var isExistingUser = false
    private var didAppear = false
    
    private var modalOverlayView: UIView?
    private var modalView: UIView?
    private var dailyWordsModalView: DailyNotificationsModalView?
    
    private lazy var promptsTipView: EasyTipView = {
        var preferences = EasyTipView.Preferences()
        preferences.drawing.font = UIFont(name: "HindSiliguri-Regular", size: 17) ?? .systemFont(ofSize: 17)
        preferences.drawing.foregroundColor = .white
        preferences.drawing.backgroundColor = .black.withAlphaComponent(0.8)
        
        return EasyTipView(text: "Try me", preferences: preferences)
    }()

    static func instantiate(isExistingUser: Bool = false) -> MainTabBarController? {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)

        guard let vc = storyboard.instantiateViewController(withIdentifier: "MainTabBarController") as? MainTabBarController
        else { return nil }

        vc.isExistingUser = isExistingUser

        return vc
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        guard Auth.auth().currentUser != nil else {
            setRootViewController(viewController: ColdOpeningVC.instantiate()!)
            return
        }

        FirebaseService.shared.getDailyWordRemindersStatus()
        PromptsService.shared.getCreditsAmount()

        delegate = self

        tabBar.isTranslucent = false
        tabBar.tintColor = UIColor(red: 24/255, green: 71/255, blue: 245/255, alpha: 1)
        
        tabBar.layer.shadowColor = UIColor.lightGray.cgColor
        tabBar.layer.shadowOpacity = 0.5
        tabBar.layer.shadowOffset = CGSize.zero
        tabBar.layer.shadowRadius = 5
        tabBar.layer.borderColor = UIColor.clear.cgColor
        tabBar.layer.borderWidth = 0
        tabBar.clipsToBounds = false
        tabBar.backgroundColor = UIColor.white
        UITabBar.appearance().shadowImage = UIImage()
        UITabBar.appearance().backgroundImage = UIImage()

        setupViewControllers()
        setupTabBarImages()
        setupTabIndicator()

        let tagObserver = FBTagObserver.shared
        tagObserver.observerTags() { tags in }

        let thoughtsObserver = FBThoughtObserver.shared
        thoughtsObserver.observerThoughts { thoughts in }
        
        IAPManager.shared.getProducts()
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)

        if !didAppear {
            didAppear = true
            handleTabSelection(index: 0)
  
            if !UserDefaults.didAskForDailyWordReminders {
                showDailyNotificationsModal()
            } else {
                showPromptsTooltip()
            }
        }
    }

    override var preferredStatusBarStyle: UIStatusBarStyle { .lightContent }
    override var childForStatusBarStyle: UIViewController? { nil }

    private func setupTabIndicator() {
        let indicatorWidth = UIScreen.main.bounds.width / CGFloat(tabBar.items!.count)
        indicatorImage = UIImageView(image: UIImage(named: "tab-indicator"))
        indicatorImage?.contentMode = .center
        indicatorImage?.frame = CGRect(x: 0, y: 0, width: indicatorWidth, height: 3)
        indicatorImage?.tintColor = UIColor(named: "Blue")
        tabBar.addSubview(indicatorImage!)
    }

    private func setupViewControllers() {
        let thoughtsVC = ListViewController.instantiate(listType: .thought, withNavigationController: true, shouldShowWelcomeMessage: isExistingUser)
        let projectsVC = ListViewController.instantiate(listType: .project, withNavigationController: true)
        let newThoughtVC = ThoughtViewController.instantiate()
        let tagsVC = ListViewController.instantiate(listType: .tag, withNavigationController: true)
        
        let promptsVC = UIViewController()
        promptsVC.tabBarItem = UITabBarItem(title: "", image: UIImage(named: "tab-prompts"), selectedImage: nil)

        viewControllers = [thoughtsVC, projectsVC, newThoughtVC, tagsVC, promptsVC]
    }

    private func setupTabBarImages() {
        guard let viewControllers = viewControllers else { return }
        
        for (index, viewController) in viewControllers.enumerated() {
            guard index != 2 else {
                if #available(iOS 13, *) {
                    viewController.tabBarItem.imageInsets = UIEdgeInsets(top: -14, left: 0, bottom: 0, right: 0)
                }

                continue
            }

            guard index != 4, UIDevice.current.userInterfaceIdiom != .pad else { continue }
            viewController.tabBarItem.imageInsets = UIEdgeInsets(top: 7, left: 0, bottom: -7, right: 0)
        }
    }
    
    private func showPromptsTooltip() {
        guard let tabBarItem = tabBar.items?.last, !PromptsService.shared.didShowTooltip, UserDefaults.didAskForDailyWordReminders else { return }
        promptsTipView.show(forItem: tabBarItem)
    }

    private func handleTabSelection(index: Int) {
        if index == 0 {
            showPromptsTooltip()
        } else {
            promptsTipView.dismiss()
        }
        
        guard index != 2 else { return }
        
        guard index != 4 else {
            showPrompts()
            return
        }

        UIView.animate(withDuration: 0.3) {
            self.indicatorImage?.center.x = self.orderedTabBarItemViews[index].frame.midX
        }
    }

    func changeCurrentTab(index: Int) {
        dismiss(animated: true, completion: nil)

        selectedIndex = index
        handleTabSelection(index: selectedIndex)
    }

    func openNewThought(animated: Bool = true) {
        dismiss(animated: true) {
            let vc = ThoughtViewController.instantiate(delegate: self)
            vc.modalPresentationStyle = .overFullScreen
            vc.modalPresentationCapturesStatusBarAppearance = true
            self.present(vc, animated: animated)
        }
    }

    func openThought(id: String) {
        FirebaseService.shared.getThought(id: id) { [weak self] thought in
            guard let self = self, let thought = thought else { return }

            self.dismiss(animated: true) {
                let vc = ThoughtViewController.instantiate(thought: thought, delegate: self)
                vc.modalPresentationStyle = .overFullScreen
                vc.modalPresentationCapturesStatusBarAppearance = true
                self.present(vc, animated: true)
            }
        }
    }
    
    func showPrompts() {
        if selectedIndex == 0 {
            PromptsService.shared.didShowTooltip = true
        }
        
        showPromptsModal()
    }
    
    private func showPromptsModal() {
        let vc = PromptsViewController.instantiate(delegate: self)
        present(vc, animated: true)
    }
    
    // MARK: - Daily words notifications
    private func showDailyNotificationsModal() {
        guard !UserDefaults.didAskForDailyWordReminders, dailyWordsModalView == nil else { return }

        UserDefaults.updateDidAskForDailyWordReminders(didAsk: true)
        
        modalOverlayView = UIView(frame: view.frame)
        modalOverlayView?.backgroundColor = UIColor(red: 0/255, green: 41/255, blue: 105/255, alpha: 1)
        modalOverlayView?.alpha = 0
        view.addSubview(modalOverlayView!)

        let width = min(view.frame.width - 20, 360)
        let x = (view.frame.width - width) / 2

        dailyWordsModalView = DailyNotificationsModalView(frame: CGRect(x: x, y: view.frame.height * 1.5, width: width, height: 360))
        dailyWordsModalView?.delegate = self
        view.addSubview(dailyWordsModalView!)

        UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 0.8, initialSpringVelocity: 0.2, animations: {
            self.modalOverlayView?.alpha = 0.3
            self.dailyWordsModalView?.center.y = self.view.center.y
        }, completion: nil)
    }
}

extension MainTabBarController: UITabBarControllerDelegate {
    func tabBarController(_ tabBarController: UITabBarController, shouldSelect viewController: UIViewController) -> Bool {
        if let navVC = viewController as? UINavigationController, navVC.viewControllers.first is ThoughtViewController {
            let selectedTag: FBTag?
            if let navVC = selectedViewController as? UINavigationController, let listVC = navVC.visibleViewController as? ListViewController, let tag = listVC.selectedTag {
                selectedTag = tag
            } else {
                selectedTag = nil
            }
            let vc = ThoughtViewController.instantiate(tag: selectedTag, delegate: self)
            vc.modalPresentationStyle = .overFullScreen
            vc.modalPresentationCapturesStatusBarAppearance = true
            tabBarController.present(vc, animated: true)
            return false
        } else if let fromView = selectedViewController?.view, let toView = viewController.view, let controllerIndex = viewControllers?.firstIndex(of: viewController) {
            guard controllerIndex != 4 else {
                return false
            }
            
            let viewSize = fromView.frame
            let scrollRight = controllerIndex > tabBarController.selectedIndex

            if fromView == toView {
                if let navVC = selectedViewController as? UINavigationController {
                    if navVC.viewControllers.count > 1 {
                        navVC.popToRootViewController(animated: true)
                    } else if let listVC = navVC.viewControllers.last as? ListViewController {
                        listVC.scrollToTop()
                    }
                }
                return false
            }

            // Avoid UI issues when switching tabs fast
            if fromView.superview?.subviews.contains(toView) == true { return false }
            fromView.superview?.addSubview(toView)
            let screenWidth = UIScreen.main.bounds.size.width
            toView.frame = CGRect(x: (scrollRight ? screenWidth : -screenWidth), y: viewSize.origin.y, width: screenWidth, height: viewSize.size.height)
            UIView.animate(withDuration: 0.25, delay: TimeInterval(0.0), options: [.curveEaseOut, .preferredFramesPerSecond60], animations: {
                fromView.frame = CGRect(x: (scrollRight ? -screenWidth : screenWidth), y: viewSize.origin.y, width: screenWidth, height: viewSize.size.height)
                toView.frame = CGRect(x: 0, y: viewSize.origin.y, width: screenWidth, height: viewSize.size.height)
            }, completion: { finished in
                if finished {
                    fromView.removeFromSuperview()
                    tabBarController.selectedIndex = controllerIndex
                }
            })
            return true
        }
        
        return true
    }

    override func tabBar(_ tabBar: UITabBar, didSelect item: UITabBarItem) {
        guard let index = tabBar.items?.firstIndex(of: item) else { return }

        handleTabSelection(index: index)
    }
}

extension MainTabBarController: ThoughtControllerDelegate {
    func didSave(thought: FBThought?, isNew: Bool) {
        appRateManager.askForReview()

        if let vc = topMostViewController as? ListViewController {
            let message = thought == nil ? "Thought Saved!" : "Thought updated"
            vc.showAlertLabel(message: message)
        }
    }
}

extension MainTabBarController: PromptsViewDelegate {
    func didSelect(prompt: String, promptPackId: String?) {
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) {
            let vc = ThoughtViewController.instantiate(prompt: prompt, promptPackId: promptPackId, tag: nil, delegate: self)
            vc.modalPresentationStyle = .overFullScreen
            vc.modalPresentationCapturesStatusBarAppearance = true
            self.present(vc, animated: true)
        }
    }
}

extension MainTabBarController: DailyNotificationsModalDelegate {
    func enableDailyNotifications() {
        closeDailyNotificationsModal {
            DispatchQueue.main.async {
                NotificationService.shared.askNotificationsPermission()
            }
        }
    }

    func closeDailyNotificationsModal(handler: (() -> Void)?) {
        UIView.animate(withDuration: 0.3, animations: {
            self.dailyWordsModalView?.center.y = self.view.frame.height * 1.5
            self.modalOverlayView?.alpha = 0
        }, completion: { _ in
            self.dailyWordsModalView = nil
            self.modalOverlayView = nil
            self.showPromptsTooltip()
            handler?()
        })
    }
}
