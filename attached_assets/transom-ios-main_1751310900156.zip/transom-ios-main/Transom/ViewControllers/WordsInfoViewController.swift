//
//  WordsInfoViewController.swift
//  transom
//
//  Created by Roma Sosnovsky on 26.08.2020.
//  Copyright © 2020 Void Digital. All rights reserved.
//

import UIKit

class WordsInfoViewController: UIViewController {
    private var textView: UITextView!
    private let fontSize: CGFloat = 18
    private var didLayoutSubviews = false

    private var text: NSAttributedString {
        let plainText = """
            The “One Hundred Words” Project
            Ask any writer for their secret to writing and they’ll tell you: just write. It doesn’t matter if it’s total trash (it probably is) or if you’re ever going to use it (you probably won’t). Write early, often, anywhere, anytime, about anything at all. Just write.
            When you write consistently, you form a healthy habit that brings language, ideation, and creativity to the surface — making these skills immediately accessible when you sit down to work.
            That’s why we created One Hundred Words: to encourage writers to write a little something every single day. It’s not about writing anything “good” or “substantial” — it’s about creating momentum. And \(Config.dailyWordsGoal) words? You could bang that out with your thumbs in a heartbeat. (I’m already at 133 words on this page!)
            For more on the neuroscience of writing, check out Susan Reynolds’ excellent and approachable Fire Up Your Writing Brain. And if you need a creative nudge, pick up Steven Pressfield’s inspirational The War of Art.
            Best of luck, writer!
        """
        let paragraphStyle = NSMutableParagraphStyle()
        paragraphStyle.lineSpacing = 3
        paragraphStyle.paragraphSpacing = 12
        let attrs: [NSAttributedString.Key: Any] = [.paragraphStyle: paragraphStyle, .font: UIFont(name: ThoughtFont.regular.rawValue, size: fontSize)!, .foregroundColor: UIColor(red: 70/255, green: 70/255, blue: 70/255, alpha: 1), .kern: 0.6]
        let attributedString = NSMutableAttributedString(string: plainText, attributes: attrs)

        let range1 = attributedString.mutableString.range(of: "The “One Hundred Words” Project")
        attributedString.addAttribute(.font, value: UIFont(name: ThoughtFont.bold.rawValue, size: fontSize)!, range: range1)

        let range2 = attributedString.mutableString.range(of: "One Hundred Words:")
        attributedString.addAttribute(.font, value: UIFont(name: ThoughtFont.bold.rawValue, size: fontSize)!, range: range2)

        let range3 = attributedString.mutableString.range(of: "just write")
        attributedString.addAttribute(.font, value: UIFont(name: ThoughtFont.italic.rawValue, size: fontSize)!, range: range3)

        let range4 = attributedString.mutableString.range(of: "Fire Up Your Writing Brain")
        attributedString.addAttribute(.font, value: UIFont(name: ThoughtFont.italic.rawValue, size: fontSize)!, range: range4)

        let range5 = attributedString.mutableString.range(of: "The War of Art")
        attributedString.addAttribute(.font, value: UIFont(name: ThoughtFont.italic.rawValue, size: fontSize)!, range: range5)

        return NSAttributedString(attributedString: attributedString)
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        setupNavigationItem()
        setupTextView()
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()

        guard !didLayoutSubviews else { return }

        didLayoutSubviews = true
        textView.setContentOffset(.zero, animated: false)
    }

    private func setupNavigationItem() {
        navigationItem.title = "What's This?"
    }

    private func setupTextView() {
        textView = UITextView()
        textView.textContainerInset = UIEdgeInsets(top: 24, left: 16, bottom: 36, right: 16)
        textView.attributedText = text
        view.addSubview(textView)

        textView.translatesAutoresizingMaskIntoConstraints = false

        NSLayoutConstraint.activate([
            textView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor),
            textView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor),
            textView.topAnchor.constraint(equalTo: view.layoutMarginsGuide.topAnchor),
            textView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
        ])
    }


}
