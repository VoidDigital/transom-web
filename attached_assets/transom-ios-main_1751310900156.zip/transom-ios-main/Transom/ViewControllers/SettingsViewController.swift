//
//  SettingsViewController.swift
//  transom
//
//  Created by Roma Sosnovsky on 03.08.2020.
//  Copyright © 2020 Void Digital. All rights reserved.
//

import FirebaseAuth
import UIKit
import UserNotifications

class SettingsViewController: UIViewController {
    @IBOutlet private weak var wrapTableView: UIView!
    @IBOutlet private weak var tableView: UITableView!
    @IBOutlet private weak var footerView: UIView!
    @IBOutlet private weak var versionLabel: UILabel!

    private let notificationService = NotificationService.shared

    static func instantiate() -> UINavigationController {
        let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SettingsViewController")
        return SettingsNavigationController(rootViewController: vc)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        setupUI()
        setupNavigationBar()
        setupTableView()
    }

    override var preferredStatusBarStyle: UIStatusBarStyle { .default }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)

        setNeedsStatusBarAppearanceUpdate()
    }

    private func setupUI() {
        navigationItem.title = "Preferences"
        navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
    }

    private func setupNavigationBar() {
        let closeBarButtonItem = UIBarButtonItem(image: UIImage(named: "navigation-bar-close"), style: .plain, target: self, action: #selector(closeSettings))
        navigationItem.leftBarButtonItem = closeBarButtonItem
    }
    
    private func setupTableView() {
        tableView.dataSource = self
        tableView.delegate = self
        tableView.register(UINib(nibName: "SettingsTableViewCell", bundle: nil), forCellReuseIdentifier: "settingsCell")

        tableView.contentInset = UIEdgeInsets(top: 5, left: 0, bottom: 0, right: 0)
        tableView.tableHeaderView = nil
        tableView.tableFooterView = footerView

        let currentVersion = Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "4.2.1"
        versionLabel.text = "Version \(currentVersion)"

        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(openVoidDigital))
        footerView.isUserInteractionEnabled = true
        footerView.addGestureRecognizer(tapGesture)
    }

    @objc private func closeSettings() {
        dismiss(animated: true, completion: nil)
    }

    @objc private func openVoidDigital() {
        guard let url = URL(string: "https://voiddigital.com") else { return }
        UIApplication.shared.open(url, options: [:], completionHandler: nil)
    }

    // MARK: - Menu actions
    private func showArchivedThoughts() {
        let vc = ListViewController.instantiate(listType: .archive)
        navigationController?.pushViewController(vc, animated: true)
    }

    private func chooseExportFileType() {
        let vc = ExportSelectionViewController.instantiate()
        navigationController?.pushViewController(vc, animated: true)
    }

    private func shareFeedback() {
        guard let url = URL(string: "https://www.chrissteib.com/contact-transom") else { return }
        UIApplication.shared.open(url, options: [:])
    }

    private func rateApp() {
        guard let url = URL(string: "itms-apps://itunes.apple.com/app/927983947") else { return }

        UIApplication.shared.open(url, options: [:], completionHandler: nil)
    }

    private func showTransomFriends() {
        guard let url = URL(string: "https://bookshop.org/lists/friends-of-transom") else { return }

        UIApplication.shared.open(url, options: [:], completionHandler: nil)
    }

    private func showAboutUs() {
        let vc = TextViewController.instantiate(type: .about)
        navigationController?.pushViewController(vc, animated: true)
    }

    private func showLegalStuff() {
        let vc = TextViewController.instantiate(type: .legal)
        navigationController?.pushViewController(vc, animated: true)
    }

    private func showAuthScreen() {
        guard let authVC = ColdOpeningVC.instantiate() else { return }
        setRootViewController(viewController: authVC)
    }

    private func logout() {
        let firebaseAuth = Auth.auth()

        do {
            try firebaseAuth.signOut()
            FirebaseService.shared.reset()
            PromptsService.shared.reset()
            showAuthScreen()
        } catch let error {
            print("Error signing out: \(error.localizedDescription)")
        }
    }

    private func showNotificationsPermissionAlert() {
        DispatchQueue.main.async {
            let alertController = UIAlertController(title: "Notification Permission", message: "Please enable notifications for Transom in settings", preferredStyle: .alert)

            let enableAction = UIAlertAction(title: "Open Settings", style: .default) { _ in
                guard let settingsUrl = URL(string: UIApplication.openSettingsURLString) else {
                    return
                }

                if UIApplication.shared.canOpenURL(settingsUrl) {
                    UIApplication.shared.open(settingsUrl, options: [:], completionHandler: nil)
                }
            }
            let cancelAction = UIAlertAction(title: "Later", style: .cancel, handler: nil)

            alertController.addAction(enableAction)
            alertController.addAction(cancelAction)

            self.present(alertController, animated: true, completion: nil)
        }
    }
}

extension SettingsViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 9
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard indexPath.row != 1 else {
            let cell = tableView.dequeueReusableCell(withIdentifier: "dailyWordsCell", for: indexPath) as! SettingsSwitchTableViewCell
            cell.updateSwitch(isOn: UserDefaults.isDailyWordRemindersEnabled)
            cell.delegate = self
            return cell
        }

        guard indexPath.row != 5 else {
            return tableView.dequeueReusableCell(withIdentifier: "friendsCell", for: indexPath)
        }

        guard let cell = tableView.dequeueReusableCell(withIdentifier: "settingsCell", for: indexPath) as? SettingsTableViewCell else {
            return UITableViewCell()
        }

        switch indexPath.row {
        case 0:
            cell.setup(label: "View Archived Thoughts", imageName: "settings-arrow", imageSize: CGSize(width: 8, height: 12), imageMargin: 30)
        case 2:
            cell.setup(label: "Export Thoughts", imageName: "settings-arrow", imageSize: CGSize(width: 8, height: 12), imageMargin: 30)
        case 3:
            cell.setup(label: "Contact Us", imageName: "settings-email", imageSize: CGSize(width: 24, height: 16), imageMargin: 24)
        case 4:
            cell.setup(label: "Rate and Review Transom", imageName: "settings-star", imageSize: CGSize(width: 19, height: 18), imageMargin: 26)
        case 6:
            cell.setup(label: "Who We Are", imageName: "settings-docs", imageSize: CGSize(width: 16, height: 20), imageMargin: 28)
        case 7:
            cell.setup(label: "Legal Stuff", imageName: "settings-docs", imageSize: CGSize(width: 16, height: 20), imageMargin: 28)
        case 8:
            cell.setup(label: "Log Out", description: Auth.auth().currentUser?.email, imageName: "settings-logout", imageSize: CGSize(width: 18, height: 20), imageMargin: 30)
        default:
            break
        }

        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        switch indexPath.row {
        case 0:
            showArchivedThoughts()
        case 2:
            chooseExportFileType()
        case 3:
            shareFeedback()
        case 4:
            rateApp()
        case 5:
            showTransomFriends()
        case 6:
            showAboutUs()
        case 7:
            showLegalStuff()
        case 8:
            logout()
        default:
            break
        }
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80
    }
}

extension SettingsViewController: SettingsSwitchDelegate {
    func onSwitchChanged(value: Bool) {
        FirebaseService.shared.updateDailyWordReminders(isEnabled: value)
        
        if (value) {
            notificationService.getNotificationsStatus { [weak self] status in
                guard let self = self else { return }

                switch status {
                case .notDetermined:
                    DispatchQueue.main.async {
                        self.notificationService.askNotificationsPermission()
                    }
                case .denied:
                    self.showNotificationsPermissionAlert()
                case .authorized:
                    self.notificationService.scheduleDailyWordNotifications()
                default:
                    break
                }
            }
        } else {
            self.notificationService.deleteScheduledNotifications()
        }
    }
}
