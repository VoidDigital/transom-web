//
//  TextViewController.swift
//  transom
//
//  Created by Roma Sosnovsky on 9/19/19.
//  Copyright © 2019 Void Digital. All rights reserved.
//

import UIKit

class TextViewController: UIViewController {
    @IBOutlet private weak var textView: UITextView!

    private var type: AboutTextType = .about

    static func instantiate(type: AboutTextType) -> TextViewController {
        let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "TextViewController") as! TextViewController
        vc.type = type
        return vc
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        setupUI()
        setupTextView()
    }

    private func setupUI() {
        navigationItem.title = type.title

        let closeBarButtonItem = UIBarButtonItem(image: UIImage(named: "back"), style: .plain, target: self, action: #selector(goBack))
        navigationItem.leftBarButtonItem = closeBarButtonItem
    }

    private func setupTextView() {
        textView.attributedText = type.text
        textView.contentInset = UIEdgeInsets(top: 15, left: 15, bottom: 15, right: 15)
        textView.isEditable = false
        textView.isSelectable = true
    }
}
