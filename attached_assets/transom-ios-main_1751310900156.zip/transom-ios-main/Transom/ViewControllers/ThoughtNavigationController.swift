//
//  ThoughtNavigationController.swift
//  transom
//
//  Created by Roma Sosnovsky on 17.02.2020.
//  Copyright © 2020 Void Digital. All rights reserved.
//

import UIKit

enum ThoughtAction {
    case share, archive, delete
}

class ThoughtNavigationController: UINavigationController {
    private var thought: FBThought?
    private weak var previewDelegate: ThoughtListDelegate?

    static func instantiate(thought: FBThought?, rootViewController: UIViewController, previewDelegate: ThoughtListDelegate?) -> ThoughtNavigationController {
        let vc = ThoughtNavigationController(rootViewController: rootViewController)
        vc.thought = thought
        vc.previewDelegate = previewDelegate
        return vc
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        setupNavigationBar()
    }

    private func setupNavigationBar() {
        let tintColor = UIColor(red: 65/255, green: 65/255, blue: 65/255, alpha: 1)
        navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: tintColor]
        navigationBar.barTintColor = nil
        navigationBar.tintColor = tintColor

        if #available(iOS 15, *) {
            let appearance = UINavigationBarAppearance()
            appearance.configureWithOpaqueBackground()
            appearance.titleTextAttributes = [.foregroundColor: tintColor]
            appearance.backgroundColor = UIColor(red: 248/255, green: 248/255, blue: 248/255, alpha: 1)
            navigationBar.standardAppearance = appearance
            navigationBar.scrollEdgeAppearance = appearance
            navigationBar.compactAppearance = appearance
        }
    }

    override var previewActionItems: [UIPreviewActionItem] {
        guard let thought = thought else { return [] }

        let shareAction = UIPreviewAction(title: "Share this Thought", style: .default) { [weak self] _, _ in
            self?.previewDelegate?.didSelect(action: .share, for: thought)
        }

        let archiveAction = UIPreviewAction(title: "Send to Archives", style: .default) { [weak self] _, _ in
            self?.previewDelegate?.didSelect(action: .archive, for: thought)
        }

        let deleteAction = UIPreviewAction(title: "Delete it Forever", style: .destructive) { [weak self] _, _ in
            self?.previewDelegate?.didSelect(action: .delete, for: thought)
        }

        return [shareAction, archiveAction, deleteAction]
    }
}
