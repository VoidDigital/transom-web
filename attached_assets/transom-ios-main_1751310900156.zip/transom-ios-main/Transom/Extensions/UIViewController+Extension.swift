//
//  UIViewController+Extension.swift
//  transom
//
//  Created by Roma Sosnovsky on 8/9/19.
//  Copyright © 2019 Void Digital. All rights reserved.
//

import UIKit

extension UIViewController {
    func showMessage(title: String?, text: String, buttonTitle: String = "Close", handler: ((UIAlertAction) -> Void)? = nil) {
        let alertController = UIAlertController(title: title, message: text, preferredStyle: .alert)
        let closeAction = UIAlertAction(title: buttonTitle, style: .default, handler: handler)
        alertController.addAction(closeAction)

        DispatchQueue.main.async {
            self.present(alertController, animated: true, completion: nil)
        }
    }

    func showError(text: String) {
        showMessage(title: "Error", text: text)
    }

    func setRootViewController(viewController: UIViewController) {
        guard let window = UIApplication.shared.keyWindow else { return }

        DispatchQueue.main.async {
            UIView.transition(with: window, duration: 0.5, options: UIView.AnimationOptions.transitionFlipFromRight, animations: {
                UIApplication.shared.keyWindow?.rootViewController = viewController
            }, completion: nil)
        }
    }

    var topMostViewController: UIViewController {
        if let presented = self.presentedViewController {
            return presented.topMostViewController
        }

        if let navigation = self as? UINavigationController {
            return navigation.visibleViewController?.topMostViewController ?? navigation
        }

        if let tab = self as? UITabBarController {
            return tab.selectedViewController?.topMostViewController ?? tab
        }

        return self
    }
    
    @objc func goBack() {
        navigationController?.popViewController(animated: true)
    }
}
