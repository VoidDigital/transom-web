//
//  String+Extensions.swift
//  transom
//
//  Created by Roma Sosnovsky on 9/17/19.
//  Copyright © 2019 Void Digital. All rights reserved.
//

import Foundation

extension String {
    var isValidPassword: Bool {
        let regularExpression = "^(?=.*?[A-Za-z0-9]).{6,}"
        let passwordValidation = NSPredicate.init(format: "SELF MATCHES %@", regularExpression)
        return passwordValidation.evaluate(with: self)
    }

    var isValidEmail: Bool {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}"
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailTest.evaluate(with: self)
    }
}
