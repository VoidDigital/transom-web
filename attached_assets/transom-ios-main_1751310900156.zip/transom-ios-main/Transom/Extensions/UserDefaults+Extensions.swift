//
//  UserDefaults+Extensions.swift
//  transom
//

import Foundation

extension UserDefaults {
    
    //MARK: - Consts
    
    private enum Consts {
        static let numberOfThoughtsKey = "numberofThoughts"
        static let reviewRequestLastDateKey = "reviewrequestLastDate"
        static let reviewRequestLastVersionKey = "reviewRequestLastVersion"
        static let showWordsCountKey = "showWordsCount"
        static let showDailyWordReminders = "showDailyWordReminders"
        static let didAskForDailyWordReminders = "didAskForDailyWordReminders"
        static let todayWordsCount = "todayWordsCount"
    }
    
    static func increaseNumberOfThoughts() {
        let userDefaults = UserDefaults.standard
        var numberOfThoughts = userDefaults.integer(forKey: Consts.numberOfThoughtsKey)
        numberOfThoughts += 1
        userDefaults.set(numberOfThoughts, forKey: Consts.numberOfThoughtsKey)
    }
    
    static func getNumberOfThoughts() -> Int {
        UserDefaults.standard.integer(forKey: Consts.numberOfThoughtsKey)
    }
    
    static func setReviewRequestLastDate() {
        UserDefaults.standard.set(Date(), forKey: Consts.reviewRequestLastDateKey)
    }
    
    static func getReviewRequestLastDate() -> Date? {
        UserDefaults.standard.value(forKey: Consts.reviewRequestLastDateKey) as? Date
    }
    
    static func setReviewRequestLastVersion() {
        let currentVersion = AppInfo.getCurrentVersion()
        UserDefaults.standard.set(currentVersion, forKey: Consts.reviewRequestLastVersionKey)
    }
    
    static func getReviewRequestLastVersion() -> String? {
        UserDefaults.standard.string(forKey: Consts.reviewRequestLastVersionKey)
    }
    
    static func showWordsCount() -> Bool {
        return true
//        let showWordsCount = UserDefaults.standard.object(forKey: Consts.showWordsCountKey)
//        if showWordsCount == nil {
//            setShowWordCount(true)
//        }
//        return UserDefaults.standard.bool(forKey: Consts.showWordsCountKey)
    }
    
    static func setShowWordCount(_ value: Bool) {
        UserDefaults.standard.set(value, forKey: Consts.showWordsCountKey)
    }

    static var isDailyWordRemindersEnabled: Bool {
        UserDefaults.standard.bool(forKey: Consts.showDailyWordReminders)
    }

    static func updateDailyWordReminders(isEnabled: Bool) {
        UserDefaults.standard.set(isEnabled, forKey: Consts.showDailyWordReminders)
    }

    static var didAskForDailyWordReminders: Bool {
        UserDefaults.standard.bool(forKey: Consts.didAskForDailyWordReminders)
    }

    static func updateDidAskForDailyWordReminders(didAsk: Bool) {
        UserDefaults.standard.set(didAsk, forKey: Consts.didAskForDailyWordReminders)
    }

    static var todayWordsCount: Int {
        UserDefaults.standard.integer(forKey: Consts.todayWordsCount)
    }

    static func updateTodayWordsCount(_ wordsCount: Int) {
        UserDefaults.standard.set(wordsCount, forKey: Consts.todayWordsCount)

        if wordsCount >= Config.dailyWordsGoal {
            NotificationService.shared.deleteTodayNotification()
        }
    }
}
