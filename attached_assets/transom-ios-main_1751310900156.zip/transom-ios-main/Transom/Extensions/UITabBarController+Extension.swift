//
//  UITabBarController+Extension.swift
//  transom
//
//  Created by Roma Sosnovsky on 07.02.2020.
//  Copyright © 2020 Void Digital. All rights reserved.
//

import UIKit

extension UITabBarController {
    var orderedTabBarItemViews: [UIView] {
        return tabBar.subviews.filter { $0.isUserInteractionEnabled }.sorted(by: {$0.frame.minX < $1.frame.minX})
    }
}
