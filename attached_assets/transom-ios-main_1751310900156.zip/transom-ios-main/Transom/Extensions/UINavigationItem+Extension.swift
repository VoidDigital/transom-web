//
//  UINavigationItem+Extension.swift
//  transom
//
//  Created by Roma Sosnovsky on 9/24/19.
//  Copyright © 2019 Void Digital. All rights reserved.
//

import UIKit

extension UINavigationItem {
    func setTitle(title: String, subtitle: String) {
        let titleLabel = UILabel()
        titleLabel.text = title
        titleLabel.font = UIFont.systemFont(ofSize: 16, weight: .medium)
        titleLabel.textColor = UIColor(red: 65/255, green: 65/255, blue: 65/255, alpha: 1)
        titleLabel.sizeToFit()

        let subtitleLabel = UILabel()
        subtitleLabel.text = subtitle
        subtitleLabel.font = UIFont.systemFont(ofSize: 12)
        subtitleLabel.textColor = UIColor(red: 162/255, green: 168/255, blue: 172/255, alpha: 1)
        subtitleLabel.textAlignment = .center
        subtitleLabel.sizeToFit()

        let stackView = UIStackView(arrangedSubviews: [titleLabel, subtitleLabel])
        stackView.distribution = .equalCentering
        stackView.axis = .vertical
        stackView.alignment = .center

        let width = max(titleLabel.frame.size.width, subtitleLabel.frame.size.width)
        stackView.frame = CGRect(x: 0, y: 0, width: width, height: 35)

        titleLabel.sizeToFit()
        subtitleLabel.sizeToFit()

        self.titleView = stackView
    }
}
