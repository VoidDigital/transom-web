//
//  UISearchBar+Extension.swift
//  transom
//
//  Created by Roma Sosnovsky on 9/4/19.
//  Copyright © 2019 Void Digital. All rights reserved.
//

import UIKit

extension UISearchBar {
    public var textField: UITextField? {
        guard let firstSubview = subviews.first else {
            return nil
        }

        if #available(iOS 13.0, *) {
            return searchTextField
        } else {
            for view in firstSubview.subviews {
                if let textView = view as? UITextField {
                    return textView
                }
            }
        }

        return nil
    }
}
