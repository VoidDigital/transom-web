//
//  UIView+Extension.swift
//  transom
//
//  Created by Roma Sosnovsky on 05/03/21.
//  Copyright © 2021 Void Digital. All rights reserved.
//

import UIKit

extension UIView {

    enum ViewSide {
        case left, right, top, bottom
    }

    func addBorder(toSide side: ViewSide = .bottom, withColor color: UIColor? = nil, andThickness thickness: CGFloat = 1) {
        let borderColor = color ?? UIColor(red: 237/255, green: 237/255, blue: 237/255, alpha: 1)
        
        let border = CALayer()
        border.backgroundColor = borderColor.cgColor

        switch side {
        case .left: border.frame = CGRect(x: frame.origin.x, y: frame.origin.y, width: thickness, height: frame.size.height)
        case .right: border.frame = CGRect(x: frame.size.width - thickness, y: frame.origin.y, width: thickness, height: frame.size.height)
        case .top: border.frame = CGRect(x: frame.origin.x, y: frame.origin.y, width: frame.size.width, height: thickness)
        case .bottom: border.frame = CGRect(x: frame.origin.x, y: frame.size.height - thickness, width: frame.size.width, height: thickness)
        }
        layer.addSublayer(border)
    }
}
