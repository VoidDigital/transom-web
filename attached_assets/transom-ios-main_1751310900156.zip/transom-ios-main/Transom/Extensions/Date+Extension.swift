//
//  Date+Extension.swift
//  transom
//
//  Created by Roma Sosnovsky on 30.04.2020.
//  Copyright © 2020 Void Digital. All rights reserved.
//

import Foundation

extension Date {
    var relativeDateString: String {
        let calendar = Calendar.current
        let minuteAgo = calendar.date(byAdding: .minute, value: -1, to: Date())!
        let hourAgo = calendar.date(byAdding: .hour, value: -1, to: Date())!
        let dayAgo = calendar.date(byAdding: .day, value: -1, to: Date())!
        let twoDaysAgo = calendar.date(byAdding: .day, value: -2, to: Date())!

        if minuteAgo < self {
            return "Just Now"
        } else if hourAgo < self {
            let diff = Calendar.current.dateComponents([.minute], from: self, to: Date()).minute ?? 0
            let word = diff == 1 ? "minute" : "minutes"
            return "\(diff) \(word) ago"
        } else if dayAgo < self {
            let diff = Calendar.current.dateComponents([.hour], from: self, to: Date()).hour ?? 0
            let word = diff == 1 ? "hour" : "hours"
            return "\(diff) \(word) ago"
        } else if twoDaysAgo < self {
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "MMMM d, h:mm a"
            return dateFormatter.string(from: self)
        }
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MMMM d"
        return dateFormatter.string(from: self)
    }
}
