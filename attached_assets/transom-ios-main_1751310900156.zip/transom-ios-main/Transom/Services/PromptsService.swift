//
//  PromptsService.swift
//  transom
//
//  Created by Roma Sosnovsky on 06/05/21.
//  Copyright © 2021 Void Digital. All rights reserved.
//

import Firebase
import FirebaseDatabase
import FirebaseFirestore
import FirebaseFirestoreSwift
import Foundation

class PromptsService {
    static let shared = PromptsService()
    
    private let starterPackId = "un63j689gfPU8iIZxAD2"
    
    var packs: [PromptPack] = []
    var userPromptsPacks: [String: [String]] = [:]
    
    var boughtPacksIds: [String] = []
    var boughtPacks: [PromptPack] {
        packs.filter {
            guard let id = $0.id else { return false }
            return id == starterPackId || boughtPacksIds.contains(id)
        }
    }
    private var boughtPacksIdsReference: DatabaseReference? {
        guard let uid = Auth.auth().currentUser?.email else {
            return nil
        }

        return Database.database().reference(withPath: uid.makeFirebaseString()).child("boughtPacksIds")
    }
    private var boughtPacksIdsHandle: DatabaseHandle?
    
    var storePacks: [PromptPack] {
        packs.filter {
            guard let id = $0.id else { return false }
            return id != starterPackId && !boughtPacksIds.contains(id)
        }
    }
    
    let boughtPacksListener = BoughtPromptPacksListenerDelegate(delegates: [])
    let creditsListener = CreditsBalanceListenerDelegate(delegates: [])
    
    var creditsAmount = 0 {
        didSet {
            creditsListener.creditsBalanceDidChange()
        }
    }
    
    private var creditsAmountReference: DatabaseReference? {
        guard let uid = Auth.auth().currentUser?.email else {
            return nil
        }

        return Database.database().reference(withPath: uid.makeFirebaseString()).child("creditsAmount")
    }
    private var creditsAmountHandle: DatabaseHandle?
    
    var didShowOnboarding: Bool {
        get {
            UserDefaults.standard.bool(forKey: "didShowPromptsOnboarding")
        }
        set {
            UserDefaults.standard.setValue(true, forKey: "didShowPromptsOnboarding")
        }
    }
    
    var didShowTooltip: Bool {
        get {
            UserDefaults.standard.bool(forKey: "didShowPromptsTooltip")
        }
        set {
            UserDefaults.standard.setValue(true, forKey: "didShowPromptsTooltip")
        }
    }
    
    private let db = Firestore.firestore()
    
    private var userPromptsReference: DatabaseReference? {
        guard let uid = Auth.auth().currentUser?.email else { return nil }
        return Database.database().reference(withPath: uid.makeFirebaseString()).child("promptsPacks")
    }
    
    func loadData() {
        loadPrompts()
        getUserPrompts()
        getBoughtPackIds()
        getCreditsAmount()
    }
    
    func loadPrompts() {
        guard packs.isEmpty else { return }
        
        db.collection("promptCollections").getDocuments { [weak self] snapshot, err in
            guard let self = self,
                  let packs = snapshot?.documents.compactMap({ try? $0.data(as: PromptPack.self) })
            else { return }
            
            self.packs = packs.filter { $0.isPublished }
        }
    }
    
    private func getUserPrompts() {
        guard let ref = userPromptsReference else { return }

        ref.observeSingleEvent(of: .value) { snapshot in
            if let promptsPacks = snapshot.value as? [String: [String]] {
                self.userPromptsPacks = promptsPacks
            }
        }
    }
    
    func getPrompt(from pack: PromptPack) -> String? {
        guard let id = pack.id else { return nil }
  
        var prompts = (userPromptsPacks[id] ?? pack.prompts.shuffled())
        
        if prompts.isEmpty { prompts = pack.prompts.shuffled() }
        
        let promptToUse = prompts.removeFirst()
        prompts.append(promptToUse)
        
        userPromptsPacks[id] = prompts
        userPromptsReference?.setValue(userPromptsPacks)
        
        return promptToUse
    }
    
    func add(prompt: String, packId: String?) {
        guard let id = packId,
              let prompts = userPromptsPacks[id],
              !prompts.contains(prompt)
        else { return }
        
        userPromptsPacks[id] = prompts + [prompt]
        userPromptsReference?.setValue(userPromptsPacks)
    }
    
    func use(prompt: String, packId: String?) {
        guard let id = packId else { return }
        
        if let prompts = userPromptsPacks[id], !prompts.isEmpty {
            let updatedPrompts = prompts.filter { $0 != prompt }
            
            if updatedPrompts.isEmpty {
                userPromptsPacks.removeValue(forKey: id)
            } else {
                userPromptsPacks[id] = updatedPrompts
            }
        } else if let pack = packs.first(where: { $0.id == id }) {
            userPromptsPacks[id] = pack.prompts.filter { $0 != prompt }
        }
        
        userPromptsReference?.setValue(userPromptsPacks)
    }
    
    func getCreditsAmount() {
        guard let ref = creditsAmountReference else { return }
        
        creditsAmountHandle = ref.observe(.value) { [weak self] snapshot in
            guard let amount = snapshot.value as? Int
            else {
                self?.creditsAmount = 0
                return
            }
            
            self?.creditsAmount = amount
        }
    }
    
    func updateCreditsAmount(change: Int, handler: ((Int) -> Void)? = nil) {
        guard let ref = creditsAmountReference else { return }
        ref.getData { (error, snapshot) in
            if let currentAmount = snapshot.value as? Int {
                ref.setValue(currentAmount + change)
                handler?(currentAmount + change)
            } else {
                ref.setValue(change)
                handler?(change)
            }
        }
    }
    
    private func getBoughtPackIds() {
        guard let ref = boughtPacksIdsReference else { return }
        
        ref.getData { [weak self] (error, snapshot) in
            guard let self = self,
                  let ids = snapshot.value as? [String]
            else { return }
            
            self.boughtPacksIds = ids
            self.boughtPacksListener.boughtPacksDidChange()
        }
    }
    
    func buy(pack: PromptPack, handler: ((Bool) -> Void)?) {
        guard let packId = pack.id,
              let price = pack.price, price > 0
        else { handler?(false); return }
        
        updateCreditsAmount(change: -price)
        
        guard let ref = boughtPacksIdsReference else { handler?(false); return }
        
        ref.getData { [weak self] (error, snapshot) in
            guard let self = self else { return }
            
            let currentIds = snapshot.value as? [String] ?? []
            let updatedIds = currentIds + [packId]
            
            ref.setValue(updatedIds)

            handler?(true)
            
            self.boughtPacksIds = updatedIds
            self.boughtPacksListener.boughtPacksDidChange()
        }
    }
    
    func reset() {
        boughtPacksIdsHandle = nil
        creditsAmountHandle = nil

        boughtPacksIds = []
        userPromptsPacks = [:]
        creditsAmountHandle = nil
        creditsAmount = 0
    }
}
