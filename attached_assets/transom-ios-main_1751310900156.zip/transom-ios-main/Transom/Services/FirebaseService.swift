//
//  FirebaseService.swift
//  transom
//
//  Created by Roma Sosnovsky on 8/25/19.
//  Copyright © 2019 Void Digital. All rights reserved.
//

import FirebaseAuth
import FirebaseDatabase
import Foundation

class FirebaseService {
    static let shared = FirebaseService()

    private let ref = Database.database().reference()

    private var currentDateString: String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        return dateFormatter.string(from: Date())
    }

    var didGetThoughts = false
    var thoughts: [FBThought] = []
    var thoughtsHandle: DatabaseHandle?

    var didGetTags = false
    var tags: [FBTag] = []
    var tagsHandle: DatabaseHandle?

    var projectsList: [FBTag] { tags.filter { $0.isPiece } }
    var tagsList: [FBTag] { tags.filter { !$0.isPiece } }
    var nonArchivedThoughts: [FBThought] { thoughts.filter { !$0.isArchived } }

    let thoughtsListener = ThoughtsListenerDelegate(delegates: [])
    let tagsListener = TagsListenerDelegate(delegates: [])

    func getThought(id: String, completion: @escaping ((FBThought?) -> Void)) {
        if let thought = thoughts.first(where: { $0.itemKey == id }) {
            completion(thought)
        } else {
            guard let ref = FBThought.thoughtsRef?.child(id) else {
                completion(nil)
                return
            }

            ref.observeSingleEvent(of: .value) { snapshot in
                guard let json = snapshot.value as? [String: AnyObject] else {
                    completion(nil)
                    return
                }
                ref.removeAllObservers()
                let fbThought = FBThought(key: id, snapshotValue: json)
                completion(fbThought)
            }
        }
    }

    func getUserThoughts(completion: @escaping ([FBThought]) -> Void) {
        guard !didGetThoughts else {
            completion(nonArchivedThoughts)
            return
        }

        guard let ref = FBThought.thoughtsRef else { return }

        thoughtsHandle = ref.observe(.value) { [weak self] snapshot in
            guard let self = self else { return }

            var thoughts: [FBThought] = []

            if let json = snapshot.value as? [String: Any] {
                for key in json.keys {
                    if let snapshotValue = json[key] as? [String: AnyObject] {
                        let fbThought = FBThought(key: key, snapshotValue: snapshotValue)
                        thoughts.append(fbThought)
                    }
                }
            }

            self.thoughts = thoughts.sorted(by: { $0.updatedAt > $1.updatedAt })

            if let handle = self.thoughtsHandle {
                ref.removeObserver(withHandle: handle)
            }

            self.didGetThoughts = true
            self.setupThoughtsListener()

            completion(self.nonArchivedThoughts)
        }
    }

    func setupThoughtsListener() {
        FBThought.thoughtsRef?.observe(.childAdded) { snapshot in
            guard let json = snapshot.value as? [String: AnyObject] else { return }

            let fbThought = FBThought(key: snapshot.key, snapshotValue: json)

            if (!self.thoughts.contains(fbThought)) {
                self.thoughts.insert(fbThought, at: 0)
                self.thoughts.sort(by: { $0.updatedAt > $1.updatedAt })
                self.thoughtsListener.didAdd(thought: fbThought)
            }
        }

        FBThought.thoughtsRef?.observe(.childChanged) { snapshot in
            guard let json = snapshot.value as? [String: AnyObject] else { return }

            let fbThought = FBThought(key: snapshot.key, snapshotValue: json)

            if let thoughtIndex = self.thoughts.firstIndex(of: fbThought) {
                self.thoughts[thoughtIndex] = fbThought
                self.thoughts.sort(by: { $0.updatedAt > $1.updatedAt })
                self.thoughtsListener.didUpdated(thought: fbThought)
            }
        }

        FBThought.thoughtsRef?.observe(.childRemoved) { snapshot in
            guard let json = snapshot.value as? [String: AnyObject] else { return }

            let fbThought = FBThought(key: snapshot.key, snapshotValue: json)
            self.thoughts = self.thoughts.filter { $0.itemKey != fbThought.itemKey }.sorted(by: { $0.updatedAt > $1.updatedAt })
            self.thoughtsListener.didRemoved(thought: fbThought)
        }
    }

    func getUserArchivedThoughts(completion: @escaping ([FBThought]) -> Void) {
        completion(thoughts.filter({ $0.isArchived }))
    }

    func getUserTags(type: TagType? = nil, completion: @escaping ([FBTag]) -> Void) {
        guard !didGetTags else {
            if let type = type {
                let tags = type == .project ? projectsList : tagsList
                completion(tags)
            } else {
                completion(tags)
            }
            return
        }

        guard let ref = FBTag.tagRef else { return }

        tagsHandle = ref.observe(.value) { [weak self] snapshot in
            guard let self = self else { return }

            var tags: [FBTag] = []

            if let dictionary = snapshot.value as? [String: Any] {
                for (key, _ ) in dictionary {
                    guard let tagDict = dictionary[key] as? [String: Any] else { continue }

                    let name = (tagDict["name"] as? String ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
                    let isPiece = tagDict["isPiece"] as? Bool ?? false
                    let createdAt = tagDict["createdAt"] as? TimeInterval ?? 0

                    guard !name.isEmpty else { continue }

                    let tag = FBTag(name: name, createdAt: createdAt, isPiece: isPiece)
                    if !tags.contains(tag) {
                        tags.append(tag)
                    }
                }
            }

            self.tags = tags.sorted { $0.name.lowercased() < $1.name.lowercased() }

            if let handle = self.tagsHandle {
                ref.removeObserver(withHandle: handle)
            }
            self.didGetTags = true
            self.setupTagsListener()

            if let type = type {
                let tags = type == .project ? self.projectsList : self.tagsList
                completion(tags)
            } else {
                completion(tags)
            }
        }
    }

    func setupTagsListener() {
        guard let ref = FBTag.tagRef else { return }

        ref.observe(.childAdded) { snapshot in
            guard let tagDict = snapshot.value as? [String: Any] else { return }

            let name = (tagDict["name"] as? String ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
            let isPiece = tagDict["isPiece"] as? Bool ?? false
            let createdAt = tagDict["createdAt"] as? TimeInterval ?? 0

            guard !name.isEmpty else { return }

            let tag = FBTag(name: name, createdAt: createdAt, isPiece: isPiece)

            if (!self.tags.contains(tag)) {
                self.tags.insert(tag, at: 0)
                self.tags.sort(by: { $0.name.lowercased() < $1.name.lowercased() })
                self.tagsListener.didAdd(tag: tag)
            }
        }

        ref.observe(.childChanged) { snapshot in
            guard let tagDict = snapshot.value as? [String: Any] else { return }

            let name = (tagDict["name"] as? String ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
            let isPiece = tagDict["isPiece"] as? Bool ?? false
            let createdAt = tagDict["createdAt"] as? TimeInterval ?? 0

            guard !name.isEmpty else { return }

            let tag = FBTag(name: name, createdAt: createdAt, isPiece: isPiece)

            if let tagIndex = self.tags.firstIndex(of: tag) {
                self.tags[tagIndex] = tag
                self.tags.sort(by: { $0.name.lowercased() < $1.name.lowercased() })
                self.tagsListener.didUpdated(tag: tag)
            }
        }

        ref.observe(.childRemoved) { snapshot in
            guard let tagDict = snapshot.value as? [String: Any] else { return }

            let name = (tagDict["name"] as? String ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
            let isPiece = tagDict["isPiece"] as? Bool ?? false
            let createdAt = tagDict["createdAt"] as? TimeInterval ?? 0

            guard !name.isEmpty else { return }

            let tag = FBTag(name: name, createdAt: createdAt, isPiece: isPiece)
            self.tags = self.tags.filter { $0.itemKey != tag.itemKey }.sorted(by: { $0.name.lowercased() < $1.name.lowercased() })
            self.tagsListener.didRemoved(tag: tag)
        }
    }

    func thoughts(for tag: FBTag) -> [FBThought] {
        thoughts.filter { !$0.isArchived && $0.contains(tag: tag) }
    }
    
    func thoughts(for tagName: String) -> [FBThought] {
        thoughts.filter { !$0.isArchived && $0.contains(tagName: tagName) }
    }

    // MARK: - Daily word reminders
    func getDailyWordRemindersStatus() {
        guard let uid = Auth.auth().currentUser?.email else { return }
        let userReference = Database.database().reference(withPath: uid.makeFirebaseString()).child("notifications").child("dailyWordGoal")
        userReference.observe(.value) { snapshot in
            guard let isEnabled = snapshot.value as? Int else { return }

            UserDefaults.updateDailyWordReminders(isEnabled: isEnabled == 1)
            NotificationService.shared.checkScheduledNotifications()
        }
    }

    func updateDailyWordReminders(isEnabled: Bool) {
        guard let uid = Auth.auth().currentUser?.email else { return }
        let userReference = Database.database().reference(withPath: uid.makeFirebaseString())
        userReference.child("notifications").child("dailyWordGoal").setValue(isEnabled)
        UserDefaults.updateDailyWordReminders(isEnabled: isEnabled)
        NotificationCenter.default.post(name: Notification.Name(rawValue: Config.Notifications.didUpdateWordsCount), object: nil)
    }

    func getTodayWordsCount() {
        guard let uid = Auth.auth().currentUser?.email else { return }

        let wordCountReference = Database.database().reference(withPath: uid.makeFirebaseString()).child("dailyWordsCount/\(currentDateString)")
        wordCountReference.observe(.value) { snapshot in
            let currentWordsCount = snapshot.value as? Int ?? 0
            UserDefaults.updateTodayWordsCount(currentWordsCount)
            NotificationCenter.default.post(name: Notification.Name(rawValue: Config.Notifications.didUpdateWordsCount), object: nil)
        }
    }

    func updateDailyWordsCount(_ wordsCount: Int) {
        guard let uid = Auth.auth().currentUser?.email else { return }

        let wordCountReference = Database.database().reference(withPath: uid.makeFirebaseString()).child("dailyWordsCount/\(currentDateString)")
        wordCountReference.keepSynced(true)
        wordCountReference.observeSingleEvent(of: .value) { snapshot in
            let currentWordsCount = snapshot.value as? Int ?? 0
            let updatedWordsCount = currentWordsCount + wordsCount
            wordCountReference.setValue(updatedWordsCount)
            UserDefaults.updateTodayWordsCount(updatedWordsCount)

            NotificationCenter.default.post(name: Notification.Name(rawValue: Config.Notifications.didUpdateWordsCount), object: nil)
        }
    }

    func getDailyWordsCount(handler: @escaping (([String: Int]) -> Void)) {
        guard let uid = Auth.auth().currentUser?.email else {
            handler([:])
            return
        }

        let wordCountReference = Database.database().reference(withPath: uid.makeFirebaseString()).child("dailyWordsCount")
        wordCountReference.observe(.value) { snapshot in
            if let days = snapshot.value as? [String: Int] {
                handler(days)
            } else {
                handler([:])
            }
        }
    }

    // MARK: - Reset
    func reset() {
        didGetThoughts = false
        thoughts = []
        thoughtsHandle = nil

        didGetTags = false
        tags = []
        tagsHandle = nil
    }
}
