//
//  IAPHelper.swift
//  transom
//
//  Created by Roma Sosnovsky on 25/08/21.
//  Copyright © 2021 Void Digital. All rights reserved.
//

import Foundation
import StoreKit

class IAPManager: NSObject {
    
    // MARK: - Custom Types
    enum IAPManagerError: Error {
        case paymentWasCancelled
        case productRequestFailed
    }
    
    enum InAppProductId: String, CaseIterable {
        case promptCredit = "prompt_credit"
        
        var identifier: String {
            "com.voidllc.transom.\(rawValue)"
        }
    }
    
    // MARK: - Properties
    static let shared = IAPManager()
    
    private var products: [SKProduct] = []
    
    var onBuyProductHandler: ((Result<Bool, Error>) -> Void)?
    
    private let productIds: Set<String> = Set(InAppProductId.allCases.map { $0.identifier })
    
    // MARK: - General Methods
    func getPriceFormatted(for product: SKProduct, amount: Int = 1) -> String? {
        let formatter = NumberFormatter()
        formatter.numberStyle = .currency
        formatter.locale = product.priceLocale
        let totalPrice = product.price.multiplying(by: NSDecimalNumber(value: amount))
        return formatter.string(from: totalPrice)
    }
    
    func startObserving() {
        SKPaymentQueue.default().add(self)
    }

    func stopObserving() {
        SKPaymentQueue.default().remove(self)
    }
    
    func canMakePayments() -> Bool {
        SKPaymentQueue.canMakePayments()
    }
    
    func getProduct(id: InAppProductId) -> SKProduct? {
        products.first(where: { $0.productIdentifier == id.identifier })
    }
    
    // MARK: - Get IAP Products
    func getProducts() {
        let request = SKProductsRequest(productIdentifiers: productIds)
        request.delegate = self
        request.start()
    }
    
    // MARK: - Purchase Products
    func buy(product: SKProduct, quantity: Int = 1, withHandler handler: @escaping ((_ result: Result<Bool, Error>) -> Void)) {
        let payment = SKMutablePayment(product: product)
        payment.quantity = quantity
        SKPaymentQueue.default().add(payment)
        
        onBuyProductHandler = handler
    }
}

// MARK: - SKPaymentTransactionObserver
extension IAPManager: SKPaymentTransactionObserver {
    func paymentQueue(_ queue: SKPaymentQueue, updatedTransactions transactions: [SKPaymentTransaction]) {
        transactions.forEach { (transaction) in
            switch transaction.transactionState {
            case .purchased:
                onBuyProductHandler?(.success(true))
                SKPaymentQueue.default().finishTransaction(transaction)
                
            case .restored:
                SKPaymentQueue.default().finishTransaction(transaction)
                
            case .failed:
                if let error = transaction.error as? SKError {
                    if error.code != .paymentCancelled {
                        onBuyProductHandler?(.failure(error))
                    } else {
                        onBuyProductHandler?(.failure(IAPManagerError.paymentWasCancelled))
                    }
                    print("IAP Error:", error.localizedDescription)
                }
                SKPaymentQueue.default().finishTransaction(transaction)
                
            case .deferred, .purchasing: break
            @unknown default: break
            }
        }
    }
}

// MARK: - SKProductsRequestDelegate
extension IAPManager: SKProductsRequestDelegate {
    func productsRequest(_ request: SKProductsRequest, didReceive response: SKProductsResponse) {
        self.products = response.products
    }
    
    func request(_ request: SKRequest, didFailWithError error: Error) {
        #if DEBUG
        print(error)
        #endif
    }
    
    func requestDidFinish(_ request: SKRequest) {
    }
}

// MARK: - IAPManagerError Localized Error Descriptions
extension IAPManager.IAPManagerError: LocalizedError {
    var errorDescription: String? {
        switch self {
        case .productRequestFailed: return "Unable to fetch available In-App Purchase products at the moment."
        case .paymentWasCancelled: return "In-App Purchase process was cancelled."
        }
    }
}
