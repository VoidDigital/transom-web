//
//  NotificationService.swift
//  transom
//
//  Created by Roma Sosnovsky on 31.08.2020.
//  Copyright © 2020 Void Digital. All rights reserved.
//

import Foundation
import UserNotifications

class NotificationService {
    static let shared = NotificationService()

    private let center = UNUserNotificationCenter.current()

    private let dailyWordNotificationTexts = [
        "It's time to write! Keep up your creative momentum with 100 words every day.",
        "Your first draft is your worst draft — but it's the only way to a final draft. So go write 100 words now to get it out of the way.",
        "Fact: 100 Words a Day helps to keep the existential heebie-jeebies away.",
        "Write for your life! Daily creative writing has been shown to reduce stress. So go hammer out 100 words and prepare for bliss.",
        "Quick: whatever has your attention right now, go write 100 words about it to turn potential energy into creative inertia.",
        "Imagine how you'd feel to have written 36,500 words this year. It starts with you writing 100 words...right now.",
        "The journey of a thousand miles begins with 100 words. Or something like that. Anyway, go write a bit, would ya?",
        "Not all who wander are lost. But all who don't write 100 words can never write 50,000. So how about you get started now?",
        "Go write 100 words. We promise it'll. be more rewarding than the social-media fueled anxiety your other push notifications are selling.",
        "Well, you know you can write 100 words. Today's question is: will you?",
        "Don't question it, just write. Thumb out 100 words right now to build up creative momentum.",
        "Creative momentum isn't about quality, it's about consistency. Go write 100 words to get it going.",
        "The best writers write more than the others — that's why they're the best. Go write 100 words for a small step toward greatness.",
        "This notification is brought to you by guilt: go write 100 words or you'll never finish that book.",
        "Kick self-doubt in the teeth: write 100 words right now to prove you've got what it takes to be a writer.",
        "Who's got two thumbs and a dream? That's right, you do. So put those digits to work and write 100 words right now.",
        "Ding ding! It's write o'clock. Time to get your daily 100 words in.",
        "C'mon, it's just 100 words. You probably deleted more than that from your last email. (Smart move, by the way.)",
        "Studies show that people who write 100 words a day are 7x more productive than those who only write 100 words a week.",
        "Fact: writing 100 words a day is proven to deter ogres. Go ahead, try it out, and then tell us if you see any ogres.",
        "Writing 100 words a day is just like taking an ocean cruise, only there's no boat and you don't actually go anywhere.",
        "You're busy, we get it. But those 100 words...well, they're not gonna write themselves today.",
        "Sixteen Awesome People Who Wrote 100 Words Today! You Won't Believe Number Five! (Spoiler alert: it's about to be you.)",
        "Step 1: open Transom. Step 2: write 100 words. Step 3: feel pretty good about that, you deserve it. Step 4: see you tomorrow."
    ]

    func checkScheduledNotifications() {
        guard UserDefaults.isDailyWordRemindersEnabled else {
            deleteScheduledNotifications()
            return
        }

        center.getPendingNotificationRequests { [weak self] requests in
            guard let self = self, requests.count < 6 else { return }

            self.scheduleDailyWordNotifications()
        }
    }

    func scheduleDailyWordNotifications() {
        deleteScheduledNotifications()

        let calendar = Calendar.current
        let randomizedNotifications = dailyWordNotificationTexts.shuffled()
        var currentDate = Date()

        if UserDefaults.todayWordsCount >= Config.dailyWordsGoal {
            currentDate = calendar.date(byAdding: .day, value: 1, to: currentDate)!
        }

        for notificationText in randomizedNotifications {
            let content = UNMutableNotificationContent()
            content.body = notificationText
            content.categoryIdentifier = "dailyWordReminder"

            var dateComponents = calendar.dateComponents([.year, .month, .day, .hour, .minute], from: currentDate)
            dateComponents.minute = Int.random(in: 0..<60)
            if calendar.isDateInToday(currentDate) {
                let todayDateComponents = calendar.dateComponents([.hour, .minute], from: currentDate)

                guard let hour = todayDateComponents.hour, hour < 18 else {
                    return
                }

                dateComponents.hour = Int.random(in: hour+1..<19)
                addNotification(date: dateComponents, content: content)
            } else {
                dateComponents.hour = Int.random(in: 10..<19)
                addNotification(date: dateComponents, content: content)
            }

            currentDate = calendar.date(byAdding: .day, value: 1, to: currentDate)!
        }
    }

    func addNotification(date: DateComponents, content: UNNotificationContent) {
        let trigger = UNCalendarNotificationTrigger(dateMatching: date, repeats: true)

        let request = UNNotificationRequest(identifier: UUID().uuidString, content: content, trigger: trigger)
        center.add(request, withCompletionHandler: nil)
    }

    func deleteTodayNotification() {
        center.getPendingNotificationRequests { [weak self] requests in
            guard let self = self else { return }
            let calendar = Calendar.current
            let todayRequests = requests.filter {
                if let trigger = $0.trigger as? UNCalendarNotificationTrigger, let triggerDate = trigger.nextTriggerDate() {
                    return calendar.isDateInToday(triggerDate)
                }

                return false
            }
            let identifiers = todayRequests.map { $0.identifier }
            self.center.removePendingNotificationRequests(withIdentifiers: identifiers)
        }
    }

    func deleteScheduledNotifications() {
        center.removeAllPendingNotificationRequests()
    }

    func askNotificationsPermission(handler: ((Bool) -> Void)? = nil) {
        center.requestAuthorization(options: [.alert, .sound, .badge]) { [weak self] granted, error in
            guard let self = self else { return }

            if (granted) {
                FirebaseService.shared.updateDailyWordReminders(isEnabled: true)
                self.scheduleDailyWordNotifications()
            } else {
                self.deleteScheduledNotifications()
            }

            handler?(granted)
        }
    }

    func getNotificationsStatus(handler: @escaping ((UNAuthorizationStatus) -> Void)) {
        center.getNotificationSettings { settings in
            handler(settings.authorizationStatus)
        }
    }
}
