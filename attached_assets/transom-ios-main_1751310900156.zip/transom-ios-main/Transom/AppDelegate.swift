//
//  AppDelegate.swift
//  transom
//
//  Created by Roma Sosnovsky on 7/18/19.
//  Copyright © 2019 Two Sun Traders. All rights reserved.
//

import FirebaseAuth
import FirebaseCore
import FirebaseDatabase
import Mixpanel
import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?
    var shortcutItemToProcess: UIApplicationShortcutItem?

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        FirebaseApp.configure()
        
        Mixpanel.initialize(token: "935440d67c2ebf5cd49f690fde350c25")

        Database.database().isPersistenceEnabled = true
        UNUserNotificationCenter.current().delegate = self

        setupNavigationBar()
        checkIfUserSignedIn()
        
        IAPManager.shared.startObserving()

        if let shortcutItem = launchOptions?[UIApplication.LaunchOptionsKey.shortcutItem] as? UIApplicationShortcutItem {
           shortcutItemToProcess = shortcutItem
        }

        return true
    }

    func application(_ app: UIApplication, open url: URL, options: [UIApplication.OpenURLOptionsKey : Any] = [:]) -> Bool {
        return handle(url: url)
    }

    func handle(url: URL) -> Bool {
        guard let components = NSURLComponents(url: url, resolvingAgainstBaseURL: true),
            let path = components.path,
            let params = components.queryItems else {
                return false
        }

        if path == "thought", let thoughtId = params.first(where: { $0.name == "id" })?.value {
            guard let tabVC = window?.rootViewController as? MainTabBarController else { return false }
            DispatchQueue.main.async {
                tabVC.openThought(id: thoughtId)
            }
        }

        return true
    }

    func application(_ application: UIApplication, performActionFor shortcutItem: UIApplicationShortcutItem, completionHandler: @escaping (Bool) -> Void) {
        shortcutItemToProcess = shortcutItem
    }

    func applicationDidBecomeActive(_ application: UIApplication) {
        guard let shortcutItem = shortcutItemToProcess else { return }

        processShortcutItem(shortcutItem: shortcutItem)
    }
    
    func applicationWillTerminate(_ application: UIApplication) {
        IAPManager.shared.stopObserving()
    }

    func processShortcutItem(shortcutItem: UIApplicationShortcutItem) {
        shortcutItemToProcess = nil

        guard Auth.auth().currentUser != nil, let tabVC = window?.rootViewController as? MainTabBarController else { return }

        switch shortcutItem.type {
        case "ProjectsAction":
            tabVC.changeCurrentTab(index: 1)
        case "NewThoughtAction":
            tabVC.openNewThought()
        default:
            break
        }
    }

    func setupNavigationBar() {
        UINavigationBar.appearance().tintColor = UIColor(red: 65/255, green: 65/255, blue: 65/255, alpha: 1)

        UITextField.appearance(whenContainedInInstancesOf: [UISearchBar.self]).backgroundColor = UIColor(red: 142/255, green: 142/255, blue: 147/255, alpha: 0.12)
    }

    func checkIfUserSignedIn() {
        let accessGroup = "5B8JD5RLV7.com.voidllc.transom"
        let user = Auth.auth().currentUser
        
        do {
            try Auth.auth().useUserAccessGroup(accessGroup)
        } catch let error as NSError {
            print(error.userInfo)
        }

        if let user = user {
            Auth.auth().updateCurrentUser(user, completion: nil)
        } else {
            window?.rootViewController = ColdOpeningVC.instantiate()
            window?.makeKeyAndVisible()
        }
    }
}

extension AppDelegate: UNUserNotificationCenterDelegate {
    func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse, withCompletionHandler completionHandler: @escaping () -> Void) {
        if response.notification.request.content.categoryIdentifier == "dailyWordReminder" {
            guard let rootVC = window?.rootViewController as? MainTabBarController else { return }
            rootVC.openNewThought(animated: false)
        }

        completionHandler()
    }
}
